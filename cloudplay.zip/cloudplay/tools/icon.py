"""CloudPlay's app icon: a cloud holding a game controller, drawn with smooth
shapes at 1024x1024 and shrunk to each size, so it's clean at any size.

    python3 tools/icon.py                    writes web/icon.png (256x256)
    python3 tools/icon.py <icons folder>     also installs every size there (hicolor)
"""
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw

K = 16  # drawing units (a 64x64 grid) to pixels at 1024
DY = 1.5  # everything moved down a little, to sit in the middle of the square
C = {"bg": (23, 20, 15), "edge": (255, 122, 61), "cloud": (242, 232, 216), "cloud-lo": (214, 200, 178),
     "pad": (255, 122, 61), "hi": (255, 170, 125), "lo": (196, 84, 33), "ink": (35, 28, 21),
     "stick": (78, 68, 58), "stick-top": (150, 136, 118), "gold": (242, 193, 78), "pink": (255, 111, 174),
     "green": (123, 211, 137), "blue": (90, 162, 255), "home": (242, 232, 216)}


def box(x0, y0, x1, y1):
    return [x0 * K, (y0 + DY) * K, x1 * K, (y1 + DY) * K]


def circle(cx, cy, r):
    return box(cx - r, cy - r, cx + r, cy + r)


def mask(shapes, grow=0.0):
    m = Image.new("L", (64 * K, 64 * K), 0)
    d = ImageDraw.Draw(m)
    for kind, (x0, y0, x1, y1), *radius in shapes:
        b = box(x0 - grow, y0 - grow, x1 + grow, y1 + grow)
        if kind == "ellipse":
            d.ellipse(b, fill=255)
        else:
            d.rounded_rectangle(b, radius=(radius[0] + grow) * K if radius else 0, fill=255)
    return m


def shifted(m, dy):
    return ImageChops.offset(m, 0, round(dy * K))


def draw():
    img = Image.new("RGBA", (64 * K, 64 * K), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([2 * K, 2 * K, 62 * K, 62 * K], radius=13 * K, fill=C["bg"], outline=C["edge"], width=round(2.6 * K))

    def paint(colour, m):
        img.paste(Image.new("RGBA", img.size, colour + (255,)), (0, 0), m)

    cloud = [("ellipse", (7, 27, 29, 49)), ("ellipse", (17, 12, 45, 40)), ("ellipse", (34, 22, 56, 44)),
             ("ellipse", (37, 31, 55, 49)), ("rect", (17, 32, 46, 49))]
    cloud_m = mask(cloud)
    paint(C["cloud"], cloud_m)
    paint(C["cloud-lo"], ImageChops.subtract(cloud_m, shifted(cloud_m, -1.2)))  # soft shadow along its bottom

    body = [("rect", (18, 28, 45, 39), 5), ("ellipse", (14.5, 31, 26.5, 48)), ("ellipse", (36.5, 31, 48.5, 48)),
            ("rect", (22, 33, 41, 42))]
    body_m = mask(body)
    paint(C["ink"], mask(body, grow=1.1))  # outline
    paint(C["pad"], body_m)
    paint(C["hi"], ImageChops.subtract(body_m, shifted(body_m, 1.0)))   # light along the top
    paint(C["lo"], ImageChops.subtract(body_m, shifted(body_m, -1.6)))  # shadow along the bottom

    d = ImageDraw.Draw(img)
    d.rounded_rectangle(box(22.4, 29.3, 24.6, 36.7), radius=0.5 * K, fill=C["ink"])  # d-pad
    d.rounded_rectangle(box(19.8, 31.9, 27.2, 34.1), radius=0.5 * K, fill=C["ink"])
    for cx in (27.8, 35.7):  # thumbsticks
        d.ellipse(circle(cx, 38.2, 2.9), fill=C["ink"])
        d.ellipse(circle(cx, 38.2, 2.1), fill=C["stick"])
        d.ellipse(circle(cx - 0.5, 37.6, 0.8), fill=C["stick-top"])
    for colour, (cx, cy) in {"gold": (40, 30.3), "pink": (42.7, 33), "green": (40, 35.7), "blue": (37.3, 33)}.items():
        d.ellipse(circle(cx, cy, 1.3), fill=C["ink"])
        d.ellipse(circle(cx, cy, 1.0), fill=C[colour])
    d.ellipse(circle(31.75, 31.2, 1.0), fill=C["home"])
    return img


def at(img, size):
    return img.resize((size, size), Image.LANCZOS)


if __name__ == "__main__":
    big = draw()
    at(big, 256).save("web/icon.png")
    if len(sys.argv) > 1:
        for size in (16, 22, 24, 32, 48, 64, 128, 256):
            out = Path(sys.argv[1]) / f"{size}x{size}" / "apps" / "cloudplay.png"
            out.parent.mkdir(parents=True, exist_ok=True)
            at(big, size).save(out)
        subprocess.run(["gtk-update-icon-cache", "-f", "-t", sys.argv[1]], capture_output=True)
