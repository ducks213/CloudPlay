"""A virtual controller for each game, driven by the player's gamepad, and of
the same kind as theirs: an Xbox 360 pad, a PlayStation DualSense or a
Nintendo Switch Pro controller, so games show the right button hints.

Each is created through Linux uinput and looks exactly like the real one does
with its kernel driver (xpad, hid-playstation, hid-nintendo: same name, IDs,
buttons and axes), so Linux games (SDL, Steam Input) and Windows games under
Wine recognise it without any mapping.

The browser sends the Gamepad API's "standard" layout: buttons 0-16 as a bit
mask, sticks as -1..1 and triggers as 0..1. Its buttons are by position (0 is
the bottom face button: A, ✕ or B), and so are the kernel's (BTN_SOUTH...).
"""
import logging
import os

log = logging.getLogger("cloudplay.pad")

try:
    import evdev
    from evdev import AbsInfo, UInput
    from evdev import ecodes as e
except ImportError:  # python3-evdev not installed: players' gamepads fall back to keys
    evdev = None

if evdev:
    # Standard Gamepad API button index -> key code. The D-pad (12-15) is a
    # hat, and the triggers (6, 7) are handled per kind. The xpad driver files
    # the left face button (X) as BTN_NORTH and the top one (Y) as BTN_WEST;
    # hid-playstation and hid-nintendo go by position (left WEST, top NORTH).
    BUTTONS = {
        0: e.BTN_SOUTH, 1: e.BTN_EAST, 2: e.BTN_NORTH, 3: e.BTN_WEST,
        4: e.BTN_TL, 5: e.BTN_TR, 8: e.BTN_SELECT, 9: e.BTN_START,
        10: e.BTN_THUMBL, 11: e.BTN_THUMBR, 16: e.BTN_MODE,
    }
    BY_POSITION = {**BUTTONS, 2: e.BTN_WEST, 3: e.BTN_NORTH}
    STICKS = (e.ABS_X, e.ABS_Y, e.ABS_RX, e.ABS_RY)

    KINDS = {
        "xbox": {  # the xpad driver's wired Xbox 360 pad
            "name": "Microsoft X-Box 360 pad", "vendor": 0x045E, "product": 0x028E, "version": 0x110,
            "stick": (-32768, 32767, 16, 128), "analog_triggers": True, "trigger_buttons": False,
            "buttons": BUTTONS, "extra_keys": (),
        },
        "playstation": {  # hid-playstation's DualSense (PS5)
            "name": "Sony Interactive Entertainment DualSense Wireless Controller",
            "vendor": 0x054C, "product": 0x0CE6, "version": 0x8111,
            "stick": (0, 255, 0, 0), "analog_triggers": True, "trigger_buttons": True,
            "buttons": BY_POSITION, "extra_keys": (),
        },
        "nintendo": {  # hid-nintendo's Switch Pro controller (ZL/ZR are buttons only)
            "name": "Nintendo Switch Pro Controller", "vendor": 0x057E, "product": 0x2009, "version": 0x8111,
            "stick": (-32767, 32767, 0, 500), "analog_triggers": False, "trigger_buttons": True,
            "buttons": BY_POSITION, "extra_keys": (e.BTN_Z,),  # (Capture: games count buttons in code order)
        },
    }

    def capabilities(kind):
        k = KINDS[kind]
        low, high, fuzz, flat = k["stick"]
        keys = sorted({*k["buttons"].values(), *k["extra_keys"], *((e.BTN_TL2, e.BTN_TR2) if k["trigger_buttons"] else ())})
        axes = [(axis, AbsInfo(value=(low + high + 1) // 2 if low == 0 else 0, min=low, max=high,
                               fuzz=fuzz, flat=flat, resolution=0)) for axis in STICKS]
        if k["analog_triggers"]:
            axes += [(e.ABS_Z, AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0)),
                     (e.ABS_RZ, AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0))]
        axes += [(e.ABS_HAT0X, AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0)),  # D-pad
                 (e.ABS_HAT0Y, AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0))]
        return {e.EV_KEY: keys, e.EV_ABS: axes}

    CAPABILITIES = capabilities("xbox")  # (what an Xbox pad offers; kept for older callers)
else:
    KINDS = {}


class VirtualPad:
    def __init__(self, create=True):
        """create: the kind of controller ("xbox", "playstation", "nintendo";
        True is an Xbox pad), or False for none (the player has no gamepad, so
        games show keyboard hints instead of controller buttons)."""
        self.device = None
        self.state = {}
        self.primed = False
        self.kind = None
        if not evdev or not create:
            return
        self.kind = create if create in KINDS else "xbox"
        k = KINDS[self.kind]
        self.caps = capabilities(self.kind)
        try:
            self.device = UInput(self.caps, name=k["name"], vendor=k["vendor"], product=k["product"],
                                 version=k["version"], bustype=e.BUS_USB)
        except (OSError, evdev.uinput.UInputError) as err:
            log.warning("no virtual controller (%s): gamepads will send keys instead", err)

    @property
    def available(self):
        return self.device is not None

    @property
    def nodes(self):
        """The device files games open: /dev/input/eventN and /dev/input/jsN."""
        if not self.device:
            return []
        event = self.device.device.path
        sysfs = f"/sys/class/input/{os.path.basename(event)}/device"
        return [event, *(f"/dev/input/{name}" for name in sorted(os.listdir(sysfs)) if name.startswith("js"))]

    def update(self, buttons, sticks, triggers):
        """buttons: standard-layout bit mask; sticks: [lx, ly, rx, ry] in -1..1;
        triggers: [left, right] in 0..1. Only changes are written."""
        if not self.device:
            return
        if not self.primed and (buttons or any(sticks) or any(triggers)):
            self._prime()  # at the player's first input, by when the game has the pad open
        k = KINDS[self.kind]
        low, high = k["stick"][:2]
        pressed = lambda i: bool(buttons >> i & 1)  # noqa: E731
        values = {(e.EV_KEY, code): int(pressed(i)) for i, code in k["buttons"].items()}
        for axis, value in zip(STICKS, sticks):
            value = max(-1.0, min(1.0, value))
            values[(e.EV_ABS, axis)] = round(low + (value + 1) / 2 * (high - low)) if low == 0 else round(value * high)
        left, right = (max(0.0, min(1.0, t)) for t in triggers)
        if k["analog_triggers"]:
            values[(e.EV_ABS, e.ABS_Z)] = round(left * 255)
            values[(e.EV_ABS, e.ABS_RZ)] = round(right * 255)
        if k["trigger_buttons"]:  # (also counted as pressed when pulled at all, as the real ones do)
            values[(e.EV_KEY, e.BTN_TL2)] = int(left > 0.05 or pressed(6))
            values[(e.EV_KEY, e.BTN_TR2)] = int(right > 0.05 or pressed(7))
        values[(e.EV_ABS, e.ABS_HAT0X)] = pressed(15) - pressed(14)
        values[(e.EV_ABS, e.ABS_HAT0Y)] = pressed(13) - pressed(12)
        changed = False
        for (kind, code), value in values.items():
            if self.state.get((kind, code), self._rest(kind, code)) != value:
                self.device.write(kind, code, value)
                self.state[(kind, code)] = value
                changed = True
        if changed:
            self.device.syn()

    def _rest(self, kind, code):
        """An input's value at rest (sticks rest mid-range where they start at 0)."""
        if kind == e.EV_ABS and code in STICKS:
            low, high = KINDS[self.kind]["stick"][:2]
            return (low + high + 1) // 2 if low == 0 else 0
        return 0

    def _prime(self):
        """SDL (which Wine uses for controllers) takes the first value it sees on
        each axis as that axis's resting point, so a first real movement (say a
        half-pressed trigger) would be lost. Wiggle every axis by one step from
        rest before the player's first input, once the game has the pad open."""
        axes = [code for code, _ in self.caps[e.EV_ABS] if code not in (e.ABS_HAT0X, e.ABS_HAT0Y)]
        for step in (1, 0):
            for code in axes:
                self.device.write(e.EV_ABS, code, self._rest(e.EV_ABS, code) + step)
            self.device.syn()
        self.primed = True

    def release(self):
        """Let go of everything (the player left, or their gamepad disconnected)."""
        self.update(0, [0, 0, 0, 0], [0, 0])

    def close(self):
        if self.device:
            self.release()
            self.device.close()
            self.device = None
