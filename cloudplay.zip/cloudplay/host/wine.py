"""CloudPlay's own Wine prefix, with the translation layers Steam's Proton uses.

Windows games run in ~/.local/share/cloudplay/wine instead of the desktop's
~/.wine, so they never share a wineserver, single-instance locks or settings
with Windows programs the host's user runs on the desktop.

DXVK turns Direct3D 8-11 into Vulkan and VKD3D-Proton does Direct3D 12. That
is how the Steam Deck runs most Windows games; Wine's own Direct3D goes through
OpenGL and is slower and less compatible (and Wine 9 has no usable D3D12).

    python3 -m host.wine     # download the layers (once) and set up the prefix

The stream host also sets the prefix up by itself the first time a Windows
game starts, using whatever layers have been downloaded.
"""
import hashlib
import logging
import os
import shutil
import subprocess
import tarfile
import tempfile
import threading
import urllib.request
from pathlib import Path

log = logging.getLogger("cloudplay.wine")

DATA = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "cloudplay"
PREFIX = DATA / "wine"
LAYERS = DATA / "layers"
MARKER = PREFIX / ".cloudplay-layers"  # which layer versions are installed in the prefix

# Pinned releases, checked against these hashes when downloaded. DXVK stays on
# 2.7.1: 3.x requires VK_KHR_load_store_op_none, which Wine 9.0 doesn't pass
# through to Windows programs, so it finds no usable GPU there.
RELEASES = {
    "dxvk-2.7.1": (
        "https://github.com/doitsujin/dxvk/releases/download/v2.7.1/dxvk-2.7.1.tar.gz",
        "d85ce7c79f57ecd765aaa1b9e7007cb875e6fde9f6d331df799bce73d513ce87",
    ),
    "vkd3d-proton-3.0.1": (
        "https://github.com/HansKristian-Work/vkd3d-proton/releases/download/v3.0.1/vkd3d-proton-3.0.1.tar.zst",
        "3cf2315522af5e43605ef6d3c41dad91387040bf97199934f3f7ab76caaa2f0c",
    ),
}
# DLLs each layer replaces, and its folders for 64-bit and 32-bit games.
LAYER_DLLS = {
    "dxvk-2.7.1": (["d3d8", "d3d9", "d3d10core", "d3d11", "dxgi"], "x64", "x32"),
    "vkd3d-proton-3.0.1": (["d3d12", "d3d12core"], "x64", "x86"),
}

_setup_lock = threading.Lock()


def game_env():
    """Environment for a Windows game: CloudPlay's prefix, set up if needed."""
    with _setup_lock:
        setup()
    return {
        "WINEPREFIX": str(PREFIX),
        "WINEDEBUG": "-all",  # Wine's debug output costs CPU and nobody reads it
        "DXVK_LOG_LEVEL": "none",
        "VKD3D_DEBUG": "none",
    }


def setup():
    """Create the prefix and install every downloaded layer into it. Quick when
    nothing changed; the first run takes a few seconds (wineboot)."""
    wine = shutil.which("wine")
    if not wine:
        return
    layers = sorted(name for name in LAYER_DLLS if (LAYERS / name).is_dir())
    if MARKER.exists() and MARKER.read_text().split() == layers:
        return
    env = _setup_env()
    if not (PREFIX / "system.reg").exists():
        log.info("creating CloudPlay's Wine prefix in %s", PREFIX)
        PREFIX.mkdir(parents=True, exist_ok=True)
        _run([wine, "wineboot", "--init"], env)
    windows = PREFIX / "drive_c" / "windows"
    overrides = []
    for name in layers:
        dlls, dir64, dir32 = LAYER_DLLS[name]
        for src, dst in ((dir64, "system32"), (dir32, "syswow64")):
            if (windows / dst).is_dir() and (LAYERS / name / src).is_dir():
                for dll in dlls:
                    shutil.copy2(LAYERS / name / src / f"{dll}.dll", windows / dst / f"{dll}.dll")
        overrides += dlls
    if overrides:
        # Use the copied DLLs instead of Wine's built-in ones.
        with tempfile.NamedTemporaryFile("w", suffix=".reg", delete=False) as reg:
            reg.write("REGEDIT4\n\n[HKEY_CURRENT_USER\\Software\\Wine\\DllOverrides]\n")
            reg.writelines(f'"{dll}"="native"\n' for dll in overrides)
        try:
            _run([wine, "regedit", "/S", reg.name], env)
        finally:
            os.unlink(reg.name)
    _run([shutil.which("wineserver") or "wineserver", "-w"], env)  # let the registry reach the disk
    MARKER.write_text(" ".join(layers))
    log.info("Wine prefix ready with %s", ", ".join(layers) or "no translation layers")


def _setup_env():
    env = dict(os.environ, WINEPREFIX=str(PREFIX), WINEDEBUG="-all")
    # Headless: no "updating configuration" window, and no prompts to download Mono/Gecko.
    env.pop("DISPLAY", None)
    env.pop("WAYLAND_DISPLAY", None)
    env["WINEDLLOVERRIDES"] = "mscoree=;mshtml="
    return env


def _run(cmd, env):
    subprocess.run(cmd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                   timeout=300, check=False)


def download():
    """Fetch the pinned layer releases into LAYERS (checking their hashes)."""
    LAYERS.mkdir(parents=True, exist_ok=True)
    for name, (url, sha256) in RELEASES.items():
        if (LAYERS / name).is_dir():
            continue
        archive = LAYERS / url.rsplit("/", 1)[1]
        if not archive.exists():
            log.info("downloading %s", url)
            with urllib.request.urlopen(url, timeout=60) as resp, open(archive, "wb") as out:
                shutil.copyfileobj(resp, out)
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        if digest != sha256:
            archive.unlink()
            raise SystemExit(f"{archive.name}: unexpected SHA-256 {digest}")
        if archive.name.endswith(".tar.zst"):
            subprocess.run(["tar", "--zstd", "-xf", archive, "-C", LAYERS], check=True)
        else:
            with tarfile.open(archive) as tar:
                tar.extractall(LAYERS, filter="data")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    download()
    setup()
