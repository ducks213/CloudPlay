"""Per-game sound: a virtual sound device for each game, recorded and encoded
for the browser.

Each game gets its own PulseAudio/PipeWire null sink (named in its
environment for every sound API), so its sound never plays on the host's
speakers or leaks into another player's stream. The sink's monitor is
captured with GStreamer and sent either as Opus packets (20 ms, for browsers
with WebCodecs' AudioDecoder) or as raw 16-bit PCM (for the rest).
"""
import itertools
import logging
import os
import re
import shutil
import subprocess

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst  # noqa: E402

log = logging.getLogger("cloudplay.audio")

RATE, CHANNELS = 48000, 2
CODECS = ("opus", "pcm")
SINK_PREFIX = "cloudplay-"

Gst.init(None)
_count = itertools.count()


class GameAudio:
    def __init__(self, codec):
        self.sink = f"{SINK_PREFIX}{os.getpid()}-{next(_count)}"
        self.module = self.pipeline = self.appsink = None
        self.module = _pactl("load-module", "module-null-sink", f"sink_name={self.sink}",
                             "sink_properties=device.description=CloudPlay-game")
        if not self.module:
            log.warning("no sound: couldn't create a virtual sound device (is PulseAudio/PipeWire running?)")
            return
        encode = "opusenc bitrate=128000 frame-size=20 ! " if codec == "opus" else ""
        self.pipeline = Gst.parse_launch(
            f"pulsesrc device={self.sink}.monitor buffer-time=40000 latency-time=10000 ! "
            f"audioconvert ! audioresample ! audio/x-raw,format=S16LE,rate={RATE},channels={CHANNELS} ! "
            f"{encode}appsink name=sink max-buffers=200 drop=true sync=false"
        )
        self.appsink = self.pipeline.get_by_name("sink")
        self.pipeline.set_state(Gst.State.PLAYING)

    @property
    def env(self):
        """Environment that sends a game's sound to its own device, whichever
        sound API it uses: PulseAudio (most games, Wine), PipeWire directly
        (e.g. newer OpenAL Soft, SDL3) or ALSA through PipeWire's plugin."""
        if not self.module:
            return {}
        return {
            "PULSE_SINK": self.sink,
            "PIPEWIRE_PROPS": f"{{ target.object = {self.sink} }}",
            "PIPEWIRE_NODE": self.sink,
        }

    def pull(self):
        """Every audio packet captured since the last call, oldest first."""
        packets = []
        while self.appsink is not None:
            sample = self.appsink.try_pull_sample(0)
            if sample is None:
                break
            buf = sample.get_buffer()
            packets.append(buf.extract_dup(0, buf.get_size()))
        return packets

    def close(self):
        if self.pipeline is not None:
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = self.appsink = None
        if self.module:
            _pactl("unload-module", self.module)
            self.module = None


def remove_stale():
    """Unload virtual devices left by a CloudPlay process that has died."""
    for line in (_pactl("list", "short", "modules") or "").splitlines():
        match = re.search(rf"sink_name={SINK_PREFIX}(\d+)-", line)
        if match and not os.path.exists(f"/proc/{match.group(1)}"):
            _pactl("unload-module", line.split()[0])


def _pactl(*args):
    pactl = shutil.which("pactl")
    if not pactl:
        return None
    try:
        r = subprocess.run([pactl, *args], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return r.stdout.strip() if r.returncode == 0 else None
