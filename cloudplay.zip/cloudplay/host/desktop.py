"""Stream a real PC game: launch it, capture its window, replay the player's input.

By default each game gets its own hidden screen (an Xvfb virtual display), so
nothing appears on the host's monitor and the host's mouse and keyboard are
left alone; the game is only visible in the player's browser. Its window is
found among the screen's top-level windows, captured with GStreamer
(ximagesrc → scale → JPEG) and followed as it moves or resizes. Input is
replayed through the XTest extension.

Alternatively a game can run on the host's real desktop (--on-screen). There
its window is found through the window manager's client list (matched by
process group), and input is only replayed while one of the game's windows is
active, so a remote player can never type or click into anything else.

Windows games run through Wine. Imported games only ever come from tickets the
control plane signed, and only the server owner can import them.
"""
import ctypes
import functools
import glob
import io
import itertools
import json
import logging
import os
import re
import select
import shutil
import signal
import subprocess
import sys
import threading
import time

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstApp", "1.0")
gi.require_version("GstVideo", "1.0")
from gi.repository import Gst, GstApp, GstVideo  # noqa: E402,F401  (GstApp registers appsink's pull API)
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

from common import console, epic, steam  # noqa: E402
from host import audio, pad, wine  # noqa: E402

log = logging.getLogger("cloudplay.desktop")

OUT_W, OUT_H = 1920, 1080  # H.264 stream, and the size of hidden screens
JPEG_W, JPEG_H = 1280, 720  # JPEG fallback, for browsers without WebCodecs
JPEG_FPS = 30
# The player's stream quality setting: largest picture and frame rate for H.264.
QUALITY = {"best": (1920, 1080, 60), "balanced": (1280, 720, 60), "saver": (1280, 720, 30)}
BITS_PER_PIXEL = 0.1  # H.264 bitrate budget: 1080p60 ≈ 12 Mbit/s

# What a binary message to the browser holds (the byte after the sequence number).
FRAME_JPEG, FRAME_KEY, FRAME_DELTA, AUDIO = 0, 1, 2, 3
MIN_WINDOW = 64
KILL_GRACE_SECONDS = 3

Gst.init(None)

# --- Xlib via ctypes --------------------------------------------------------

_x11 = ctypes.cdll.LoadLibrary("libX11.so.6")
_xtst = ctypes.cdll.LoadLibrary("libXtst.so.6")
try:
    _xfixes = ctypes.cdll.LoadLibrary("libXfixes.so.3")
except OSError:
    _xfixes = None  # can't tell whether games hide their cursor; the browser always shows one
try:
    _xdamage = ctypes.cdll.LoadLibrary("libXdamage.so.1")
except OSError:
    _xdamage = None  # no real game fps, everything else still works
_x11.XInitThreads()  # must precede every other Xlib call; GStreamer's ximagesrc shares libX11

_c = ctypes
Window = Atom = KeySym = _c.c_ulong


class XWindowAttributes(_c.Structure):
    _fields_ = [
        ("x", _c.c_int), ("y", _c.c_int), ("width", _c.c_int), ("height", _c.c_int),
        ("border_width", _c.c_int), ("depth", _c.c_int), ("visual", _c.c_void_p), ("root", Window),
        ("class_", _c.c_int), ("bit_gravity", _c.c_int), ("win_gravity", _c.c_int), ("backing_store", _c.c_int),
        ("backing_planes", _c.c_ulong), ("backing_pixel", _c.c_ulong), ("save_under", _c.c_int),
        ("colormap", _c.c_ulong), ("map_installed", _c.c_int), ("map_state", _c.c_int),
        ("all_event_masks", _c.c_long), ("your_event_mask", _c.c_long), ("do_not_propagate_mask", _c.c_long),
        ("override_redirect", _c.c_int), ("screen", _c.c_void_p),
    ]


class XClientMessageEvent(_c.Structure):
    _fields_ = [
        ("type", _c.c_int), ("serial", _c.c_ulong), ("send_event", _c.c_int), ("display", _c.c_void_p),
        ("window", Window), ("message_type", Atom), ("format", _c.c_int), ("data", _c.c_long * 5),
    ]


class XEvent(_c.Union):
    _fields_ = [("xclient", XClientMessageEvent), ("pad", _c.c_long * 24)]


_x11.XOpenDisplay.restype = _c.c_void_p
_x11.XOpenDisplay.argtypes = [_c.c_char_p]
_x11.XCloseDisplay.argtypes = [_c.c_void_p]
_x11.XDefaultRootWindow.restype = Window
_x11.XDefaultRootWindow.argtypes = [_c.c_void_p]
_x11.XDisplayWidth.argtypes = _x11.XDisplayHeight.argtypes = [_c.c_void_p, _c.c_int]
_x11.XInternAtom.restype = Atom
_x11.XInternAtom.argtypes = [_c.c_void_p, _c.c_char_p, _c.c_int]
_x11.XGetWindowProperty.argtypes = [
    _c.c_void_p, Window, Atom, _c.c_long, _c.c_long, _c.c_int, Atom,
    _c.POINTER(Atom), _c.POINTER(_c.c_int), _c.POINTER(_c.c_ulong), _c.POINTER(_c.c_ulong),
    _c.POINTER(_c.POINTER(_c.c_ubyte)),
]
_x11.XFree.argtypes = [_c.c_void_p]
_x11.XGetWindowAttributes.argtypes = [_c.c_void_p, Window, _c.POINTER(XWindowAttributes)]
_x11.XTranslateCoordinates.argtypes = [
    _c.c_void_p, Window, Window, _c.c_int, _c.c_int, _c.POINTER(_c.c_int), _c.POINTER(_c.c_int), _c.POINTER(Window),
]
_x11.XSendEvent.argtypes = [_c.c_void_p, Window, _c.c_int, _c.c_long, _c.POINTER(XEvent)]
_x11.XStringToKeysym.restype = KeySym
_x11.XStringToKeysym.argtypes = [_c.c_char_p]
_x11.XKeysymToKeycode.restype = _c.c_ubyte
_x11.XKeysymToKeycode.argtypes = [_c.c_void_p, KeySym]
_x11.XFlush.argtypes = [_c.c_void_p]
_x11.XPending.argtypes = _x11.XConnectionNumber.argtypes = [_c.c_void_p]
_x11.XNextEvent.argtypes = [_c.c_void_p, _c.c_void_p]
if _xdamage:
    _xdamage.XDamageQueryExtension.argtypes = [_c.c_void_p, _c.POINTER(_c.c_int), _c.POINTER(_c.c_int)]
    _xdamage.XDamageCreate.restype = _c.c_ulong
    _xdamage.XDamageCreate.argtypes = [_c.c_void_p, _c.c_ulong, _c.c_int]
    _xdamage.XDamageSubtract.argtypes = [_c.c_void_p, _c.c_ulong, _c.c_ulong, _c.c_ulong]
    _xdamage.XDamageDestroy.argtypes = [_c.c_void_p, _c.c_ulong]
_x11.XQueryTree.argtypes = [
    _c.c_void_p, Window, _c.POINTER(Window), _c.POINTER(Window), _c.POINTER(_c.POINTER(Window)), _c.POINTER(_c.c_uint),
]
_x11.XSetInputFocus.argtypes = [_c.c_void_p, Window, _c.c_int, _c.c_ulong]
_x11.XRaiseWindow.argtypes = [_c.c_void_p, Window]
_xtst.XTestFakeKeyEvent.argtypes = [_c.c_void_p, _c.c_uint, _c.c_int, _c.c_ulong]
_xtst.XTestFakeButtonEvent.argtypes = [_c.c_void_p, _c.c_uint, _c.c_int, _c.c_ulong]
_xtst.XTestFakeMotionEvent.argtypes = [_c.c_void_p, _c.c_int, _c.c_int, _c.c_int, _c.c_ulong]

# Xlib's default error handler exits the process; windows vanish all the time here.
_IGNORE_X_ERRORS = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.c_void_p)(lambda display, event: 0)
_x11.XSetErrorHandler.argtypes = [_c.c_void_p]
_x11.XSetErrorHandler(_c.cast(_IGNORE_X_ERRORS, _c.c_void_p))

class XFixesCursorImage(ctypes.Structure):
    _fields_ = [
        ("x", ctypes.c_short), ("y", ctypes.c_short), ("width", ctypes.c_ushort), ("height", ctypes.c_ushort),
        ("xhot", ctypes.c_ushort), ("yhot", ctypes.c_ushort), ("cursor_serial", ctypes.c_ulong),
        ("pixels", ctypes.POINTER(ctypes.c_ulong)), ("atom", ctypes.c_ulong), ("name", ctypes.c_char_p),
    ]


if _xfixes:
    _xfixes.XFixesGetCursorImage.restype = ctypes.POINTER(XFixesCursorImage)
    _xfixes.XFixesGetCursorImage.argtypes = [ctypes.c_void_p]

IS_VIEWABLE = 2
DAMAGE_REPORT_NON_EMPTY = 3
REVERT_TO_PARENT = 2
CLIENT_MESSAGE = 33
SUBSTRUCTURE_REDIRECT_AND_NOTIFY = (1 << 20) | (1 << 19)

# Browser KeyboardEvent.code → X keysym. Super/Meta is left out on purpose so
# players can't trigger desktop shortcuts.
_KEY_NAMES = {
    **{f"Key{c}": c.lower() for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"},
    **{f"Digit{d}": str(d) for d in range(10)},
    **{f"F{n}": f"F{n}" for n in range(1, 13)},
    "ArrowUp": "Up", "ArrowDown": "Down", "ArrowLeft": "Left", "ArrowRight": "Right",
    "Enter": "Return", "NumpadEnter": "KP_Enter", "Escape": "Escape", "Space": "space", "Tab": "Tab",
    "Backspace": "BackSpace", "Delete": "Delete", "Insert": "Insert", "Home": "Home", "End": "End",
    "PageUp": "Prior", "PageDown": "Next", "CapsLock": "Caps_Lock",
    "ShiftLeft": "Shift_L", "ShiftRight": "Shift_R", "ControlLeft": "Control_L", "ControlRight": "Control_R",
    "AltLeft": "Alt_L", "AltRight": "Alt_R",
    "Minus": "minus", "Equal": "equal", "BracketLeft": "bracketleft", "BracketRight": "bracketright",
    "Semicolon": "semicolon", "Quote": "apostrophe", "Backquote": "grave", "Backslash": "backslash",
    "Comma": "comma", "Period": "period", "Slash": "slash",
    **{f"Numpad{d}": f"KP_{d}" for d in range(10)},
}
KEYSYMS = {code: _x11.XStringToKeysym(name.encode()) for code, name in _KEY_NAMES.items()}


class LaunchError(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


class GameExited(Exception):
    pass


def _pgid(pid):
    try:
        return os.getpgid(pid)
    except (ProcessLookupError, PermissionError):
        return None


class VirtualScreen:
    """A private, invisible X screen that one game runs on. It's full HD so
    games that go fullscreen fill the 1080p stream.

    Preferably it's a rootful Xwayland inside a headless Weston that renders
    with the GPU, so OpenGL *and* Vulkan (DirectX 11/12 games under Wine) get
    the graphics card directly. Without Weston it falls back to Xvfb, where
    only OpenGL can reach the GPU, through VirtualGL (see with_gpu)."""

    _count = itertools.count()

    def __init__(self, width=OUT_W, height=OUT_H):
        self.procs = []
        self.gpu = False
        try:
            if self._gpu_available():
                try:
                    socket = self._start_weston(width, height)
                    env = dict(os.environ, WAYLAND_DISPLAY=socket)
                    self.name = self._start_x([shutil.which("Xwayland"), "-geometry", f"{width}x{height}"], env)
                    self.gpu = True
                except LaunchError:
                    log.warning("GPU screen (Weston) failed to start; falling back to Xvfb")
                    self.close()
            if not self.gpu:
                xvfb = shutil.which("Xvfb")
                if not xvfb:
                    raise LaunchError("no_xvfb")
                self.name = self._start_x([xvfb, "-screen", "0", f"{width}x{height}x24"], os.environ)
        except BaseException:
            self.close()
            raise
        log.info("started hidden screen %s (%dx%d, %s)", self.name, width, height, "GPU via Weston" if self.gpu else "Xvfb")

    @staticmethod
    def _gpu_available():
        return bool(
            shutil.which("weston") and shutil.which("Xwayland")
            and os.environ.get("XDG_RUNTIME_DIR") and glob.glob("/dev/dri/renderD*")
        )

    def _spawn(self, cmd, env, **kw):
        try:
            proc = subprocess.Popen(
                cmd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True, **kw,
            )
        except OSError as e:
            raise LaunchError("launch_failed") from e
        self.procs.append(proc)
        return proc

    def _start_weston(self, width, height):
        """A headless Weston compositing on the GPU; kiosk shell shows the one
        X screen full size and starts no panels or helpers."""
        socket = f"cloudplay-{os.getpid()}-{next(self._count)}"
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], socket)
        env = {k: v for k, v in os.environ.items() if k not in ("WAYLAND_DISPLAY", "DISPLAY")}
        proc = self._spawn([
            shutil.which("weston"), "--backend=headless", "--renderer=gl", "--shell=kiosk", "--no-config",
            f"--socket={socket}", f"--width={width}", f"--height={height}", "--idle-time=0",
        ], env)
        deadline = time.monotonic() + 10
        while not os.path.exists(path):
            if proc.poll() is not None or time.monotonic() > deadline:
                raise LaunchError("launch_failed")
            time.sleep(0.05)
        return socket

    def _start_x(self, cmd, env):
        """Start an X server that picks a free display number and reports it
        through -displayfd once it's ready."""
        read_fd, write_fd = os.pipe()
        try:
            self._spawn([*cmd, "-displayfd", str(write_fd), "-nolisten", "tcp", "-noreset"], env, pass_fds=(write_fd,))
        except LaunchError:
            os.close(read_fd)
            raise
        finally:
            os.close(write_fd)
        number = b""
        deadline = time.monotonic() + 10
        with os.fdopen(read_fd, "rb", buffering=0) as pipe:
            while not number.endswith(b"\n") and time.monotonic() < deadline:
                if select.select([pipe], [], [], max(0.0, deadline - time.monotonic()))[0]:
                    chunk = pipe.read(16)
                    if not chunk:
                        break
                    number += chunk
        if not number.strip().isdigit():
            raise LaunchError("launch_failed")
        return f":{number.strip().decode()}"

    def close(self):
        for proc in reversed(self.procs):  # X server first, then its compositor
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(KILL_GRACE_SECONDS)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
        self.procs.clear()


class X11:
    def __init__(self, name, private=False):
        self.private = private  # a hidden screen of our own: every window on it is the game's
        self.d = _x11.XOpenDisplay(name.encode())
        if not self.d:
            raise LaunchError("no_display")
        self.root = _x11.XDefaultRootWindow(self.d)
        self.width = _x11.XDisplayWidth(self.d, 0)
        self.height = _x11.XDisplayHeight(self.d, 0)
        self._atoms = {}

    def atom(self, name):
        if name not in self._atoms:
            self._atoms[name] = _x11.XInternAtom(self.d, name.encode(), 0)
        return self._atoms[name]

    def prop(self, window, name):
        """Read a 32-bit list property (CARDINAL / WINDOW) as Python ints."""
        kind, fmt, count, after = Atom(), _c.c_int(), _c.c_ulong(), _c.c_ulong()
        data = _c.POINTER(_c.c_ubyte)()
        status = _x11.XGetWindowProperty(
            self.d, window, self.atom(name), 0, 4096, 0, 0,
            _c.byref(kind), _c.byref(fmt), _c.byref(count), _c.byref(after), _c.byref(data),
        )
        if status != 0 or not data:
            return []
        try:
            if fmt.value != 32:
                return []
            values = _c.cast(data, _c.POINTER(_c.c_ulong))  # format-32 data is an array of C longs
            return [values[i] for i in range(count.value)]
        finally:
            _x11.XFree(data)

    def geometry(self, window):
        """Visible client area in root coordinates, or None if not viewable."""
        attrs = XWindowAttributes()
        if not _x11.XGetWindowAttributes(self.d, window, _c.byref(attrs)) or attrs.map_state != IS_VIEWABLE:
            return None
        if self.atom("_NET_WM_STATE_HIDDEN") in self.prop(window, "_NET_WM_STATE"):
            return None  # minimised: some window managers (Cinnamon, GNOME) keep it mapped
        x, y, child = _c.c_int(), _c.c_int(), Window()
        _x11.XTranslateCoordinates(self.d, window, self.root, 0, 0, _c.byref(x), _c.byref(y), _c.byref(child))
        return x.value, y.value, attrs.width, attrs.height

    def top_level_windows(self):
        root, parent, children, count = Window(), Window(), _c.POINTER(Window)(), _c.c_uint()
        if not _x11.XQueryTree(self.d, self.root, _c.byref(root), _c.byref(parent), _c.byref(children), _c.byref(count)):
            return []
        try:
            return [children[i] for i in range(count.value)]
        finally:
            if children:
                _x11.XFree(children)

    def windows_of(self, pgid):
        if self.private:  # no window manager here, and nothing else runs on this screen
            yield from self.top_level_windows()
            return
        for window in self.prop(self.root, "_NET_CLIENT_LIST"):
            pids = self.prop(window, "_NET_WM_PID")
            if pids and _pgid(pids[0]) == pgid:
                yield window

    def pgid_of(self, window):
        pids = self.prop(window, "_NET_WM_PID")
        return _pgid(pids[0]) if pids else None

    def active_window(self):
        active = self.prop(self.root, "_NET_ACTIVE_WINDOW")
        return active[0] if active else 0

    def activate(self, window):
        if self.private:  # no window manager: raise and focus it ourselves
            _x11.XRaiseWindow(self.d, window)
            _x11.XSetInputFocus(self.d, window, REVERT_TO_PARENT, 0)
            _x11.XFlush(self.d)
            return
        event = XEvent()
        msg = event.xclient
        msg.type = CLIENT_MESSAGE
        msg.window = window
        msg.message_type = self.atom("_NET_ACTIVE_WINDOW")
        msg.format = 32
        msg.data[0] = 2  # source indication: pager/tool, which window managers honour
        _x11.XSendEvent(self.d, self.root, 0, SUBSTRUCTURE_REDIRECT_AND_NOTIFY, _c.byref(event))
        _x11.XFlush(self.d)

    def key(self, keysym, down):
        code = _x11.XKeysymToKeycode(self.d, keysym)
        if code:
            _xtst.XTestFakeKeyEvent(self.d, code, int(down), 0)

    def button(self, button, down):
        _xtst.XTestFakeButtonEvent(self.d, button, int(down), 0)

    def move(self, x, y):
        _xtst.XTestFakeMotionEvent(self.d, -1, x, y, 0)

    def flush(self):
        _x11.XFlush(self.d)

    def cursor_hidden(self):
        """Whether the pointer currently shows no cursor at all: games that don't
        use the mouse (Deltarune, most console-style games) hide it over their window."""
        if not _xfixes:
            return False
        image = _xfixes.XFixesGetCursorImage(self.d)
        if not image:
            return False
        try:
            img = image.contents
            return not any(img.pixels[i] >> 24 & 0xFF for i in range(img.width * img.height))  # all transparent
        finally:
            _x11.XFree(image)

    def close(self):
        _x11.XCloseDisplay(self.d)


class FrameCounter(threading.Thread):
    """Measures the game's real frame rate: how many times a second it draws a
    new picture into its window (X Damage events), independent of how often
    the stream samples the screen. A game that repeats the same picture, or
    shows a still menu, draws nothing and counts nothing."""

    def __init__(self, display):
        super().__init__(name="frame-counter", daemon=True)
        self.fps = None
        self.want = self.window = self.damage = 0
        self.stopping = False
        self.d = _x11.XOpenDisplay(display.encode()) if _xdamage else None
        event_base, error_base = _c.c_int(), _c.c_int()
        if self.d and not _xdamage.XDamageQueryExtension(self.d, _c.byref(event_base), _c.byref(error_base)):
            _x11.XCloseDisplay(self.d)
            self.d = None
        self.notify = event_base.value  # XDamageNotify is the extension's first event

    def watch(self, window):
        self.want = window

    def stop(self):
        self.stopping = True

    def run(self):
        if not self.d:
            return
        fd = _x11.XConnectionNumber(self.d)
        event = XEvent()
        count, since = 0, time.monotonic()
        try:
            while not self.stopping:
                if self.want != self.window:
                    if self.damage:
                        _xdamage.XDamageDestroy(self.d, self.damage)
                    self.window = self.want
                    self.damage = _xdamage.XDamageCreate(self.d, self.window, DAMAGE_REPORT_NON_EMPTY)
                    _x11.XFlush(self.d)
                if not _x11.XPending(self.d):
                    select.select([fd], [], [], 0.1)
                while _x11.XPending(self.d):
                    _x11.XNextEvent(self.d, _c.byref(event))
                    if event.xclient.type == self.notify:
                        count += 1
                        _xdamage.XDamageSubtract(self.d, self.damage, 0, 0)  # re-arm for the next frame
                _x11.XFlush(self.d)
                now = time.monotonic()
                if now - since >= 1.0:
                    self.fps = round(count / (now - since)) if self.window else None
                    count, since = 0, now
        finally:
            if self.damage:
                _xdamage.XDamageDestroy(self.d, self.damage)
            _x11.XCloseDisplay(self.d)


def command_for(launch):
    path, runner = launch["path"], launch["runner"]
    if runner == "epic":  # path is the Epic app name; it runs with Wine like any Windows game
        wine = shutil.which("wine")
        if not wine:
            raise LaunchError("no_wine")
        if not epic.available():
            raise LaunchError("no_legendary")
        try:
            info = epic.launch_info(path)  # (also signs in to Epic for the game, which most need)
        except (OSError, subprocess.SubprocessError) as e:
            log.warning("Epic game %s couldn't start: %s", path, e)
            raise LaunchError("epic_failed") from None
        exe = info.get("game_executable") or ""
        folder = info.get("game_directory") or ""
        if not os.path.isabs(exe):
            exe = os.path.join(folder, exe)
        launch["cwd"] = info.get("working_directory") or os.path.dirname(exe)
        launch["env"] = {k: str(v) for k, v in (info.get("environment") or {}).items()}
        return [wine, exe, *info.get("game_parameters", []), *info.get("egl_parameters", []), *info.get("user_parameters", [])]
    if runner == "flatpak":  # path is the Flathub app id
        if not re.match(r"^[A-Za-z0-9_.-]+$", path):
            raise LaunchError("launch_failed")
        return ["flatpak", "run", path]
    if runner == "console":  # a PlayStation, streamed through chiaki-ng
        target = json.loads(path)
        if not console.installed():
            raise LaunchError("no_chiaki")
        return console.launch_command(target["nickname"], target["address"])
    if runner == "steam":  # path is the Steam appid
        if not steam.available():
            raise LaunchError("no_steam")
        if steam.running_pid():  # one Steam client per account: it can't also run for CloudPlay
            raise LaunchError("steam_running")
        return steam.launch_command(path, launch.get("args", []))
    if not os.path.isfile(path):
        raise LaunchError("game_missing")
    if runner == "wine":
        wine = shutil.which("wine")
        if not wine:
            raise LaunchError("no_wine")
        return [wine, path, *launch.get("args", [])]
    return [path, *launch.get("args", [])]


# Private data a game has no business reading: browser profiles (passwords,
# cookies), keyrings, SSH/GPG keys, and CloudPlay's own accounts database.
# Games see empty folders there; the rest of the home folder (their saves,
# settings, Wine prefix) stays as it is.
PRIVATE_PATHS = [
    "~/.ssh", "~/.gnupg", "~/.password-store", "~/.pki", "~/.local/share/keyrings",
    "~/.mozilla", "~/.thunderbird", "~/.config/BraveSoftware", "~/.config/google-chrome",
    "~/.config/chromium", "~/.config/microsoft-edge", "~/.config/vivaldi", "~/.config/opera",
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),  # CloudPlay itself
    "~/.local/share/cloudplay/data",  # accounts database, pictures (when installed with install.sh)
    str(epic.CONFIG),  # the Epic account's sign-in
]


# Runs as the first process in a game's sandbox. Many games start through a
# launcher that opens the real game (e.g. Deltarune's chapter select) and then
# exits; the sandbox would end with that launcher and take the game with it.
# This becomes the "subreaper" for everything the game starts, so orphaned
# processes stay its children, and only exits once all of them have.
SUPERVISOR = """
import ctypes, os, sys
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)  # PR_SET_CHILD_SUBREAPER
if os.fork() == 0:
    os.execvp(sys.argv[1], sys.argv[1:])
while True:
    try:
        os.wait()
    except ChildProcessError:
        break
"""


def sandboxed(cmd, devices):
    """Run a game on a hidden screen in a bubblewrap sandbox of its own, so
    several games can run side by side without mixing up their controllers:

    - /dev/input holds only this game's own virtual controller;
    - Wine's server directory is private, so the game gets its own wineserver
      (and the winedevice process that reads controllers) inside the sandbox
      instead of sharing one with every other Wine game;
    - it has its own process list, so everything it starts, Wine's background
      processes included, ends with it;
    - PRIVATE_PATHS are hidden;
    - it lasts until every program the game started has exited (SUPERVISOR).

    Everything else (files, GPU, X, sound) is the host's as usual."""
    bwrap = shutil.which("bwrap")
    if not bwrap:
        log.warning("bubblewrap not installed: games share controllers and Wine processes")
        return cmd
    # Where Wine keeps its server socket: $XDG_RUNTIME_DIR/wine (Wine 9+), else /tmp/.wine-UID.
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    wine_dir = os.path.join(runtime, "wine") if runtime else f"/tmp/.wine-{os.getuid()}"
    args = [bwrap, "--dev-bind", "/", "/", "--tmpfs", "/dev/input", "--perms", "0700", "--tmpfs", wine_dir]
    for path in map(os.path.expanduser, PRIVATE_PATHS):
        if os.path.isdir(path):
            args += ["--perms", "0700", "--tmpfs", path]
    for device in devices:
        args += ["--dev-bind", device, device]
    return [*args, "--unshare-pid", "--die-with-parent", "--", sys.executable, "-c", SUPERVISOR, *cmd]


def with_gpu(cmd):
    """Xvfb screens can't reach the graphics card, so OpenGL would be drawn on
    the CPU. VirtualGL, when installed, renders on the GPU instead and copies
    each finished frame onto the hidden screen."""
    vglrun = shutil.which("vglrun")
    if not vglrun:
        log.info("VirtualGL not installed: games on hidden screens are drawn by the CPU")
        return cmd
    return [vglrun, "-d", "egl", *cmd]


# Colour conversion and scaling before the encoder. On the CPU it works at any
# size but costs a lot: with a busy game it can't keep up with 1080p60, and the
# stream drops frames while the game itself still runs at 60. The GPU converter
# (vapostproc) is far cheaper but shears the picture at some widths (330, 1008,
# 1164 px...), so it's only used where it's safe: widths in multiples of 64,
# like the usual full-screen sizes (1920, 1280). Queues put capture, conversion
# and encoding on separate threads.
CPU_CONVERT = (
    "queue max-size-buffers=2 leaky=downstream ! videoconvertscale n-threads=4 ! "
    "video/x-raw,format={fmt},width={w},height={h} ! queue max-size-buffers=2 ! "
)
GPU_CONVERT = (
    "queue max-size-buffers=2 leaky=downstream ! vapostproc ! "
    "video/x-raw(memory:VAMemory),format=NV12,width={w},height={h} ! queue max-size-buffers=2 ! "
)
GPU_SAFE_WIDTH = 64


def gpu_convert_safe(in_w, out_w):
    return in_w % GPU_SAFE_WIDTH == 0 and out_w % GPU_SAFE_WIDTH == 0


def h264_encoder():
    """The best H.264 encoder GStreamer has here, as a pipeline template, or None.
    Intel/AMD GPUs encode through VA-API; otherwise x264 does it on the CPU."""
    have = lambda *names: all(Gst.ElementFactory.find(n) for n in names)  # noqa: E731
    if not have("h264parse"):
        return None
    convert = CPU_CONVERT
    for enc in ("vah264lpenc", "vah264enc"):
        if have(enc):
            return convert.replace("{fmt}", "NV12") + (
                f"{enc} name=enc bitrate={{kbps}} rate-control=cbr key-int-max={{gop}} b-frames=0"
            )
    if have("x264enc"):
        return convert.replace("{fmt}", "I420") + (
            "x264enc name=enc tune=zerolatency speed-preset=ultrafast bitrate={kbps} key-int-max={gop} bframes=0"
        )
    return None


class DesktopGame:
    """Same interface as the built-in games (accepts / on_input / next_frame),
    plus mouse input and close().

    With codec "h264" (when an encoder is available) next_frame returns a list
    of (kind, data) chunks, every one of which must reach the browser in order;
    otherwise it returns the newest JPEG, like the built-in games."""

    def __init__(self, launch, display, title, codec="jpeg", audio_codec=None, gamepad=True, quality="best"):
        """display is the host's desktop to show the game on, or None to give
        it a hidden screen of its own. audio_codec ("opus" or "pcm") gives the
        game its own sound device, captured for the stream."""
        cmd = command_for(launch)
        self.encoder = h264_encoder() if codec == "h264" else None
        self.codec = "h264" if self.encoder else "jpeg"
        if self.encoder:  # (the bitrate follows from size and frame rate)
            self.max_w, self.max_h, self.fps = QUALITY.get(quality, QUALITY["best"])
        else:
            self.max_w, self.max_h, self.fps = JPEG_W, JPEG_H, JPEG_FPS
        self.screen = VirtualScreen() if display is None else None
        if self.screen:
            display = self.screen.name
            if not self.screen.gpu:
                cmd = with_gpu(cmd)
        self.display = display
        try:
            self.x = X11(display, private=self.screen is not None)
        except LaunchError:
            if self.screen:
                self.screen.close()
            raise
        env = dict(os.environ, DISPLAY=display)
        if self.screen:
            env.pop("WAYLAND_DISPLAY", None)  # games must draw on the X screen we capture
        if launch["runner"] in ("wine", "epic"):
            env.update(wine.game_env())  # CloudPlay's own prefix, with DXVK and VKD3D-Proton
        env.update(launch.get("env") or {})  # (what an Epic game asks for)
        self.audio = audio.GameAudio(audio_codec) if audio_codec in audio.CODECS else None
        if self.audio:
            env.update(self.audio.env)
        # Before the game starts (many only look for controllers then), and only if
        # the player has a gamepad: games switch their hints to controller buttons
        # as soon as they see one.
        self.pad = pad.VirtualPad(create=gamepad)
        # Not on the host's desktop (games are found by PID there, which a sandbox
        # would hide), nor for Steam: it runs its own container for games, has to
        # see its own processes, and only one Steam session can run anyway.
        self.steam_appid = int(launch["path"]) if launch["runner"] == "steam" else None
        self.steam_started = False
        # (chiaki-ng is a Flatpak, which runs in a sandbox of its own)
        if self.screen and launch["runner"] not in ("steam", "console", "flatpak"):
            cmd = sandboxed(cmd, self.pad.nodes)
        try:
            self.proc = subprocess.Popen(
                cmd, cwd=launch.get("cwd") or (os.path.dirname(launch["path"]) if launch["runner"] in ("wine", "native")
                                               else os.path.expanduser("~")),
                env=env,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True,  # own process group: find its windows, kill it cleanly
            )
        except OSError as e:
            self.x.close()
            self.pad.close()
            if self.audio:
                self.audio.close()
            if self.screen:
                self.screen.close()
            raise LaunchError("launch_failed") from e
        log.info("launched %s (pid %d)", cmd, self.proc.pid)
        self.pgid = self.proc.pid
        self.lock = threading.RLock()
        self.window = None
        self.geom = None
        self.pipeline = self.sink = self.enc = None
        self.quality = 70
        self.held_keys = set()
        self.held_buttons = set()
        self.last_frame = _placeholder(f"Launching {title}…")
        self.minimised = False
        self.placeholder_sent = 0.0
        self.cursor_hidden = False  # the game hides its mouse cursor: the browser should too
        self.next_cursor_check = 0.0
        self.next_check = 0.0
        self.closed = False
        self.frames = FrameCounter(display)
        self.frames.start()

    @property
    def game_fps(self):
        """Frames per second the game really draws (None if unknown)."""
        return None if self.minimised or self.window is None else self.frames.fps

    # --- frames ---------------------------------------------------------

    def next_frame(self, dt, quality):
        with self.lock:
            if self.closed:
                return self._no_video()
            now = time.monotonic()
            if now >= self.next_check:
                self.next_check = now + 0.5
                if not self._alive():
                    raise GameExited()
                self._track_window()
            if now >= self.next_cursor_check and self.geom is not None:
                self.next_cursor_check = now + 0.1
                self.cursor_hidden = self.x.cursor_hidden()
            if self.sink is None:
                return self._no_video()
            if not self.encoder and quality != self.quality:
                self.quality = quality
                self.enc.set_property("quality", quality)
            sink = self.sink
        if self.encoder:
            return self._pull_video(sink)
        sample = sink.try_pull_sample(Gst.SECOND // 10)  # outside the lock so input isn't held up
        if sample is not None:
            buf = sample.get_buffer()
            ok, info = buf.map(Gst.MapFlags.READ)
            if ok:
                try:
                    self.last_frame = bytes(info.data)
                finally:
                    buf.unmap(info)
        return self.last_frame

    def _no_video(self):
        """Nothing is being captured: show the placeholder (launching, paused)."""
        if not self.encoder:
            return self.last_frame
        now = time.monotonic()
        if now - self.placeholder_sent < 1.0:
            time.sleep(1 / self.fps)  # keep the session loop from spinning
            return []
        self.placeholder_sent = now
        return [(FRAME_JPEG, self.last_frame)]

    def _pull_video(self, sink):
        """Every encoded frame since the last call; waits up to one frame for the first."""
        chunks = []
        timeout = Gst.SECOND // self.fps
        while True:
            sample = sink.try_pull_sample(timeout)
            if sample is None:
                return chunks
            timeout = 0
            buf = sample.get_buffer()
            ok, info = buf.map(Gst.MapFlags.READ)
            if ok:
                try:
                    delta = buf.has_flags(Gst.BufferFlags.DELTA_UNIT)
                    chunks.append((FRAME_DELTA if delta else FRAME_KEY, bytes(info.data)))
                finally:
                    buf.unmap(info)

    def on_pad(self, buttons, sticks, triggers):
        with self.lock:
            if not self.closed:
                self.pad.update(buttons, sticks, triggers)

    def pull_audio(self):
        """The game's sound since the last call, as encoded packets."""
        return self.audio.pull() if self.audio else []

    def request_keyframe(self):
        """The browser lost frames (or is just joining): start a fresh picture."""
        with self.lock:
            if self.sink is not None and self.encoder:
                self.sink.send_event(GstVideo.video_event_new_upstream_force_key_unit(Gst.CLOCK_TIME_NONE, True, 0))

    def _alive(self):
        if self.steam_appid:
            # Steam stays up after the game closes, so look for the game itself.
            if steam.game_running(self.display, self.steam_appid):
                self.steam_started = True
            elif self.steam_started:
                return False
        self.proc.poll()  # reap the leader so a zombie doesn't keep the group "alive"
        try:
            os.killpg(self.pgid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True

    def _track_window(self):
        if self.pipeline is not None:
            error = self.pipeline.get_bus().pop_filtered(Gst.MessageType.ERROR)
            if error is not None:
                log.warning("capture error: %s", error.parse_error()[0].message)
                self._stop_pipeline()
        windows = list(self.x.windows_of(self.pgid))
        candidates = []
        for window in windows:
            g = self._clip(self.x.geometry(window))
            if g:
                candidates.append((g[2] * g[3], window, g))
        if not candidates:
            if self.window in windows:
                self._minimise()
            return  # splash screen gone, main window not up yet: keep showing the last frame
        if self.minimised:
            log.info("game window restored")
            self.minimised = False
        _, window, g = max(candidates)
        if window != self.window:
            self.window = window
            self.x.activate(window)
            self.frames.watch(window)
        if g != self.geom:
            self._start_pipeline(g)

    def _minimise(self):
        """The game window was minimised on the host: stop capturing that patch
        of screen (it now shows other apps) and leave the pointer alone until
        someone at the host restores it."""
        if self.minimised:
            return
        self.minimised = True
        log.info("game window minimised; input paused")
        self._stop_pipeline()
        self._release_all()
        self.x.flush()
        self.last_frame = _minimised_frame()

    def _release_all(self):
        for key in self.held_keys:  # never leave a key stuck down on the desktop
            self.x.key(KEYSYMS[key], False)
        for button in self.held_buttons:
            self.x.button(button, False)
        self.held_keys.clear()
        self.held_buttons.clear()

    def _clip(self, g):
        if not g:
            return None
        x, y, w, h = g
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(self.x.width, x + w), min(self.x.height, y + h)
        if x1 - x0 < MIN_WINDOW or y1 - y0 < MIN_WINDOW:
            return None
        return x0, y0, x1 - x0, y1 - y0

    def _start_pipeline(self, g):
        self._stop_pipeline()
        x, y, w, h = g
        scale = min(self.max_w / w, self.max_h / h, 1.0)
        out_w, out_h = max(2, int(w * scale) // 2 * 2), max(2, int(h * scale) // 2 * 2)
        source = (
            f'ximagesrc display-name="{self.display}" use-damage=false show-pointer=false '
            f"startx={x} starty={y} endx={x + w - 1} endy={y + h - 1} ! video/x-raw,framerate={self.fps}/1 ! "
        )
        on_gpu = False
        if self.encoder:
            kbps = max(1000, int(out_w * out_h * self.fps * BITS_PER_PIXEL / 1000))
            template = self.encoder
            on_gpu = ("vah264" in template and Gst.ElementFactory.find("vapostproc") is not None
                      and gpu_convert_safe(w, out_w))
            if on_gpu:
                template = template.replace(CPU_CONVERT.replace("{fmt}", "NV12"), GPU_CONVERT)
            encode = template.format(w=out_w, h=out_h, kbps=kbps, gop=self.fps * 2)
            # Every frame must reach the browser, so the sink never drops; a
            # slow link is handled by the host skipping to the next keyframe.
            sink = (
                "h264parse config-interval=-1 ! video/x-h264,stream-format=byte-stream,alignment=au ! "
                "appsink name=sink max-buffers=30 drop=false sync=false"
            )
            pipeline = Gst.parse_launch(f"{source}{encode} ! {sink}")
        else:
            pipeline = Gst.parse_launch(
                f"{source}videoconvert ! videoscale method=bilinear ! "
                f"video/x-raw,width={out_w},height={out_h} ! jpegenc name=enc quality={self.quality} ! "
                "appsink name=sink max-buffers=1 drop=true sync=false"
            )
        pipeline.set_state(Gst.State.PLAYING)
        self.pipeline, self.sink, self.enc = pipeline, pipeline.get_by_name("sink"), pipeline.get_by_name("enc")
        self.geom = g
        log.info("capturing game window %#x at %s → %dx%d %s @ %d fps%s", self.window, g, out_w, out_h, self.codec, self.fps,
                 " (converted on the GPU)" if self.encoder and on_gpu else "")

    def _stop_pipeline(self):
        if self.pipeline is not None:
            self.pipeline.set_state(Gst.State.NULL)
        self.pipeline = self.sink = self.enc = None
        self.geom = None

    # --- input ----------------------------------------------------------

    def accepts(self, key):
        return key in KEYSYMS

    def _focused(self, activate=True):
        """True if the game has focus. If not, ask the window manager to give it
        focus (unless activate is False) and drop this input rather than sending
        it to some other app. A minimised game never grabs focus back."""
        if self.window is None or self.minimised:
            return False
        if self.x.private:
            return True  # its own hidden screen: input can't reach anything else
        active = self.x.active_window()
        if active and (active == self.window or self.x.pgid_of(active) == self.pgid):
            return True
        if activate:
            self.x.activate(self.window)
        return False

    def on_input(self, key, down):
        with self.lock:
            if self.closed:
                return
            if down:
                if self.geom is None or key in self.held_keys or not self._focused():
                    return
                self.held_keys.add(key)
            elif key in self.held_keys:
                self.held_keys.discard(key)
            else:
                return
            self.x.key(KEYSYMS[key], down)
            self.x.flush()

    def on_mouse(self, kind, *args):
        with self.lock:
            if self.closed or self.geom is None:
                return
            if kind == "move":
                if not self._focused(activate=False):
                    return  # pointer moves alone don't pull the game forward or steal the cursor
                gx, gy, gw, gh = self.geom
                self.x.move(gx + round(args[0] * (gw - 1)), gy + round(args[1] * (gh - 1)))
            elif kind == "button":
                button, down = args
                if down:
                    if button in self.held_buttons or not self._focused():
                        return
                    self.held_buttons.add(button)
                elif button in self.held_buttons:
                    self.held_buttons.discard(button)
                else:
                    return
                self.x.button(button, down)
            elif kind == "wheel" and self._focused():
                button = 4 if args[0] < 0 else 5
                self.x.button(button, True)
                self.x.button(button, False)
            self.x.flush()

    # --- shutdown -------------------------------------------------------

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            self._release_all()
            self.pad.close()
            self.x.flush()
            self._stop_pipeline()
            self.frames.stop()
            self.x.close()
        self.frames.join(2)  # its X connection must close before the screen goes away
        try:
            if self.steam_appid:
                self._stop_steam()
            self._kill_game()
        finally:
            if self.audio:
                self.audio.close()
            if self.screen:
                self.screen.close()

    def _stop_steam(self):
        """Ask Steam to quit (closing the game), then end anything it left on
        this session's hidden screen."""
        try:
            subprocess.run(steam.shutdown_command(), timeout=15, stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (OSError, subprocess.TimeoutExpired):
            pass
        deadline = time.monotonic() + 15
        while self._alive() and time.monotonic() < deadline:
            time.sleep(0.2)
        if self.screen:  # everything still attached to our private screen belongs to this session
            for pid in steam.processes_on_display(self.display):
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass

    def _kill_game(self):
        try:
            os.killpg(self.pgid, signal.SIGTERM)
        except ProcessLookupError:
            return
        deadline = time.monotonic() + KILL_GRACE_SECONDS
        while time.monotonic() < deadline:
            if not self._alive():
                return
            time.sleep(0.1)
        try:
            os.killpg(self.pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        self.proc.poll()


@functools.cache
def _minimised_frame():
    return _placeholder("Paused: the game is minimised on the host computer")


@functools.lru_cache(maxsize=None)
def font(size):
    try:
        return ImageFont.load_default(size=size)
    except Exception:  # Pillow without FreeType only ships the fixed bitmap font
        return ImageFont.load_default()


def _placeholder(text):
    img = Image.new("RGB", (JPEG_W, JPEG_H), "#0a0a12")
    d = ImageDraw.Draw(img)
    f = font(36)
    left, top, right, bottom = d.textbbox((0, 0), text, font=f)
    d.text(((JPEG_W - (right - left)) / 2, (JPEG_H - (bottom - top)) / 2), text, font=f, fill="#ececf4")
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=80)
    return buf.getvalue()
