"""CloudPlay stream host: runs game instances and streams them to browsers.

Each session is one imported PC game (host/desktop.py), launched on a hidden
screen of its own (or on the host's desktop with --on-screen); its window is
captured and pushed over a WebSocket, and input arrives as small JSON messages
on the same socket.

Browsers that can decode H.264 (WebCodecs) get 1080p60 H.264, encoded on the
GPU when possible. Those frames depend on each other, so they're all sent in
order; when the link falls behind, the backlog is dropped and the stream
resumes at a fresh keyframe. Other browsers get JPEG frames: only the newest
is ever sent, so a slow connection drops frames instead of building up
latency, and JPEG quality adapts to how many are dropped.

Production note: a real GPU host would move from WebSocket to WebRTC for
lower latency. The session/ticket/heartbeat contract with the control plane
stays the same.
"""
import argparse
import asyncio
import collections
import hmac
import json
import logging
import os
import secrets
import signal
import socket
import struct
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qs, urlparse

import websockets

from common import tickets

log = logging.getLogger("cloudplay.host")

FPS = 30
HEARTBEAT_INTERVAL = 5
IDLE_TIMEOUT = 15 * 60  # no keys, mouse or gamepad for this long frees the game and GPU
QUALITY_MIN, QUALITY_MAX, QUALITY_START = 35, 80, 70


class Session:
    def __init__(self, claims, game):
        self.id = claims["sid"]
        self.game_slug = claims["game"]
        self.game = game
        self.video = getattr(game, "codec", "jpeg") == "h264"
        self.fps = getattr(game, "fps", FPS)
        self.chunks = collections.deque()  # H.264 frames waiting to be sent, in order
        self.audio = collections.deque()  # sound packets waiting to be sent, in order
        self.notices = collections.deque()  # small JSON messages for the browser, e.g. cursor changes
        self.cursor_hidden = False
        self.inputs = collections.deque()  # filled on the event loop, drained in the worker thread
        self.quality = QUALITY_START
        self.seq = 0
        # The CloudPlay app can show the video natively: it then takes the video
        # over a second connection, opened with this key (sent only to the player).
        self.video_key = None
        self.video_ws = None
        self.encoded = 0  # video frames the encoder has made, for the fps the server sends
        self.encoded_seen = (time.monotonic(), 0)
        self.latest = b""
        self.frame_ready = asyncio.Event()
        self.started = self.last_input = time.monotonic()
        self.end_reason = None
        self.done = asyncio.Event()

    def tick(self, dt):
        """Advance the game and encode a frame. Runs in a worker thread."""
        while self.inputs:
            kind, *args = self.inputs.popleft()
            if kind == "key":
                self.game.on_input(*args)
            elif kind == "keyframe":
                self.game.request_keyframe()
            elif kind == "pad":
                self.game.on_pad(*args)
            else:
                self.game.on_mouse(kind, *args)
        frame = self.game.next_frame(dt, self.quality)
        self.audio.extend(self.game.pull_audio())
        if self.game.cursor_hidden != self.cursor_hidden:
            self.cursor_hidden = self.game.cursor_hidden
            self.notices.append({"t": "cursor", "hidden": self.cursor_hidden})
        return frame

    def sent_fps(self):
        if not self.video:
            return None
        now = time.monotonic()
        then, count = self.encoded_seen
        self.encoded_seen = (now, self.encoded)
        return round((self.encoded - count) / (now - then)) if now > then else None

    def end(self, reason):
        if self.end_reason is None:
            self.end_reason = reason
            self.done.set()


class Host:
    def __init__(
        self, host_id, secret, control_url, public_url=None, capacity=4, region="local",
        pc_games=True, desktop_display=None,
    ):
        """PC games run on hidden screens, or on desktop_display (the host's own
        desktop, e.g. ":0") when it's given."""
        self.host_id = host_id
        self.ticket_key = tickets.derive(secret, "ticket")
        self.host_token = tickets.derive(secret, "host-auth")
        self.control_url = control_url.rstrip("/")
        self.public_url = public_url
        self.capacity = capacity
        self.region = region
        self.sessions = {}
        self.redeemed = {}  # sid -> ticket expiry, so a ticket can't be replayed
        self.ended = []  # finished sessions not yet acknowledged by the control plane
        self.pool = ThreadPoolExecutor(max_workers=max(2, capacity), thread_name_prefix="encode")
        self.desktop = None  # the host.desktop module, when PC games are enabled
        self.desktop_display = desktop_display
        self.desktop_busy = False  # the host's desktop fits one PC game at a time
        if pc_games:
            try:
                from host import audio, desktop

                self.desktop = desktop
                audio.remove_stale()  # sound devices left behind by a crashed server
            except Exception as e:  # no X11 / GStreamer on this machine
                log.warning("PC games disabled: %s", e)

    async def start(self, bind, port):
        server = await websockets.serve(
            self.handle, bind, port, max_size=4096, compression=None, ping_interval=10, ping_timeout=20
        )
        if self.public_url is None:
            actual = server.sockets[0].getsockname()[1]
            self.public_url = f"ws://localhost:{actual}"
        return server

    async def handle(self, ws, path):
        query = parse_qs(urlparse(path).query)
        if urlparse(path).path == "/video":
            await self._attach_video(ws, query)
            return
        try:
            claims = tickets.verify(query.get("ticket", [""])[0], self.ticket_key)
        except tickets.TicketError as e:
            await ws.close(4401, str(e))
            return
        launch = claims.get("launch")
        if claims.get("host") != self.host_id or not launch:
            await ws.close(4403, "ticket is for another host")
            return
        if claims["sid"] in self.redeemed:
            await ws.close(4409, "ticket already used")
            return
        if len(self.sessions) >= self.capacity:
            await ws.close(4503, "host full")
            return
        if not self.desktop:
            await ws.close(4503, "this host can't run PC games")
            return
        if self.desktop_display:
            # One game at a time on the host's desktop; the previous one may still be shutting down.
            for _ in range(30):
                if not self.desktop_busy:
                    break
                await asyncio.sleep(0.2)
            else:
                await ws.close(4503, "another PC game is running")
                return
            self.desktop_busy = True

        self.redeemed[claims["sid"]] = claims["exp"]
        loop = asyncio.get_running_loop()
        # What the browser can decode.
        codec = "h264" if query.get("video") == ["h264"] else "jpeg"
        audio_codec = query.get("audio", [None])[0]  # "opus", "pcm", or no sound
        # The player has a gamepad: a virtual one of the same kind (Xbox, PlayStation, Nintendo).
        gamepad = (query.get("padkind", ["xbox"])[0] if query.get("padkind", ["xbox"])[0] in ("xbox", "playstation", "nintendo")
                   else "xbox") if query.get("pad") == ["1"] else False
        quality = query.get("quality", ["best"])[0]  # their stream quality setting
        try:
            game = await loop.run_in_executor(None, self._make_game, claims, codec, audio_codec, gamepad, quality)
        except Exception as e:
            reason = getattr(e, "reason", "launch_failed")
            log.warning("session %s could not start: %s", claims["sid"], reason)
            self.desktop_busy = False
            self.ended.append({"sid": claims["sid"], "seconds": 0, "reason": reason})
            try:
                await ws.send(json.dumps({"t": "end", "reason": reason}))
                await ws.close(1000, reason)
            except websockets.ConnectionClosed:
                pass
            return
        s = Session(claims, game)
        if s.video and query.get("native") == ["1"]:
            s.video_key = secrets.token_urlsafe(24)
        self.sessions[s.id] = s
        log.info("session %s started (%s)", s.id, claims.get("title") or s.game_slug)

        tasks = [asyncio.create_task(self._guard(s, c)) for c in (self._run(s), self._send(ws, s), self._recv(ws, s))]
        await s.done.wait()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if s.video_ws is not None:
            await s.video_ws.close(1000, "game ended")

        played = time.monotonic() - s.started
        await loop.run_in_executor(None, s.game.close)
        self.desktop_busy = False
        del self.sessions[s.id]
        self.ended.append({"sid": s.id, "seconds": round(played, 1), "reason": s.end_reason})
        log.info("session %s ended after %.0fs: %s", s.id, played, s.end_reason)
        if ws.open:
            try:
                await ws.send(json.dumps({"t": "end", "reason": s.end_reason}))
                await ws.close(1000, s.end_reason)
            except websockets.ConnectionClosed:
                pass

    def _make_game(self, claims, codec, audio_codec, gamepad, quality):
        return self.desktop.DesktopGame(
            claims["launch"], self.desktop_display, claims.get("title") or "game", codec, audio_codec, gamepad, quality
        )

    async def _guard(self, s, coro):
        try:
            await coro
        except asyncio.CancelledError:
            raise
        except websockets.ConnectionClosed:
            s.end("disconnected")
        except Exception:
            log.exception("session %s crashed", s.id)
            s.end("error")
        else:
            s.end("disconnected")

    async def _run(self, s):
        loop = asyncio.get_running_loop()
        period = 1 / s.fps
        last = time.monotonic()
        while True:
            now = time.monotonic()
            if now - s.last_input >= IDLE_TIMEOUT:
                s.end("idle")
                return
            try:
                frame = await loop.run_in_executor(self.pool, s.tick, min(now - last, 0.1))
            except Exception as e:
                if not isinstance(e, self.desktop.GameExited):
                    raise
                s.end("game_exited")
                return
            last = now
            if s.video:
                s.chunks.extend(frame)
                s.encoded += len(frame)
                if frame or s.audio or s.notices:
                    s.frame_ready.set()
                continue  # pulling from the encoder already waited for the next frame
            s.seq += 1
            s.latest = frame
            s.frame_ready.set()
            await asyncio.sleep(max(0.0, period - (time.monotonic() - now)))

    async def _send(self, ws, s):
        await ws.send(json.dumps({
            "t": "hello", "w": s.game.max_w, "h": s.game.max_h, "fps": s.fps, "codec": "h264" if s.video else "jpeg",
            "pad": s.game.pad.available,  # a real (virtual) controller, rather than gamepad-as-keys
            "video_key": s.video_key,  # for the app's native video connection (see _attach_video)
        }))
        if s.video:
            await self._send_video(ws, s)
            return
        sent = 0
        while True:
            await s.frame_ready.wait()
            s.frame_ready.clear()
            await self._send_audio(ws, s)
            seq, data = s.seq, s.latest
            if seq - sent > 1:  # frames were skipped: the link can't keep up
                s.quality = max(QUALITY_MIN, s.quality - 5)
            elif seq % FPS == 0:
                s.quality = min(QUALITY_MAX, s.quality + 1)
            await ws.send(struct.pack(">IB", seq, self.desktop.FRAME_JPEG) + data)
            sent = seq

    async def _send_audio(self, ws, s):
        while s.notices:
            await ws.send(json.dumps(s.notices.popleft()))
        # Sound is small and never skipped; the browser plays it in order.
        while s.audio:
            await ws.send(struct.pack(">IB", 0, self.desktop.AUDIO) + s.audio.popleft())

    async def _send_video(self, ws, s):
        key = self.desktop.FRAME_KEY
        delta = self.desktop.FRAME_DELTA
        waiting_for_key = True  # the browser can only start decoding at a keyframe
        target = ws
        while True:
            await s.frame_ready.wait()
            s.frame_ready.clear()
            await self._send_audio(ws, s)
            if (s.video_ws or ws) is not target:  # the app's native video took over, or let go
                target = s.video_ws or ws
                waiting_for_key = True
                s.inputs.append(("keyframe",))
            if len(s.chunks) > s.fps // 2:  # over half a second behind: skip ahead
                s.chunks.clear()
                waiting_for_key = True
                s.inputs.append(("keyframe",))
                continue
            while s.chunks:
                kind, data = s.chunks.popleft()
                if kind == delta and waiting_for_key:
                    continue
                if kind == key:
                    waiting_for_key = False
                s.seq += 1
                frame = struct.pack(">IB", s.seq, kind) + data
                if target is ws:
                    await ws.send(frame)
                    continue
                try:
                    await target.send(frame)
                except websockets.ConnectionClosed:  # the native video went away: back to the page
                    if s.video_ws is target:
                        s.video_ws = None
                    s.chunks.clear()
                    break

    async def _attach_video(self, ws, query):
        """The CloudPlay app's native video: the session's video goes here instead
        of to the page, while this connection lasts."""
        s = self.sessions.get(query.get("session", [""])[0])
        key = query.get("key", [""])[0]
        if not s or not s.video_key or not hmac.compare_digest(key, s.video_key):
            await ws.close(4403, "not allowed")
            return
        if s.video_ws is not None:
            await s.video_ws.close(1000, "replaced")
        s.video_ws = ws
        log.info("session %s: video shown natively by the app", s.id)
        try:
            await ws.wait_closed()
        finally:
            if s.video_ws is ws:
                s.video_ws = None
                log.info("session %s: native video closed, the page shows it again", s.id)

    async def _recv(self, ws, s):
        async for raw in ws:
            if not isinstance(raw, str):
                continue
            try:
                msg = json.loads(raw)
            except ValueError:
                continue
            if not isinstance(msg, dict):
                continue
            kind = msg.get("t")
            if kind == "in" and isinstance(msg.get("k"), str) and s.game.accepts(msg["k"]):
                s.inputs.append(("key", msg["k"], bool(msg.get("d"))))
            elif kind == "mm" and _is_num(msg.get("x")) and _is_num(msg.get("y")):
                s.inputs.append(("move", min(1.0, max(0.0, msg["x"])), min(1.0, max(0.0, msg["y"]))))
            elif kind == "mb" and msg.get("b") in (1, 2, 3):
                s.inputs.append(("button", msg["b"], bool(msg.get("d"))))
            elif kind == "pad" and isinstance(msg.get("b"), int) and _nums(msg.get("s"), 4) and _nums(msg.get("g"), 2):
                s.inputs.append(("pad", msg["b"], msg["s"], msg["g"]))
            elif kind == "mw" and _is_num(msg.get("dy")):
                s.inputs.append(("wheel", -1 if msg["dy"] < 0 else 1))
            elif kind == "key" and s.video:  # the browser's decoder needs a fresh start
                s.inputs.append(("keyframe",))
            elif kind == "ping":
                await ws.send(json.dumps({
                    "t": "pong", "c": msg.get("c"), "q": s.quality,
                    "gf": s.game.game_fps,  # the game's real frame rate, measured on the server
                    "sf": s.sent_fps(),  # frames the server streamed: below gf means capture/encoding can't keep up
                }))
            elif kind == "bye":
                s.end("stopped")
                return
            if kind in ("in", "mm", "mb", "mw", "pad"):
                s.last_input = time.monotonic()

    # --- control plane --------------------------------------------------

    async def heartbeat(self):
        ended = list(self.ended)
        payload = {
            "host_id": self.host_id,
            "ws_url": self.public_url,
            "region": self.region,
            "capacity": self.capacity,
            # 0: can't run games, 1: a hidden screen per game, 2: one game at a time on the real desktop
            "desktop": 0 if self.desktop is None else 2 if self.desktop_display else 1,
            "active": list(self.sessions),
            "ended": ended,
        }
        reply = await asyncio.get_running_loop().run_in_executor(None, self._post, payload)
        del self.ended[: len(ended)]  # only acknowledged entries; new ones may have been appended
        for sid in reply.get("terminate", []):
            if sid in self.sessions:
                self.sessions[sid].end("stopped_by_server")
        now = time.time()
        self.redeemed = {sid: exp for sid, exp in self.redeemed.items() if exp > now}

    def _post(self, payload):
        req = urllib.request.Request(
            f"{self.control_url}/api/hosts/heartbeat",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.host_token}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())

    async def run_forever(self):
        """Heartbeat until SIGINT/SIGTERM, then close every running game, so
        stopping the server never leaves a game running on a hidden screen."""
        loop = asyncio.get_running_loop()
        stop = asyncio.Event()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, stop.set)
        beat = asyncio.create_task(self.heartbeat_forever())
        await stop.wait()
        log.info("stopping: closing %d session(s)", len(self.sessions))
        beat.cancel()
        await self.shutdown()

    async def shutdown(self, timeout=15):
        for s in list(self.sessions.values()):
            s.end("server_stopped")
        deadline = time.monotonic() + timeout
        while self.sessions and time.monotonic() < deadline:  # each session closes its own game
            await asyncio.sleep(0.1)

    async def heartbeat_forever(self):
        while True:
            try:
                await self.heartbeat()
            except Exception as e:
                log.warning("heartbeat to %s failed: %s", self.control_url, e)
            await asyncio.sleep(HEARTBEAT_INTERVAL)


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _nums(v, n):
    return isinstance(v, list) and len(v) == n and all(_is_num(x) for x in v)


async def main_async(args, secret):
    display = os.environ.get("DISPLAY") if args.on_screen else None
    host = Host(
        args.id, secret, args.control, args.public_url, args.capacity, args.region,
        desktop_display=display,
    )
    await host.start(args.bind, args.port)
    log.info("stream host %s on %s (capacity %d)", host.host_id, host.public_url, host.capacity)
    await host.run_forever()


def main():
    parser = argparse.ArgumentParser(description="CloudPlay stream host")
    parser.add_argument("--id", default=socket.gethostname())
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8081)
    parser.add_argument("--public-url", help="ws(s):// URL browsers use to reach this host")
    parser.add_argument("--control", default="http://localhost:8080")
    parser.add_argument("--capacity", type=int, default=4)
    parser.add_argument("--region", default="local")
    parser.add_argument("--on-screen", action="store_true", help="show PC games on this computer's desktop ($DISPLAY) instead of hidden screens")
    args = parser.parse_args()
    secret = os.environ.get("CLOUDPLAY_SECRET")
    if not secret:
        raise SystemExit("Set CLOUDPLAY_SECRET (shared with the control plane).")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    asyncio.run(main_async(args, secret))


if __name__ == "__main__":
    main()
