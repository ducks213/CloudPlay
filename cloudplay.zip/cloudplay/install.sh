#!/bin/sh
# Installs CloudPlay for the person running it. Their computer becomes the
# CloudPlay server, and the first account they create is its owner.
#
#   ./install.sh                 install (asks for the password once, for system packages)
#   ./install.sh --no-packages   skip the system packages (already installed, or not apt-based)
#   ./install.sh --no-start      set everything up but don't start it
#   ./install.sh --no-wine       skip setting up Wine (no Windows games)
#
# Everything goes into the user's own folders:
#   ~/.local/share/cloudplay/app    the program
#   ~/.local/share/cloudplay/data   accounts, settings and pictures
#   ~/.local/share/cloudplay/wine   Wine for Windows games (with DXVK and VKD3D-Proton)
# Remove it again with ./uninstall.sh.
set -eu

SOURCE=$(cd "$(dirname "$0")" && pwd)
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/cloudplay"
APP="$DATA/app"
CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}"
PACKAGES=yes
START=yes
WINE=yes
for arg in "$@"; do
    case "$arg" in
        --no-packages) PACKAGES=no ;;
        --no-start) START=no ;;
        --no-wine) WINE=no ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done

say() { printf '\n\033[1m%s\033[0m\n' "$*"; }

if [ "$PACKAGES" = yes ]; then
    if command -v apt-get >/dev/null; then
        say "Installing what CloudPlay needs (this asks for your password)…"
        # Wine's 32-bit half runs older Windows games.
        sudo dpkg --add-architecture i386
        sudo apt-get update
        sudo apt-get install -y \
            python3 python3-gi python3-websockets python3-pil python3-evdev gir1.2-gstreamer-1.0 gir1.2-webkit2-4.1 \
            gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
            gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly \
            weston xwayland xvfb bubblewrap pulseaudio-utils libxtst6 libxdamage1 libxfixes3 \
            curl zstd wine wine64 wine32:i386
        # Let CloudPlay create a virtual controller for each player.
        echo 'KERNEL=="uinput", SUBSYSTEM=="misc", TAG+="uaccess", OPTIONS+="static_node=uinput"' |
            sudo tee /etc/udev/rules.d/60-cloudplay-uinput.rules >/dev/null
        sudo udevadm control --reload-rules
        sudo udevadm trigger --name-match=uinput || true
    else
        say "This isn't an apt-based system: install these yourself, then run ./install.sh --no-packages"
        echo "Python 3 with PyGObject, websockets, Pillow and evdev; GStreamer with the base, good, bad and"
        echo "ugly plugins; WebKitGTK 4.1 with GObject bindings; Weston, Xwayland, Xvfb, bubblewrap, pactl, Wine;"
    echo "write access to /dev/uinput."
        exit 1
    fi
fi

say "Copying CloudPlay into $APP…"
mkdir -p "$APP" "$DATA/data"
# Only the program: never someone's own database or pictures from the source folder.
tar -C "$SOURCE" --exclude='./.git' --exclude='__pycache__' --exclude='./cloudplay*.db*' \
    --exclude='./thumbnails' --exclude='./avatars' --exclude='./backgrounds' -cf - . | tar -C "$APP" -xf -
chmod 700 "$DATA/data"

if [ "$WINE" = yes ] && command -v wine >/dev/null; then
    say "Setting up Wine for Windows games (downloads DXVK and VKD3D-Proton, about 15 MB)…"
    (cd "$APP" && python3 -m host.wine) || echo "Wine setup didn't finish; Windows games will retry it when they start."
fi

say "Adding the CloudPlay app…"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications" "$CONFIG/systemd/user"
# The icon, by name in the icon theme (so the menu and taskbar notice when it changes).
ICONS="$HOME/.local/share/icons/hicolor"
[ -f "$ICONS/index.theme" ] || { mkdir -p "$ICONS"; cp /usr/share/icons/hicolor/index.theme "$ICONS/" 2>/dev/null || true; }
(cd "$APP" && python3 tools/icon.py "$ICONS")
gtk-update-icon-cache -f -t "$ICONS" >/dev/null 2>&1 || true

cat > "$HOME/.local/bin/cloudplay" <<EOF
#!/bin/sh
# Opens the CloudPlay app (it starts the server too, if it isn't running).
exec python3 "$APP/client/app.py" "\$@"
EOF
chmod +x "$HOME/.local/bin/cloudplay"

cat > "$HOME/.local/share/applications/cloudplay.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=CloudPlay
Comment=Play your games, streamed from this computer
Exec=$HOME/.local/bin/cloudplay
Icon=cloudplay
Terminal=false
Categories=Game;
Keywords=games;stream;cloud;
StartupWMClass=cloudplay
EOF

DESKTOP=$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")
if [ -d "$DESKTOP" ]; then
    cp "$HOME/.local/share/applications/cloudplay.desktop" "$DESKTOP/cloudplay.desktop"
    chmod +x "$DESKTOP/cloudplay.desktop"
    gio set "$DESKTOP/cloudplay.desktop" metadata::trusted true 2>/dev/null || true
fi

say "Setting up the CloudPlay server to run in the background…"
cat > "$CONFIG/systemd/user/cloudplay.service" <<EOF
[Unit]
Description=CloudPlay game streaming server
After=pipewire.service pipewire-pulse.service

[Service]
WorkingDirectory=$APP
ExecStart=/usr/bin/python3 run.py --db $DATA/data/cloudplay.db
# On stop, CloudPlay closes every running game and hidden screen itself.
KillSignal=SIGTERM
TimeoutStopSec=30
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF

if [ "$START" = yes ]; then
    systemctl --user daemon-reload
    systemctl --user enable --now cloudplay.service
    say "Done! Open CloudPlay from your app menu or desktop."
    echo "The first account you create is the owner: it can add games. Your computer is the server."
else
    say "Done (not started). Start it with: systemctl --user daemon-reload && systemctl --user enable --now cloudplay"
fi
