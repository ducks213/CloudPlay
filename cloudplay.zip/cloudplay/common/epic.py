"""Epic Games, through Legendary (https://legendary.gl), the open-source Epic
Games client: signing in with an Epic account, the games it owns, installing
them, and how to start one.

CloudPlay keeps its own copy of Legendary and its own sign-in (separate from
Heroic or anything else), and starts the games through its own Wine setup.
"""
import hashlib
import json
import os
import re
import signal
import subprocess
import threading
import urllib.request
from pathlib import Path

DATA = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "cloudplay"
BIN = DATA / "bin" / "legendary"
CONFIG = DATA / "legendary"  # its sign-in and settings (hidden from games, see host/desktop.py)
GAMES = Path.home() / "Games" / "Epic"  # where the games are installed
VERSION = "0.21.1"
DOWNLOAD = f"https://github.com/legendary-gl/legendary/releases/download/{VERSION}/legendary_linux_x64"
SHA256 = "dbed33bbe96031e65858233e4badf0a1d401bb6cb0cc995d1237cf3a0c826a45"  # of that exact file
LOGIN_URL = "https://legendary.gl/epiclogin"  # Epic's login page; it ends showing an authorization code
FREE_GAMES = "https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions?locale=en-US&country={cc}"
APP_NAME_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,100}$")
PROGRESS_RE = re.compile(r"Progress: ([\d.]+)%.*?ETA: (\d+):(\d+):(\d+)")

setup_state = {"running": False, "error": None}  # getting Legendary
installs = {}  # app_name → {"running", "progress", "error"}
_lock = threading.Lock()
_procs = {}  # app_name → the running install, so it can be cancelled


def available():
    return BIN.is_file() and os.access(BIN, os.X_OK)


def setup():
    """Download Legendary (3 MB) in the background, checking it's exactly the
    expected file."""
    with _lock:
        if setup_state["running"] or available():
            return
        setup_state.update(running=True, error=None)

    def run():
        try:
            with urllib.request.urlopen(DOWNLOAD, timeout=60) as resp:
                data = resp.read(50 * 1024 * 1024)
            if hashlib.sha256(data).hexdigest() != SHA256:
                raise OSError("the download wasn't the expected file")
            BIN.parent.mkdir(parents=True, exist_ok=True)
            partial = BIN.with_suffix(".part")
            partial.write_bytes(data)
            partial.chmod(0o755)
            partial.replace(BIN)
        except OSError as e:
            setup_state["error"] = f"Couldn't get Legendary: {e}"
        finally:
            setup_state["running"] = False

    threading.Thread(target=run, daemon=True).start()


def _run(*args, timeout=120):
    env = dict(os.environ, LEGENDARY_CONFIG_PATH=str(CONFIG))
    return subprocess.run([str(BIN), *args], env=env, capture_output=True, text=True, timeout=timeout)


def account():
    """The signed-in Epic account's name, or None."""
    if not available():
        return None
    try:
        status = json.loads(_run("status", "--json", "--offline", timeout=30).stdout or "{}")
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    name = status.get("account")
    return None if not name or name.startswith("<") else name


def sign_in(code):
    """Sign in with the authorization code from Epic's login page."""
    code = code.strip().strip('"')
    match = re.search(r'"authorizationCode"\s*:\s*"([0-9a-f]+)"', code)  # (the whole page text pasted)
    code = match.group(1) if match else code
    if not re.fullmatch(r"[0-9a-f]{20,64}", code):
        return "That isn't an authorization code: copy the code from Epic's page (32 letters and numbers)."
    try:
        _run("auth", "--code", code, "--disable-webview", timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        return str(e)
    return None if account() else "Epic didn't accept that code. Codes work once and expire quickly: get a new one."


def sign_out():
    if available():
        _run("auth", "--delete", timeout=30)


def _image(images, *kinds):
    by_type = {i.get("type"): i.get("url") for i in images or [] if i.get("url")}
    return next((by_type[k] for k in kinds if k in by_type), None)


def owned():
    """[{"id", "name", "image"}] for the Windows games the account owns."""
    try:
        games = json.loads(_run("list", "--json", timeout=180).stdout or "[]")
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    result = []
    for game in games:
        meta = game.get("metadata") or {}
        result.append({"id": game.get("app_name"), "name": game.get("app_title") or game.get("app_name"),
                       "namespace": meta.get("namespace"),
                       "image": _image(meta.get("keyImages"), "DieselGameBoxWide", "OfferImageWide",
                                       "DieselStoreFrontWide", "Thumbnail", "DieselGameBox")})
    return [g for g in result if g["id"]]


def installed():
    """{app_name: install folder} for the games installed through CloudPlay's Legendary."""
    if not available():
        return {}
    try:
        games = json.loads(_run("list-installed", "--json", timeout=60).stdout or "[]")
    except (OSError, ValueError, subprocess.SubprocessError):
        return {}
    return {g["app_name"]: g.get("install_path") for g in games if g.get("app_name")}


def install(app_name, on_done):
    """Download and install a game the account owns, in the background."""
    with _lock:
        if installs.get(app_name, {}).get("running"):
            return
        installs[app_name] = {"running": True, "progress": 0.0, "eta": None, "error": None}

    def run():
        error = None
        env = dict(os.environ, LEGENDARY_CONFIG_PATH=str(CONFIG))
        try:
            GAMES.mkdir(parents=True, exist_ok=True)
            # (its own process group: Legendary downloads with a dozen helper
            # processes, and cancelling has to stop them all)
            proc = subprocess.Popen([str(BIN), "install", app_name, "-y", "--skip-sdl", "--skip-dlcs",
                                     "--base-path", str(GAMES)], env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, start_new_session=True)
            _procs[app_name] = proc
            last = ""
            for line in proc.stdout:
                found = PROGRESS_RE.search(line)
                if found:
                    h, m, s = (int(x) for x in found.group(2, 3, 4))
                    installs[app_name].update(progress=float(found.group(1)), eta=h * 3600 + m * 60 + s)
                elif line.strip():
                    last = line.strip()
            if proc.wait() and not installs[app_name].get("cancelled"):
                error = last or "installation failed"
        except OSError as e:
            error = str(e)
        _procs.pop(app_name, None)
        with _lock:
            cancelled = installs[app_name].get("cancelled")
            installs[app_name] = {"running": False, "progress": 0.0 if error or cancelled else 100.0, "eta": None,
                                  "error": None if cancelled else error}
        if not error and not cancelled:
            on_done(app_name)

    threading.Thread(target=run, daemon=True).start()


def cancel_install(app_name):
    """Stop a download that's under way. What was downloaded stays, so
    installing it again later carries on from there."""
    with _lock:
        state = installs.get(app_name)
        if not state or not state.get("running"):
            return False
        state["cancelled"] = True
    proc = _procs.get(app_name)
    if proc and proc.poll() is None:
        stop_group(proc)
    return True


def stop_group(proc):
    """Stop a process and every helper it started: politely first (so it can
    save where it got to), then firmly."""
    def run():
        for sig, wait in ((signal.SIGINT, 15), (signal.SIGTERM, 5), (signal.SIGKILL, 0)):
            try:
                os.killpg(proc.pid, sig)
            except (ProcessLookupError, PermissionError):
                return
            try:
                proc.wait(timeout=wait or None)
                return
            except subprocess.TimeoutExpired:
                continue
    threading.Thread(target=run, daemon=True).start()


def download_size(app_name):
    """How much a game downloads (bytes), or None if it can't be told."""
    try:
        info = json.loads(_run("info", app_name, "--json", timeout=90).stdout or "{}")
        return int(info["manifest"]["download_size"])
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        return None


def uninstall(app_name):
    """Remove an installed game and its files. Returns an error, or None."""
    try:
        result = _run("-y", "uninstall", app_name, timeout=600)
    except (OSError, subprocess.SubprocessError) as e:
        return str(e)
    if app_name in installed():
        return (result.stderr.strip().splitlines() or ["couldn't uninstall it"])[-1]
    return None


def launch_info(app_name):
    """How to start the game: its program, arguments (including Epic's online
    sign-in for it), folder and environment, as Legendary works them out."""
    result = _run("launch", app_name, "--json", timeout=90)
    try:
        info = json.loads(result.stdout)
    except ValueError:
        raise OSError((result.stderr.strip().splitlines() or ["Legendary couldn't start the game"])[-1]) from None
    return info


def free_games(cc):
    """Epic's free games: free right now, and coming up next."""
    try:
        req = urllib.request.Request(FREE_GAMES.format(cc=cc), headers={"User-Agent": "CloudPlay"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            elements = json.load(resp)["data"]["Catalog"]["searchStore"]["elements"]
    except (OSError, ValueError, KeyError, TypeError):
        return None
    games = []
    for e in elements:
        promos = e.get("promotions") or {}
        now = any(o.get("discountSetting", {}).get("discountPercentage") == 0
                  for p in promos.get("promotionalOffers") or [] for o in p.get("promotionalOffers") or [])
        soon = bool(promos.get("upcomingPromotionalOffers"))
        if not (now or soon):
            continue
        slug = (e.get("catalogNs", {}).get("mappings") or [{}])[0].get("pageSlug") or e.get("productSlug") or e.get("urlSlug")
        price = (e.get("price") or {}).get("totalPrice") or {}
        games.append({
            "source": "epic-free", "id": e.get("id"), "name": e.get("title"),
            "image": _image(e.get("keyImages"), "OfferImageWide", "DieselStoreFrontWide", "Thumbnail"),
            "price": 0 if now else None, "initial": price.get("originalPrice") or None,
            "currency": price.get("currencyCode"), "free_now": now,
            "url": f"https://store.epicgames.com/p/{slug.split('/')[0]}" if slug else "https://store.epicgames.com/free-games",
        })
    return sorted(games, key=lambda g: not g["free_now"])  # free right now first
