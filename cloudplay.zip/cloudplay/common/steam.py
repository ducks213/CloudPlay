"""Steam on the host: which games are installed, and whether Steam is running.

CloudPlay launches Steam games through the Steam client itself (see
host/desktop.py), so Steam picks Proton, launch options and runtimes and
checks the licence exactly as it does on the desktop.
"""
import json
import os
import re
import shutil
import unicodedata
import urllib.parse
import urllib.request
from pathlib import Path

DOT_STEAM = Path.home() / ".steam"  # Steam's pid, registry and a link to its install
ROOT = DOT_STEAM / "steam"
# Steam installs these like games, but they're tools, not something to play.
TOOLS = re.compile(r"^(Proton|Steam Linux Runtime|Steamworks Common Redistributables|SteamVR)\b")
FULLY_INSTALLED = 4  # StateFlags bit in appmanifest_*.acf

_PAIR = re.compile(r'"([^"]+)"\s+"((?:[^"\\]|\\.)*)"')


def available():
    return shutil.which("steam") is not None and ROOT.is_dir()


def _pairs(path):
    try:
        return _PAIR.findall(Path(path).read_text(errors="replace"))
    except OSError:
        return []


def library_folders():
    folders = [value for key, value in _pairs(ROOT / "steamapps" / "libraryfolders.vdf") if key == "path"]
    return [Path(f) for f in dict.fromkeys(folders or [str(ROOT)])]


def installed_games():
    """[{"appid": int, "name": str}] for every fully installed Steam game, by name."""
    games = {}
    for folder in library_folders():
        for manifest in (folder / "steamapps").glob("appmanifest_*.acf"):
            info = dict(_pairs(manifest))  # the first "appid"/"name" keys are the app's own
            try:
                appid, flags = int(info["appid"]), int(info.get("StateFlags", 0))
            except (KeyError, ValueError):
                continue
            name = info.get("name", f"Steam app {appid}")
            if flags & FULLY_INSTALLED and not TOOLS.match(name):
                games[appid] = name
    return sorted(({"appid": a, "name": n} for a, n in games.items()), key=lambda g: g["name"].lower())


def artwork(appid):
    """Steam's banner for a game (the store page's header image), if Steam has it."""
    cache = ROOT / "appcache" / "librarycache"
    for path in (cache / str(appid) / "header.jpg", cache / f"{appid}_header.jpg"):  # newer and older layouts
        if path.is_file():
            return path
    return None


def store_artwork(names, timeout=5):
    """The official banner of a game from Steam's public store, looked up by
    name (the first of names that matches), as JPEG bytes; None if no store
    entry has that name. Only the name is sent; no account is needed."""
    for name in names:
        wanted = _simple(name)
        if len(wanted) < 3:
            continue
        url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode(
            {"term": name, "l": "english", "cc": "US"})
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                items = json.load(resp).get("items", [])
        except (OSError, ValueError):
            return None  # offline, or the store is down: try again another time
        # Only the game itself: not its soundtrack, artbook or DLC.
        match = next((i for i in items if _simple(i.get("name", "")) == wanted), None)
        if match and str(match.get("id", "")).isdigit():
            return _header_image(int(match["id"]), timeout)
    return None


def _header_image(appid, timeout=5):
    """A Steam game's banner as JPEG bytes. Its exact address comes from the
    store's game details (newer games have coded file names); the plain
    address is the fallback."""
    urls = []
    try:
        details_url = f"https://store.steampowered.com/api/appdetails?appids={appid}&filters=basic"
        with urllib.request.urlopen(details_url, timeout=timeout) as resp:
            header = json.load(resp)[str(appid)]["data"]["header_image"]
        if header.startswith("https://"):
            urls.append(header)
    except (OSError, ValueError, KeyError, TypeError):
        pass
    urls.append(f"https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{appid}/header.jpg")
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                image = resp.read(2 * 1024 * 1024)
        except OSError:
            continue
        if image.startswith(b"\xff\xd8"):
            return image
    return None


def _simple(name):
    """A name reduced for comparison: "God of War Ragnarök™" -> "godofwarragnarok"."""
    ascii_name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", ascii_name.lower())


def running_pid():
    """The Steam client's pid if it's running, else None."""
    try:
        pid = int((DOT_STEAM / "steam.pid").read_text().strip())
        with open(f"/proc/{pid}/comm") as comm:
            return pid if "steam" in comm.read() else None
    except (OSError, ValueError):
        return None


def game_running(display, appid):
    """Whether a game Steam launched is running on this X display: Steam marks
    every game process with SteamAppId (its registry's RunningAppID isn't
    written reliably while the game runs)."""
    return bool(processes_on_display(display, f"SteamAppId={appid}"))


def running_app():
    """The appid of the game Steam says is running (0 if none)."""
    for key, value in _pairs(DOT_STEAM / "registry.vdf"):
        if key == "RunningAppID":
            return int(value) if value.isdigit() else 0
    return 0


def launch_command(appid, args=()):
    """Start Steam (quietly, without its windows) and have it launch the game."""
    return [shutil.which("steam") or "steam", "-silent", "-nochatui", "-nofriendsui", "-applaunch", str(appid), *args]


def shutdown_command():
    return [shutil.which("steam") or "steam", "-shutdown"]


def processes_on_display(display, marker=None):
    """PIDs of this user's processes attached to an X display (and, if given,
    with the environment entry marker): after a Steam session, whatever Steam
    and the game left behind on the hidden screen."""
    pids = []
    for entry in os.scandir("/proc"):
        if not entry.name.isdigit():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                continue
            with open(f"/proc/{entry.name}/environ", "rb") as f:
                env = f.read().split(b"\0")
        except OSError:
            continue
        if f"DISPLAY={display}".encode() in env and (marker is None or marker.encode() in env):
            pids.append(int(entry.name))
    return pids
