"""The game store's Steam part: Steam's catalogue at Steam's own prices, for
this computer's country (Epic is in common/epic.py).

CloudPlay doesn't sell anything: Steam games are bought and installed through
the Steam client with the owner's own account. Once installed, a game is
added to the library.
"""
import json
import os
import re
import shutil
import subprocess
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

STEAM = "https://store.steampowered.com"
TIMEOUT = 8
APPID_IN_URL = re.compile(r"/apps/(\d+)/")

def _get(url, data=None):
    headers = {"User-Agent": "CloudPlay", "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(data).encode()
    with urllib.request.urlopen(urllib.request.Request(url, data=data, headers=headers), timeout=TIMEOUT) as resp:
        return json.load(resp)


def country():
    """This computer's country (two letters), from its time zone: Steam shows
    prices for a country, and that's where the owner shops."""
    try:
        zone = subprocess.run(["timedatectl", "show", "-p", "Timezone", "--value"],
                              capture_output=True, text=True, timeout=5).stdout.strip()
        for line in Path("/usr/share/zoneinfo/zone.tab").read_text().splitlines():
            parts = line.split("\t")
            if len(parts) >= 3 and parts[2] == zone:
                return parts[0]
    except (OSError, subprocess.SubprocessError):
        pass
    return "US"


def _steam_header(appid):
    return f"https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{appid}/header.jpg"


def _steam_item(appid, name, price=None, currency=None, platforms=None, initial=None, logo=None):
    # Newer games keep their pictures in folders with coded names that the big
    # banner doesn't share; the search result's own picture shows where the
    # medium one is, which the page falls back to.
    # (Some use alternative pictures for a while: "capsule_sm_120_alt_assets_4.jpg".)
    fallback = (re.sub(r"/capsule_sm_120((?:_alt_assets_\d+)?)\.jpg$", r"/capsule_231x87\1.jpg", logo.split("?")[0])
                if logo and "/capsule_sm_120" in logo else None)
    return {
        "source": "steam", "id": str(appid), "name": name, "image": _steam_header(appid), "image_fallback": fallback,
        "price": price,  # in cents; 0 = free; "soon" = not out yet; None = not known
        "initial": initial if initial and isinstance(price, int) and initial > price else None,  # before a discount
        "currency": currency,
        "linux": None if platforms is None else bool(platforms.get("linux")),  # not Linux: Steam runs it with Proton
    }


def _steam_prices(appids, cc):
    """{appid: (cents, currency, cents before a discount)} for these games, from Steam (0 for free ones)."""
    prices = {}
    if not appids:
        return prices
    try:
        data = _get(f"{STEAM}/api/appdetails?appids={','.join(map(str, appids))}&filters=price_overview&cc={cc}")
    except (OSError, ValueError):
        return prices
    unpriced = []
    for appid, entry in data.items():
        if entry.get("success"):
            details = entry.get("data")
            overview = details.get("price_overview") if isinstance(details, dict) else None
            if overview:
                prices[appid] = (overview["final"], overview.get("currency"), overview.get("initial"))
            else:
                unpriced.append(appid)
    # No price: free, or not out yet. Only Steam's full details tell which.
    def details(appid):
        try:
            info = _get(f"{STEAM}/api/appdetails?appids={appid}&filters=basic,release_date&cc={cc}")[appid]["data"]
        except (OSError, ValueError, KeyError, TypeError):
            return appid, None
        if info.get("is_free"):
            return appid, (0, None, None)
        return appid, ("soon" if (info.get("release_date") or {}).get("coming_soon") else None, None, None)
    with ThreadPoolExecutor(8) as pool:
        for appid, price in pool.map(details, unpriced):
            if price:
                prices[appid] = price
    return prices


def steam_search(query, cc, count=24):
    """Games on Steam matching the query (or the best-selling ones, without a
    query), with their price here. Steam's own store search: games only, and
    with its usual filter for adult content."""
    params = {"term": query, "start": 0, "count": count, "category1": 998, "json": 1, "cc": cc, "l": "english"}
    if not query:
        params["filter"] = "topsellers"
    try:
        data = _get(f"{STEAM}/search/results/?" + urllib.parse.urlencode(params))
    except (OSError, ValueError):
        return None
    games = []
    for item in data.get("items", []):
        found = APPID_IN_URL.search(item.get("logo", ""))
        if found and found.group(1) not in {g[0] for g in games}:
            games.append((found.group(1), item["name"], item["logo"]))
    prices = _steam_prices([appid for appid, _, _ in games], cc)
    return [_steam_item(appid, name, price, currency, None, initial, logo)
            for appid, name, logo in games for price, currency, initial in [prices.get(appid, (None, None, None))]]


def search(query):
    """Steam results for a search (or the front page)."""
    cc = country()
    return {"country": cc, "steam": steam_search(query.strip(), cc)}


# --- getting a game ------------------------------------------------------

def open_in_steam(appid, buy=False, uninstall=False):
    """Hand the game to the Steam client on this computer: its store page to buy
    it, or its install (or uninstall) dialog. Steam does the rest with the
    owner's account."""
    action = "uninstall" if uninstall else "store" if buy else "install"
    link = f"steam://{action}/{int(appid)}"
    # Steam runs on its own, not as part of CloudPlay's service: restarting
    # CloudPlay mustn't close Steam (in the middle of a download or a purchase).
    on_its_own = ["systemd-run", "--user", "--scope", "--collect", "--quiet", "--unit", f"cloudplay-steam-{os.getpid()}-{int(time.time())}"]
    cmd = [*on_its_own, "steam", link] if shutil.which("systemd-run") else ["steam", link]
    subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
