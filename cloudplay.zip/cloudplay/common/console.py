"""Streaming a PlayStation through CloudPlay, with chiaki-ng (PS Remote Play).

The console does the work; chiaki-ng runs on one of CloudPlay's hidden screens,
connected to it, and CloudPlay streams that picture, sound and the player's
controller as for any game. The console has to be linked in chiaki-ng first
(with the PIN from the console's Remote Play settings).
"""
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path

FLATPAK_ID = "io.github.streetpea.Chiaki4deck"
CONFIG = Path.home() / ".var" / "app" / FLATPAK_ID / "config" / "Chiaki" / "Chiaki.conf"
ADDRESS_RE = re.compile(r"^[A-Za-z0-9.:-]{1,253}$")  # an IP address or host name
FLATHUB = "https://dl.flathub.org/repo/flathub.flatpakrepo"

# A chiaki-ng installation started from the Console settings (it takes a few minutes).
install_state = {"running": False, "error": None}


def installed():
    if not shutil.which("flatpak"):
        return False
    result = subprocess.run(["flatpak", "info", FLATPAK_ID], capture_output=True, timeout=10)
    return result.returncode == 0


def open_app():
    """Open chiaki-ng on this computer's desktop, to link a console."""
    if not os.environ.get("DISPLAY"):
        raise OSError("no desktop to open it on")
    subprocess.Popen(["flatpak", "run", FLATPAK_ID], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)


def install():
    """Install chiaki-ng from Flathub for this user (no password needed), in the background."""
    if install_state["running"]:
        return

    def run():
        install_state.update(running=True, error=None)
        try:
            for cmd in (["flatpak", "remote-add", "--user", "--if-not-exists", "flathub", FLATHUB],
                        ["flatpak", "install", "--user", "--noninteractive", "-y", "flathub", FLATPAK_ID]):
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
                if result.returncode:
                    install_state["error"] = (result.stderr.strip().splitlines() or ["installation failed"])[-1]
                    return
        except (OSError, subprocess.TimeoutExpired) as e:
            install_state["error"] = str(e)
        finally:
            install_state["running"] = False

    if not shutil.which("flatpak"):
        install_state["error"] = "Flatpak isn't installed on this computer."
        return
    threading.Thread(target=run, daemon=True).start()


def _sections():
    """chiaki-ng's settings file (Qt's INI format) as {section: {key: value}}."""
    sections, current = {}, None
    try:
        lines = CONFIG.read_text(errors="replace").splitlines()
    except OSError:
        return {}
    for line in lines:
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            current = sections.setdefault(line[1:-1], {})
        elif "=" in line and current is not None:
            key, value = line.split("=", 1)
            current[key.strip()] = value.strip()
    return sections


def _numbered(section, field):
    """Qt stores lists as "1\\field=...", "2\\field=...": the values, in order."""
    values = {}
    for key, value in section.items():
        number, _, name = key.partition("\\")
        if name == field and number.isdigit():
            values[int(number)] = value
    return [values[n] for n in sorted(values)]


def linked_consoles():
    """[{"nickname", "address"}] for every console linked in chiaki-ng. The
    address is only known if it was added by hand in chiaki-ng."""
    sections = _sections()
    nicknames = _numbered(sections.get("registered_hosts", {}), "server_nickname")
    known = _numbered(sections.get("manual_hosts", {}), "host")
    suggestion = known[0] if len(known) == 1 else ""  # with one console added by hand, that's its address
    return [{"nickname": nick, "address": suggestion} for nick in nicknames]


def launch_command(nickname, address):
    """chiaki-ng streaming the console fullscreen, closing when the stream ends."""
    return ["flatpak", "run", FLATPAK_ID, "--fullscreen", "--exit-app-on-stream-exit", "stream", nickname, address]
