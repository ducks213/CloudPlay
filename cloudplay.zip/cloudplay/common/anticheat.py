"""Which games refuse to run on Linux because of their anti-cheat, from the
community list at https://areweanticheatyet.com (updated by its users).

Used to warn before getting a game that can't be played here, such as
Fortnite, whose publisher blocks Linux.
"""
import json
import re
import threading
import time
import unicodedata
import urllib.request

LIST = "https://raw.githubusercontent.com/AreWeAntiCheatYet/AreWeAntiCheatYet/master/games.json"
REFRESH_SECONDS = 24 * 3600
WONT_RUN = {"Denied", "Broken"}  # (blocked by the publisher; doesn't work)

_cache = {"at": 0, "steam": {}, "epic": {}, "names": {}}
_lock = threading.Lock()


def _simple(name):
    ascii_name = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", ascii_name.lower())


def _load():
    with _lock:
        if time.time() - _cache["at"] < REFRESH_SECONDS:
            return _cache
    try:
        req = urllib.request.Request(LIST, headers={"User-Agent": "CloudPlay"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            games = json.load(resp)
    except (OSError, ValueError):
        with _lock:
            _cache["at"] = time.time() - REFRESH_SECONDS + 600  # offline: try again in 10 minutes
        return _cache
    steam, epic, names = {}, {}, {}
    for game in games:
        status = game.get("status")
        ids = game.get("storeIds") or {}
        if ids.get("steam"):
            steam[str(ids["steam"])] = status
        if (ids.get("epic") or {}).get("namespace"):
            epic[ids["epic"]["namespace"]] = status
        names[_simple(game.get("name"))] = status
    with _lock:
        _cache.update(at=time.time(), steam=steam, epic=epic, names=names)
    return _cache


def wont_run(source, game_id, name, namespace=None):
    """True if the game's anti-cheat is known to block Linux (or not work on it)."""
    data = _load()
    if source == "steam" and str(game_id) in data["steam"]:
        status = data["steam"][str(game_id)]
    elif source in ("epic", "epic-free") and namespace and namespace in data["epic"]:
        status = data["epic"][namespace]
    else:
        status = data["names"].get(_simple(name))
    return status in WONT_RUN
