"""Signed, short-lived session tickets.

The control plane issues a ticket when it assigns a session to a host; the
browser presents it to that host's stream endpoint. Hosts never talk to the
user database, they only check the signature and the expiry.
"""
import base64
import binascii
import hashlib
import hmac
import json
import time


class TicketError(Exception):
    pass


def derive(secret, purpose):
    """Derive a per-purpose key so one leaked key can't be reused elsewhere."""
    return hmac.new(secret.encode(), purpose.encode(), hashlib.sha256).hexdigest()


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _unb64(text):
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _mac(key, payload):
    return _b64(hmac.new(key.encode(), payload.encode(), hashlib.sha256).digest())


def sign(claims, key, ttl):
    body = dict(claims, exp=int(time.time()) + ttl)
    payload = _b64(json.dumps(body, separators=(",", ":"), sort_keys=True).encode())
    return f"{payload}.{_mac(key, payload)}"


def verify(ticket, key, now=None):
    payload, _, mac = (ticket or "").partition(".")
    if not payload or not mac:
        raise TicketError("malformed ticket")
    if not hmac.compare_digest(mac, _mac(key, payload)):
        raise TicketError("bad signature")
    try:
        claims = json.loads(_unb64(payload))
    except (ValueError, binascii.Error) as e:
        raise TicketError("malformed ticket") from e
    if claims.get("exp", 0) < (now if now is not None else time.time()):
        raise TicketError("ticket expired")
    return claims
