"""CloudPlay control plane: accounts, game library, host registry and session placement.

Stream hosts register themselves via heartbeats. When a user presses Play, the
control plane picks the least-loaded live host, records the session and hands
the browser a signed ticket for that host. Heartbeats carry session state back
(started / ended / seconds played) and carry stop requests out to hosts.
"""
import argparse
import hashlib
import hmac
import io
import urllib.parse
import urllib.request
import json
import logging
import mimetypes
import os
import re
import secrets
import shlex
import shutil
import subprocess
import sqlite3
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from common import anticheat, console, epic, steam, store, tickets

log = logging.getLogger("cloudplay.control")

WEB_DIR = Path(__file__).resolve().parent.parent / "web"
TOKEN_TTL = 30 * 86400
TICKET_TTL = 60
HOST_TIMEOUT = 20
MAX_BODY = 64 * 1024
MAX_AVATAR_UPLOAD = 8 * 1024 * 1024
# Each person's settings: name -> (default, allowed values). Volume is a number.
SETTINGS = {
    "accent": ("orange", {"orange", "gold", "teal", "blue", "pink", "green", "red", "purple", "cyan", "lime", "peach", "cream"}),
    "theme": ("dark", {"dark", "light"}),
    "quality": ("best", {"best", "balanced", "saver"}),
    "volume": (100, range(0, 101)),
    "stats": (True, {True, False}),
    "full_window": (False, {True, False}),
    "background": ("plain", {"plain", "sunset", "grid", "dots", "stars", "custom"}),  # custom: an uploaded image
}
COLOUR_RE = re.compile(r"^#[0-9a-f]{6}$")  # a colour of the person's own choosing
BACKGROUND_MAX = (1920, 1080)
AVATAR_SIZE = 256
SLUG_RE = re.compile(r"^pc-[0-9a-f]{8}$")
LOGIN_WINDOW = 300
LOGIN_MAX_FAILURES = 10
INVITE_TTL = 7 * 86400
INVITE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # no 0/O or 1/I/L to mix up
PBKDF2_ITERATIONS = 200_000

USERNAME_RE = re.compile(r"^[A-Za-z0-9_-]{3,32}$")
WINDOWS_EXTS = (".exe", ".bat")
RUNNER_LABELS = {
    "wine": "Windows game (Wine)", "native": "Linux game", "steam": "Steam game", "console": "PlayStation (Remote Play)",
    "flatpak": "Linux game (Flathub)", "epic": "Epic game",
}
STORE_IMAGE_HOSTS = {  # where the store's pictures come from (and nowhere else)
    "shared.akamai.steamstatic.com", "shared.fastly.steamstatic.com",
    "cdn1.epicgames.com", "cdn2.unrealengine.com", "epicgames-download1.akamaized.net",
}
EPIC_OWNED_CACHE_SECONDS = 600
EPIC_ASK_ABOVE = 20 * 10**9  # Epic downloads bigger than this (bytes) are confirmed first
STEAM_WAIT_SECONDS = 6 * 3600  # how long a game got from the store may take to install in Steam
ACCENTS = ["#4cc9f0", "#80ed99", "#f72585", "#ffb703", "#7b5cff", "#ff6b6b", "#06d6a0"]
MAX_BROWSE_ENTRIES = 1000
LIVE = ("pending", "active", "ending")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL COLLATE NOCASE,
  pw_hash TEXT NOT NULL,
  is_admin INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS tokens (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS hosts (
  id TEXT PRIMARY KEY,
  ws_url TEXT NOT NULL,
  region TEXT NOT NULL,
  capacity INTEGER NOT NULL,
  desktop INTEGER NOT NULL DEFAULT 0,
  last_seen REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  game TEXT NOT NULL,
  host_id TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at REAL NOT NULL,
  started_at REAL,
  ended_at REAL,
  seconds REAL NOT NULL DEFAULT 0,
  end_reason TEXT
);
CREATE TABLE IF NOT EXISTS games (
  slug TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  runner TEXT NOT NULL,
  path TEXT NOT NULL,
  args TEXT NOT NULL DEFAULT '[]',
  accent TEXT NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS invites (
  code_hash TEXT PRIMARY KEY,
  created_by INTEGER NOT NULL REFERENCES users(id),
  expires_at REAL NOT NULL,
  used_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS purchases (  -- games got through the store (CloudPlay never sees receipts)
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  source TEXT NOT NULL,
  game_id TEXT NOT NULL,
  name TEXT NOT NULL,
  image TEXT,
  price INTEGER,          -- in cents, as shown in the store when it was got (0 = free; NULL = not bought here)
  currency TEXT,
  got_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id, status);
CREATE INDEX IF NOT EXISTS sessions_host ON sessions(host_id, status);
"""


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


def hash_password(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def check_password(password, stored):
    try:
        _, iterations, salt, digest = stored.split("$")
    except ValueError:
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(iterations))
    return hmac.compare_digest(candidate.hex(), digest)


def detect_runner(path):
    return "wine" if path.lower().endswith(WINDOWS_EXTS) else "native"


def _sha256(text):
    return hashlib.sha256(text.encode()).hexdigest()


class Store:
    """Thin SQLite wrapper. The RLock makes multi-statement operations atomic
    across the HTTP server's worker threads."""

    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        if path != ":memory:":
            self.db.execute("PRAGMA journal_mode=WAL")
            # Accounts and sessions are nobody else's business on this computer.
            for f in (path, f"{path}-wal", f"{path}-shm"):
                if os.path.exists(f):
                    os.chmod(f, 0o600)
        self.db.executescript(SCHEMA)
        self.db.execute("DROP TABLE IF EXISTS achievements")  # a removed feature
        self.db.execute("DROP TABLE IF EXISTS wishlist")  # removed features
        self.db.execute("DROP TABLE IF EXISTS cart")
        # Databases created before game imports existed.
        self._add_column("users", "is_admin", "INTEGER NOT NULL DEFAULT 0")
        self._add_column("hosts", "desktop", "INTEGER NOT NULL DEFAULT 0")
        self._add_column("users", "settings", "TEXT NOT NULL DEFAULT '{}'")
        self._drop_column("users", "plan")  # paid plans are gone: everyone gets the same service
        # Accounts used to sign in with an email address, which was never used for
        # anything else; it's now a username, and old addresses keep working as one.
        if "email" in {row["name"] for row in self.db.execute("PRAGMA table_info(users)")}:
            self.db.execute("ALTER TABLE users RENAME COLUMN email TO username")
        # The first account owns the server (it may launch programs on it).
        self.db.execute(
            "UPDATE users SET is_admin = 1 WHERE id = (SELECT MIN(id) FROM users) "
            "AND NOT EXISTS (SELECT 1 FROM users WHERE is_admin = 1)"
        )

    def _add_column(self, table, column, decl):
        if column not in {row["name"] for row in self.db.execute(f"PRAGMA table_info({table})")}:
            self.db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")

    def _drop_column(self, table, column):
        if column in {row["name"] for row in self.db.execute(f"PRAGMA table_info({table})")}:
            self.db.execute(f"ALTER TABLE {table} DROP COLUMN {column}")

    def all(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchone()

    def run(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args)


class ControlPlane:
    def __init__(self, db_path, secret, fetch_artwork=True, shared=False):
        """shared: other devices can reach this server (run.py --lan), so there's
        someone to invite."""
        self.store = Store(db_path)
        self.shared = shared
        # One picture per game for the library cards: its official banner, from
        # Steam's local cache for Steam games, or looked up in Steam's store by name.
        self.fetch_artwork = fetch_artwork
        self.artwork = {}  # names → {"done": Event, "image": bytes|None}: looked up ahead of an import
        self.steam_waiting = {}  # Steam games got from the store, until installed: appid → (since, title, user id)
        self.steam_uninstalling = {}  # Steam games being uninstalled from the store: appid → since
        self.steam_watcher = None
        self.store_lock = threading.Lock()
        self.epic_owned = None  # (when, account, [games]): the Epic account's games, for a few minutes
        self.cache = {}  # name → (when, value), see _cached
        self.artwork_lock = threading.Lock()
        memory = db_path == ":memory:"
        self.thumbnails = Path(tempfile.mkdtemp() if memory else Path(db_path).resolve().parent / "thumbnails")
        self.thumbnails.mkdir(exist_ok=True)
        self.avatars = self.thumbnails.parent / "avatars"  # profile pictures, one per account
        self.avatars.mkdir(exist_ok=True)
        self.backgrounds = self.thumbnails.parent / "backgrounds"  # each account's own background image
        self.backgrounds.mkdir(exist_ok=True)
        if fetch_artwork:  # games imported before (or while offline) get theirs too
            for row in self.store.all("SELECT * FROM games WHERE runner != 'steam'"):
                if not self.thumbnail_path(row["slug"]).exists():
                    self._look_up_artwork(row)
        self.ticket_key = tickets.derive(secret, "ticket")
        self.host_token = tickets.derive(secret, "host-auth")
        self._failures = {}
        self._failures_lock = threading.Lock()

    # --- accounts -------------------------------------------------------

    @staticmethod
    def _valid_username(username):
        username = str(username or "").strip()
        if not USERNAME_RE.match(username):
            raise ApiError(400, "Usernames are 3 to 32 letters, numbers, _ or -.")
        return username

    def _username_taken(self, username, except_id=None):
        # Not case-sensitive: "Ilkay" and "ilkay" are the same account.
        row = self.store.one("SELECT id FROM users WHERE username = ? COLLATE NOCASE", (username,))
        return row is not None and row["id"] != except_id

    def needs_invite(self):
        """The first account (the owner) signs up freely; everyone after needs an invite."""
        return self.store.one("SELECT 1 FROM users LIMIT 1") is not None

    def signup(self, username, password, invite=None):
        username = self._valid_username(username)
        password = str(password or "")
        if len(password) < 8:
            raise ApiError(400, "Password must be at least 8 characters.")
        with self.store.lock:
            invite_hash = None
            if self.needs_invite():
                invite_hash = _sha256(re.sub(r"[^A-Z0-9]", "", str(invite or "").upper()))
                if not self.store.one(
                    "SELECT 1 FROM invites WHERE code_hash = ? AND used_by IS NULL AND expires_at > ?",
                    (invite_hash, time.time()),
                ):
                    raise ApiError(403, "You need a valid invite code from the server's owner to sign up.")
            if self._username_taken(username):
                raise ApiError(409, "That username is taken.")
            cur = self.store.run(
                "INSERT INTO users(username, pw_hash, created_at, is_admin) "
                "SELECT ?, ?, ?, NOT EXISTS (SELECT 1 FROM users)",
                (username, hash_password(password), time.time()),
            )
            if invite_hash:
                self.store.run("UPDATE invites SET used_by = ? WHERE code_hash = ?", (cur.lastrowid, invite_hash))
        return self._issue_token(cur.lastrowid)

    def create_invite(self, user):
        """A one-time code, valid for a week, that lets one person sign up."""
        self._require_admin(user)
        code = "".join(secrets.choice(INVITE_ALPHABET) for _ in range(8))
        expires = time.time() + INVITE_TTL
        self.store.run("INSERT INTO invites VALUES (?, ?, ?, NULL)", (_sha256(code), user["id"], expires))
        return {"code": f"{code[:4]}-{code[4:]}", "expires_at": expires}

    def login(self, username, password, ip):
        self._check_rate(ip)
        row = self.store.one(
            "SELECT id, pw_hash FROM users WHERE username = ? COLLATE NOCASE", (str(username or "").strip(),)
        )
        if not row or not check_password(str(password or ""), row["pw_hash"]):
            self._record_failure(ip)
            raise ApiError(401, "Wrong username or password.")
        return self._issue_token(row["id"])

    # --- settings --------------------------------------------------------

    @staticmethod
    def _settings(user):
        try:
            saved = json.loads(user["settings"] or "{}")
        except ValueError:
            saved = {}
        return {name: saved.get(name, default) for name, (default, _) in SETTINGS.items()}

    def update_settings(self, user, changes):
        with self.store.lock:  # read the latest saved settings, so two quick changes can't undo each other
            current = self.store.one("SELECT settings FROM users WHERE id = ?", (user["id"],))
            return self._apply_settings(user["id"], self._settings(current), changes)

    def _apply_settings(self, user_id, settings, changes):
        for name, value in changes.items():
            if name not in SETTINGS:
                raise ApiError(400, f"There's no setting called {name!r}.")
            allowed = SETTINGS[name][1]
            any_colour = name == "accent" and isinstance(value, str) and COLOUR_RE.match(value)  # e.g. "#3fa7ff"
            if not any_colour and (type(value) is not type(SETTINGS[name][0]) or value not in allowed):  # True isn't 1 here
                raise ApiError(400, f"{value!r} isn't a valid value for {name}.")
            if name == "background" and value == "custom" and not self.background_path(user_id).exists():
                raise ApiError(400, "Upload a background image first.")
            settings[name] = value
        self.store.run("UPDATE users SET settings = ? WHERE id = ?", (json.dumps(settings), user_id))
        return {"settings": settings}

    # --- profile pictures ------------------------------------------------

    def avatar_path(self, user_id):
        return self.avatars / f"{int(user_id)}.jpg"

    def avatar_url(self, user_id):
        path = self.avatar_path(user_id)
        return f"/avatars/{int(user_id)}.jpg?v={int(path.stat().st_mtime)}" if path.exists() else None

    @staticmethod
    def _redraw(data, path, square=None, fit_within=None):
        """Any common picture format, redrawn as a fresh JPEG (cropped to a square,
        or shrunk to fit): nothing from the original file (hidden data such as a
        photo's location, or anything malicious) is kept."""
        from PIL import Image, ImageOps

        Image.MAX_IMAGE_PIXELS = 40_000_000  # refuse "decompression bombs"
        try:
            with Image.open(io.BytesIO(data)) as picture:
                picture = ImageOps.exif_transpose(picture).convert("RGB")  # phones store rotation separately
                if square:
                    picture = ImageOps.fit(picture, (square, square), Image.Resampling.LANCZOS)
                else:
                    picture.thumbnail(fit_within, Image.Resampling.LANCZOS)
        except Exception:
            raise ApiError(400, "That doesn't look like a picture CloudPlay can read (try a JPEG or PNG).") from None
        partial = path.with_suffix(".part")
        picture.save(partial, "JPEG", quality=88)
        partial.replace(path)

    def set_avatar(self, user, data):
        self._redraw(data, self.avatar_path(user["id"]), square=AVATAR_SIZE)
        return {"avatar": self.avatar_url(user["id"])}

    def background_path(self, user_id):
        return self.backgrounds / f"{int(user_id)}.jpg"

    def background_url(self, user_id):
        path = self.background_path(user_id)
        return f"/backgrounds/{int(user_id)}.jpg?v={int(path.stat().st_mtime)}" if path.exists() else None

    def set_background(self, user, data):
        self._redraw(data, self.background_path(user["id"]), fit_within=BACKGROUND_MAX)
        result = self.update_settings(user, {"background": "custom"})
        return {**result, "background_image": self.background_url(user["id"])}

    def remove_background(self, user):
        self.background_path(user["id"]).unlink(missing_ok=True)
        current = self._settings(self.store.one("SELECT settings FROM users WHERE id = ?", (user["id"],)))
        result = self.update_settings(user, {"background": "plain"}) if current["background"] == "custom" \
            else {"settings": current}
        return {**result, "background_image": None}

    def remove_avatar(self, user):
        self.avatar_path(user["id"]).unlink(missing_ok=True)
        return {"avatar": None}

    def rename(self, user, username):
        username = self._valid_username(username)
        with self.store.lock:
            if self._username_taken(username, except_id=user["id"]):
                raise ApiError(409, "That username is taken.")
            self.store.run("UPDATE users SET username = ? WHERE id = ?", (username, user["id"]))
        return {"username": username}

    def logout(self, token):
        self.store.run("DELETE FROM tokens WHERE token_hash = ?", (_sha256(token),))

    def authenticate(self, token):
        row = self.store.one(
            "SELECT u.* FROM tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = ? AND t.expires_at > ?",
            (_sha256(token or ""), time.time()),
        )
        if not row:
            raise ApiError(401, "Please sign in.")
        return row

    def _issue_token(self, user_id):
        token = secrets.token_urlsafe(32)
        self.store.run("INSERT INTO tokens VALUES (?, ?, ?)", (_sha256(token), user_id, time.time() + TOKEN_TTL))
        return {"token": token}

    def _check_rate(self, ip):
        with self._failures_lock:
            recent = [t for t in self._failures.get(ip, []) if t > time.time() - LOGIN_WINDOW]
            self._failures[ip] = recent
            if len(recent) >= LOGIN_MAX_FAILURES:
                raise ApiError(429, "Too many failed sign-in attempts. Wait a few minutes and try again.")

    def _record_failure(self, ip):
        with self._failures_lock:
            self._failures.setdefault(ip, []).append(time.time())

    # --- user-facing state ----------------------------------------------

    def me(self, user):
        with self.store.lock:
            self.sweep()
            session = self.store.one(
                "SELECT id, game, status FROM sessions WHERE user_id = ? AND status IN ('pending', 'active') "
                "ORDER BY created_at DESC LIMIT 1",
                (user["id"],),
            )
            return {
                "username": user["username"],
                "is_admin": bool(user["is_admin"]),
                "can_invite": bool(user["is_admin"]) and self.shared,
                "avatar": self.avatar_url(user["id"]),
                "settings": self._settings(user),
                "background_image": self.background_url(user["id"]),
                "session": dict(session) if session else None,
            }

    def games(self, user):
        imported = [self._game_info(row, user["is_admin"]) for row in self.store.all("SELECT * FROM games ORDER BY created_at")]
        return {"games": imported}

    def _game_info(self, row, admin):
        info = {
            "slug": row["slug"],
            "title": row["title"],
            "description": RUNNER_LABELS[row["runner"]],
            "controls": "Keyboard, mouse or gamepad",
            "accent": row["accent"],
        }
        thumbnail = self.thumbnail_path(row["slug"])
        if row["runner"] == "steam" and not thumbnail.exists():
            art = steam.artwork(row["path"])  # Steam's own banner until there's a screenshot from play
            if art:
                shutil.copyfile(art, thumbnail)
        if thumbnail.exists():
            info["thumbnail"] = f"/thumbnails/{row['slug']}.jpg?v={int(thumbnail.stat().st_mtime)}"
        if admin:
            if row["runner"] == "steam":
                info["path"] = f"Steam app {row['path']}"
            elif row["runner"] == "console":
                info["path"] = "{nickname} at {address}".format(**json.loads(row["path"]))
            elif row["runner"] == "flatpak":
                info["path"] = f"Flathub app {row['path']}"
            elif row["runner"] == "epic":
                info["path"] = f"Epic game {row['path']}"
            else:
                info["path"] = row["path"]
        return info

    def thumbnail_path(self, slug):
        return self.thumbnails / f"{slug}.jpg"

    def _artwork_lookup(self, names):
        """The lookup of the banner for these names: started now if it isn't
        already running or done (it runs in the background)."""
        key = tuple(names)
        with self.artwork_lock:
            entry = self.artwork.get(key)
            if entry:
                return entry
            if len(self.artwork) >= 50:  # forget the oldest
                del self.artwork[next(iter(self.artwork))]
            entry = self.artwork[key] = {"done": threading.Event(), "image": None}

        def look_up():
            try:
                entry["image"] = steam.store_artwork(names)
            finally:
                entry["done"].set()
                if not entry["image"]:
                    with self.artwork_lock:  # offline, or not found: try afresh next time
                        if self.artwork.get(key) is entry:
                            del self.artwork[key]

        threading.Thread(target=look_up, daemon=True).start()
        return entry

    def prefetch_artwork(self, user, body):
        """The Import window asks for the banner while the owner is still picking
        the game, so it's there the moment the game is added."""
        self._require_admin(user)
        if self.fetch_artwork:
            self._artwork_lookup(self._artwork_names(str(body.get("title") or ""), str(body.get("path") or "")))
        return {"ok": True}

    @staticmethod
    def _artwork_names(title, path):
        return [name for name in (title.strip(), os.path.basename(os.path.dirname(path))) if name]

    def _save_artwork(self, row, image):
        partial = self.thumbnail_path(row["slug"]).with_suffix(".part")
        partial.write_bytes(image)
        partial.replace(self.thumbnail_path(row["slug"]))  # never a half-written image on the page
        log.info("found cover art for %s", row["title"])

    def _look_up_artwork(self, row):
        """The game's official banner (by its name, then its folder's name). If
        it was looked up ahead, it's saved at once; otherwise in the background,
        so importing isn't held up by the network."""
        entry = self._artwork_lookup(self._artwork_names(row["title"], row["path"]))
        if entry["done"].is_set():
            if entry["image"]:
                self._save_artwork(row, entry["image"])
            return

        def wait():
            entry["done"].wait(30)
            if entry["image"]:
                self._save_artwork(row, entry["image"])

        threading.Thread(target=wait, daemon=True).start()



    # --- imported PC games ------------------------------------------------

    def _require_admin(self, user):
        if not user["is_admin"]:
            raise ApiError(403, "Only the server owner can manage games.")

    def steam_library(self, user):
        """Steam games installed on this computer, for the import dialog."""
        self._require_admin(user)
        if not steam.available():
            return {"available": False, "games": []}
        imported = {row["path"] for row in self.store.all("SELECT path FROM games WHERE runner = 'steam'")}
        games = [{**g, "imported": str(g["appid"]) in imported} for g in steam.installed_games()]
        return {"available": True, "games": games}

    def import_game(self, user, body):
        self._require_admin(user)
        title = str(body.get("title") or "").strip()
        if not 1 <= len(title) <= 60:
            raise ApiError(400, "Give the game a name (up to 60 characters).")
        if body.get("steam_appid") is not None:
            return self._import_steam_game(user, title, body.get("steam_appid"))
        path = os.path.abspath(os.path.expanduser(str(body.get("path") or "")))
        if not os.path.isfile(path):
            raise ApiError(400, "There's no file at that path.")
        runner = body.get("runner") or detect_runner(path)
        if runner not in RUNNER_LABELS:
            raise ApiError(400, "Pick how to run it: Windows (Wine) or Linux.")
        if runner == "wine" and not shutil.which("wine"):
            raise ApiError(400, "Windows games need Wine, which isn't installed. Try: sudo apt install wine")
        if runner == "native" and not os.access(path, os.X_OK):
            raise ApiError(400, f"That file isn't a program. Pick the game's launcher, or make it runnable: chmod +x '{path}'")
        try:
            args = shlex.split(str(body.get("args") or ""))
        except ValueError:
            raise ApiError(400, "The launch options have an unmatched quote.") from None
        return self._add_game(user, title, runner, path, args)

    def _add_game(self, user, title, runner, path, args, look_up=True):
        slug = f"pc-{secrets.token_hex(4)}"
        self.store.run(
            "INSERT INTO games(slug, title, runner, path, args, accent, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (slug, title, runner, path, json.dumps(args), secrets.choice(ACCENTS), user["id"], time.time()),
        )
        row = self.store.one("SELECT * FROM games WHERE slug = ?", (slug,))
        if runner != "steam" and self.fetch_artwork and look_up:
            self._look_up_artwork(row)
        return self._game_info(row, True)

    def console_status(self, user):
        """For the Console settings: is chiaki-ng there, which consoles are linked."""
        self._require_admin(user)
        added = {json.loads(r["path"])["nickname"] for r in self.store.all("SELECT path FROM games WHERE runner = 'console'")}
        consoles = [{**c, "added": c["nickname"] in added} for c in console.linked_consoles()]
        return {
            "installed": console.installed(), "consoles": consoles,
            "installing": console.install_state["running"], "install_error": console.install_state["error"],
        }

    def install_chiaki(self, user):
        self._require_admin(user)
        console.install()
        return self.console_status(user)

    def open_chiaki(self, user):
        self._require_admin(user)
        try:
            console.open_app()
        except OSError:
            raise ApiError(503, "Couldn't open chiaki-ng on this computer. Open it from the app menu instead.") from None
        return {"ok": True}

    def add_console(self, user, body):
        self._require_admin(user)
        nickname, address = str(body.get("nickname") or ""), str(body.get("address") or "").strip()
        if nickname not in {c["nickname"] for c in console.linked_consoles()}:
            raise ApiError(400, "That console isn't linked in chiaki-ng.")
        if not console.ADDRESS_RE.match(address):
            raise ApiError(400, "Enter the console's network address, like 192.168.1.20.")
        return self._add_game(user, "PlayStation", "console", json.dumps({"nickname": nickname, "address": address}), [])

    # --- the store (common/store.py) ---------------------------------------

    def store_search(self, user, query):
        """Steam (at Steam's prices here) and Epic games, marked with what's
        already installed or in the library."""
        self._require_admin(user)
        if len(query) > 100:
            raise ApiError(400, "That search is too long.")
        in_library = {(r["runner"], r["path"]) for r in self.store.all("SELECT runner, path FROM games")}
        # Every store and every installed-check at once: one after another took seconds.
        with ThreadPoolExecutor(4) as pool:
            found = pool.submit(store.search, query)
            epic_part = pool.submit(self._epic_results, query, in_library)
            steam_ids = pool.submit(lambda: {str(g["appid"]) for g in steam.installed_games()} if steam.available() else set())
            results, steam_installed = found.result(), steam_ids.result()
        for item in results["steam"] or []:
            item["installed"] = item["id"] in steam_installed
            item["in_library"] = ("steam", item["id"]) in in_library
        results["steam_available"] = steam.available()
        results["epic"] = epic_part.result()
        self._mark_anticheat([*(results["steam"] or []), *(results["epic"]["owned"] or []), *(results["epic"]["free"] or [])])
        return results

    def purchase_history(self, user):
        """Games got through the store, newest first, with what the store showed
        they cost then, and the total. (Receipts are in Steam's and Epic's own
        account pages: CloudPlay never sees them.)"""
        self._require_admin(user)
        rows = self.store.all("SELECT * FROM purchases WHERE user_id = ? ORDER BY got_at DESC LIMIT 500", (user["id"],))
        totals = {}
        for r in rows:
            if r["price"]:
                totals[r["currency"] or ""] = totals.get(r["currency"] or "", 0) + r["price"]
        return {"items": [{"source": r["source"], "id": r["game_id"], "name": r["name"], "image": r["image"],
                           "price": r["price"], "currency": r["currency"], "got_at": r["got_at"]} for r in rows],
                "totals": totals,
                "receipts": {"steam": "https://store.steampowered.com/account/history/",
                             "epic": "https://www.epicgames.com/account/transactions"}}

    @staticmethod
    def _mark_anticheat(items):
        """Games whose anti-cheat blocks Linux: they can't be played here."""
        for item in items:
            item["wont_run"] = anticheat.wont_run(item["source"], item["id"], item["name"], item.get("namespace"))

    def _epic_results(self, query, in_library):
        """The Epic part of the store: sign-in state, the account's games and
        Epic's free games, filtered by the search."""
        words = query.lower().split()
        matches = lambda name: all(w in (name or "").lower() for w in words)  # noqa: E731
        account = self._cached("epic_account", 60, epic.account)
        owned = None
        if account:
            with self.store_lock:
                cached = self.epic_owned
            if not cached or time.time() - cached[0] > EPIC_OWNED_CACHE_SECONDS or cached[1] != account:
                games = epic.owned()
                cached = (time.time(), account, games) if games is not None else None
                with self.store_lock:
                    self.epic_owned = cached
            installed = epic.installed()
            owned = [{**g, "source": "epic", "installed": g["id"] in installed, "in_library": ("epic", g["id"]) in in_library}
                     for g in (cached[2] if cached else []) if matches(g["name"])]
        free = self._cached("epic_free", 1800, lambda: epic.free_games(store.country()))
        return {"ready": epic.available(), "setup": dict(epic.setup_state), "account": account, "login_url": epic.LOGIN_URL,
                "owned": owned, "free": [g for g in free if matches(g["name"])] if free is not None else None}

    def _cached(self, name, seconds, fetch):
        """fetch(), remembered for a while (things that rarely change)."""
        with self.store_lock:
            hit = self.cache.get(name)
        if hit and time.time() - hit[0] < seconds:
            return hit[1]
        value = fetch()
        if value is not None:
            with self.store_lock:
                self.cache[name] = (time.time(), value)
        return value

    def epic_setup(self, user):
        self._require_admin(user)
        epic.setup()
        return {"setup": dict(epic.setup_state), "ready": epic.available()}

    def epic_sign_in(self, user, body):
        self._require_admin(user)
        if not epic.available():
            raise ApiError(400, "Set up Epic Games first.")
        error = epic.sign_in(str(body.get("code") or "")[:4000])
        if error:
            raise ApiError(400, error)
        with self.store_lock:
            self.epic_owned = None
            self.cache.pop("epic_account", None)
        return {"account": epic.account()}

    def epic_sign_out(self, user):
        self._require_admin(user)
        epic.sign_out()
        with self.store_lock:
            self.epic_owned = None
            self.cache.pop("epic_account", None)
        return {"ok": True}

    def store_get(self, user, body):
        """Get a game from the store: a Steam game is bought or installed in the
        Steam client here; an Epic game is installed with Legendary. Either way
        it's added to the library once it's installed."""
        self._require_admin(user)
        source, game_id = body.get("source"), str(body.get("id") or "")
        title = str(body.get("name") or "").strip()[:60] or game_id
        images = [u for u in (body.get("image"), body.get("image_fallback")) if self._store_image_ok(u)]
        # For the purchase history: the price the store showed for it.
        price = body.get("price")
        record = {"source": source, "price": price if isinstance(price, int) and 0 <= price < 10_000_000 else None,
                  "currency": str(body.get("currency") or "")[:3] or None, "image": images[0] if images else None}
        if source == "epic":
            record["price"] = None  # (it was already the account's: installing it isn't buying it)
        if source == "steam":
            if not game_id.isdigit():
                raise ApiError(400, "That isn't a Steam game.")
            if not steam.available():
                raise ApiError(400, "Steam isn't installed on this computer.")
            installed = {str(g["appid"]) for g in steam.installed_games()}
            if game_id in installed:  # already there: just add it
                return {"added": self._add_store_game(user, "steam", game_id, title, images)}
            store.open_in_steam(game_id, buy=bool(body.get("buy")))
            with self.store_lock:
                self.steam_waiting[game_id] = (time.time(), title, user["id"], images, record)
                self._watch_steam()
            return {"waiting": "steam"}
        if source == "epic":
            if not epic.APP_NAME_RE.match(game_id):
                raise ApiError(400, "That isn't an Epic game.")
            if not epic.account():
                raise ApiError(400, "Sign in to Epic Games first.")
            if game_id in epic.installed():
                return {"added": self._add_store_game(user, "epic", game_id, title, images)}
            if not body.get("confirmed"):  # a big download is announced first, with its size
                size = epic.download_size(game_id)
                if size and size > EPIC_ASK_ABOVE:
                    return {"confirm": f"{size / 1e9:.0f} GB"}
            epic.install(game_id, lambda app: self._add_store_game(user, "epic", app, title, images, record))
            return {"waiting": "epic"}
        raise ApiError(400, "Pick a game from the store.")

    def store_uninstall(self, user, body):
        """Uninstall a game got through the store (its files go) and take it out
        of the library. Steam games are uninstalled by Steam, after it asks."""
        self._require_admin(user)
        source, game_id = body.get("source"), str(body.get("id") or "")
        runner = {"steam": "steam", "epic": "epic"}.get(source)
        valid = {"steam": str.isdigit, "epic": epic.APP_NAME_RE.match}.get(source)
        if not runner or not valid(game_id):
            raise ApiError(400, "Pick an installed game from the store.")
        playing = self.store.one(
            "SELECT 1 FROM sessions s JOIN games g ON g.slug = s.game WHERE g.runner = ? AND g.path = ? "
            "AND s.status IN ('pending', 'active', 'ending')", (runner, game_id))
        if playing:
            raise ApiError(409, "Someone is playing it right now: end that game first.")
        if source == "steam":
            if not steam.available():
                raise ApiError(400, "Steam isn't installed on this computer.")
            store.open_in_steam(game_id, uninstall=True)
            with self.store_lock:
                self.steam_waiting.pop(game_id, None)
                self.steam_uninstalling[game_id] = time.time()
                self._watch_steam()
            return {"waiting": "steam"}
        error = epic.uninstall(game_id)
        if error:
            raise ApiError(400, error)
        self._remove_from_library(runner, game_id)
        return {"ok": True}

    def store_cancel(self, user, body):
        """Stop getting a game: a download under way, or waiting for Steam."""
        self._require_admin(user)
        source, game_id = body.get("source"), str(body.get("id") or "")
        if source == "epic":
            epic.cancel_install(game_id)
        elif source == "steam":
            with self.store_lock:
                self.steam_waiting.pop(game_id, None)  # (a download Steam started carries on in Steam)
        else:
            raise ApiError(400, "Pick a game from the store.")
        return {"ok": True}

    def _remove_from_library(self, runner, path):
        for row in self.store.all("SELECT slug FROM games WHERE runner = ? AND path = ?", (runner, path)):
            self._delete_game(row["slug"])

    def store_status(self, user):
        self._require_admin(user)
        with self.store_lock:
            waiting = sorted(self.steam_waiting)
            uninstalling = sorted(self.steam_uninstalling)
        return {"epic": {k: dict(v) for k, v in epic.installs.items()},
                "epic_setup": dict(epic.setup_state), "steam_waiting": waiting, "steam_uninstalling": uninstalling,
                "steam_running": bool(steam.available() and steam.running_pid())}

    def _add_store_game(self, user, runner, path, title, images=(), record=None):
        if record:  # got through the store: into the purchase history
            self.store.run("INSERT INTO purchases(user_id, source, game_id, name, image, price, currency, got_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                           (user["id"], record["source"], path, title, record.get("image"), record.get("price"), record.get("currency"), time.time()))
        existing = self.store.one("SELECT * FROM games WHERE runner = ? AND path = ?", (runner, path))
        if existing:
            return self._game_info(existing, True)
        info = self._add_game(user, title, runner, path, [], look_up=not images)
        if images and self.fetch_artwork:
            row = self.store.one("SELECT * FROM games WHERE slug = ?", (info["slug"],))
            threading.Thread(target=self._store_artwork, args=(row, list(images)), daemon=True).start()
        return info

    @staticmethod
    def _store_image_ok(url):
        if not isinstance(url, str) or len(url) > 1000:
            return False
        parsed = urllib.parse.urlparse(url)
        return parsed.scheme == "https" and parsed.hostname in STORE_IMAGE_HOSTS

    def _store_artwork(self, row, images):
        """The store's own picture of the game as its library cover."""
        thumbnail = self.thumbnail_path(row["slug"])
        for url in images:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "CloudPlay"})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = resp.read(8 * 1024 * 1024)
                self._redraw(data, thumbnail, fit_within=(920, 430))
                return
            except (OSError, ApiError, ValueError):
                continue


    def _watch_steam(self):
        """Adds Steam games got from the store once Steam has installed them, and
        takes them out of the library once Steam has uninstalled them."""
        if self.steam_watcher and self.steam_watcher.is_alive():
            return

        def watch():
            while True:
                time.sleep(5)
                with self.store_lock:
                    for appid, (since, *_rest) in list(self.steam_waiting.items()):
                        if time.time() - since > STEAM_WAIT_SECONDS:
                            del self.steam_waiting[appid]
                    for appid, since in list(self.steam_uninstalling.items()):
                        if time.time() - since > STEAM_WAIT_SECONDS:
                            del self.steam_uninstalling[appid]
                    if not self.steam_waiting and not self.steam_uninstalling:
                        return
                    waiting = dict(self.steam_waiting)
                    uninstalling = list(self.steam_uninstalling)
                installed = {str(g["appid"]): g["name"] for g in steam.installed_games()}
                for appid in uninstalling:
                    if appid not in installed:
                        self._remove_from_library("steam", appid)
                        with self.store_lock:
                            self.steam_uninstalling.pop(appid, None)
                for appid, (_since, title, uid, images, record) in waiting.items():
                    if appid in installed:
                        owner = self.store.one("SELECT * FROM users WHERE id = ?", (uid,))
                        if owner:
                            self._add_store_game(owner, "steam", appid, title or installed[appid], images, record)
                        with self.store_lock:
                            self.steam_waiting.pop(appid, None)

        self.steam_watcher = threading.Thread(target=watch, daemon=True)
        self.steam_watcher.start()

    def _import_steam_game(self, user, title, appid):
        installed = {g["appid"] for g in steam.installed_games()}
        if not isinstance(appid, int) or appid not in installed:
            raise ApiError(400, "That game isn't installed in Steam on this computer.")
        return self._add_game(user, title, "steam", str(appid), [])

    def delete_game(self, user, slug):
        self._require_admin(user)
        return self._delete_game(slug)

    def _delete_game(self, slug):
        with self.store.lock:
            if not self.store.run("DELETE FROM games WHERE slug = ?", (slug,)).rowcount:
                raise ApiError(404, "That game doesn't exist.")
            self.thumbnail_path(slug).unlink(missing_ok=True)
            self.store.run(
                "UPDATE sessions SET status = 'ended', ended_at = ?, end_reason = 'game_removed' WHERE game = ? AND status = 'pending'",
                (time.time(), slug),
            )
            self.store.run("UPDATE sessions SET status = 'ending' WHERE game = ? AND status = 'active'", (slug,))
        return {"ok": True}

    def browse(self, user, directory):
        """List folders and runnable files so the owner can pick a game to import."""
        self._require_admin(user)
        path = os.path.abspath(os.path.expanduser(directory or "~"))
        if not os.path.isdir(path):
            raise ApiError(400, "That folder doesn't exist.")
        entries = []
        try:
            with os.scandir(path) as it:
                for entry in it:
                    try:
                        if entry.is_dir():
                            entries.append({"name": entry.name, "type": "dir"})
                        elif entry.is_file():
                            runner = detect_runner(entry.path)
                            if runner == "wine" or os.access(entry.path, os.X_OK):
                                entries.append({"name": entry.name, "type": "file", "runner": runner})
                    except OSError:
                        continue
        except PermissionError:
            raise ApiError(403, "CloudPlay isn't allowed to open that folder.") from None
        entries.sort(key=lambda e: (e["type"] != "dir", e["name"].startswith("."), e["name"].casefold()))
        parent = os.path.dirname(path)
        return {"dir": path, "parent": parent if parent != path else None, "entries": entries[:MAX_BROWSE_ENTRIES]}

    # --- sessions -------------------------------------------------------

    def create_session(self, user, slug):
        row = self.store.one("SELECT * FROM games WHERE slug = ?", (str(slug),))
        if not row:
            raise ApiError(404, "That game doesn't exist.")
        launch = {"runner": row["runner"], "path": row["path"], "args": json.loads(row["args"])}
        title = row["title"]
        now = time.time()
        with self.store.lock:
            self.sweep()
            # One stream per account: starting a new game replaces the old one.
            self.store.run(
                "UPDATE sessions SET status = 'ended', ended_at = ?, end_reason = 'replaced' "
                "WHERE user_id = ? AND status = 'pending'",
                (now, user["id"]),
            )
            self.store.run("UPDATE sessions SET status = 'ending' WHERE user_id = ? AND status = 'active'", (user["id"],))

            host = self._pick_host(now, user["id"])
            if not host:
                raise ApiError(503, "All game servers are busy. Try again in a minute.")

            sid = secrets.token_hex(8)
            self.store.run(
                "INSERT INTO sessions(id, user_id, game, host_id, status, created_at) VALUES (?, ?, ?, ?, 'pending', ?)",
                (sid, user["id"], slug, host["id"], now),
            )
        claims = {"sid": sid, "uid": user["id"], "game": slug, "host": host["id"], "launch": launch, "title": title}
        ticket = tickets.sign(claims, self.ticket_key, TICKET_TTL)
        return {"session_id": sid, "ws_url": host["ws_url"], "ticket": ticket}

    def stop_session(self, user, sid):
        with self.store.lock:
            row = self.store.one("SELECT status FROM sessions WHERE id = ? AND user_id = ?", (sid, user["id"]))
            if not row:
                raise ApiError(404, "Session not found.")
            if row["status"] == "pending":
                self.store.run(
                    "UPDATE sessions SET status = 'ended', ended_at = ?, end_reason = 'stopped' WHERE id = ?",
                    (time.time(), sid),
                )
            elif row["status"] == "active":
                self.store.run("UPDATE sessions SET status = 'ending' WHERE id = ?", (sid,))
        return {"ok": True}

    def _pick_host(self, now, user_id):
        # Hosts run each game on a hidden screen of its own (desktop = 1), so
        # only capacity limits them. A host showing games on its real desktop
        # (desktop = 2) fits one at a time; the player's own game that is
        # shutting down doesn't count, the host waits for it to exit.
        rows = self.store.all(
            "SELECT h.*, (SELECT COUNT(*) FROM sessions s WHERE s.host_id = h.id "
            "AND s.status IN ('pending', 'active', 'ending')) AS load, "
            "(SELECT COUNT(*) FROM sessions s WHERE s.host_id = h.id AND s.game LIKE 'pc-%' "
            "AND (s.status IN ('pending', 'active') OR (s.status = 'ending' AND s.user_id != ?))) AS desktop_load "
            "FROM hosts h WHERE h.last_seen > ?",
            (user_id, now - HOST_TIMEOUT),
        )
        free = [r for r in rows if r["load"] < r["capacity"] and r["desktop"] and (r["desktop"] == 1 or not r["desktop_load"])]
        return min(free, key=lambda r: r["load"] / r["capacity"], default=None)

    # --- hosts ----------------------------------------------------------

    def heartbeat(self, body):
        try:
            host_id = str(body["host_id"])
            ws_url = str(body["ws_url"])
            capacity = int(body["capacity"])
            region = str(body.get("region", "default"))
            desktop = min(2, int(body.get("desktop") or 0))  # 0: no PC games, 1: hidden screens, 2: shared desktop
            active = {str(s) for s in body.get("active", [])}
            ended = [(str(e["sid"]), float(e["seconds"]), str(e.get("reason", "ended"))) for e in body.get("ended", [])]
        except (KeyError, TypeError, ValueError):
            raise ApiError(400, "Malformed heartbeat.") from None
        if not ws_url.startswith(("ws://", "wss://")):
            raise ApiError(400, "ws_url must be a ws:// or wss:// URL.")

        now = time.time()
        with self.store.lock:
            self.store.run(
                "INSERT INTO hosts(id, ws_url, region, capacity, desktop, last_seen) VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET ws_url = excluded.ws_url, region = excluded.region, "
                "capacity = excluded.capacity, desktop = excluded.desktop, last_seen = excluded.last_seen",
                (host_id, ws_url, region, capacity, desktop, now),
            )
            for sid, seconds, reason in ended:
                self.store.run(
                    "UPDATE sessions SET status = 'ended', ended_at = ?, seconds = ?, end_reason = ? "
                    "WHERE id = ? AND host_id = ? AND status != 'ended'",
                    (now, max(0.0, seconds), reason, sid, host_id),
                )

            terminate = []
            for sid in active:
                row = self.store.one("SELECT status FROM sessions WHERE id = ? AND host_id = ?", (sid, host_id))
                if row is None or row["status"] in ("ending", "ended"):
                    terminate.append(sid)
                elif row["status"] == "pending":
                    self.store.run("UPDATE sessions SET status = 'active', started_at = ? WHERE id = ?", (now, sid))

            # Sessions we think are running there but the host no longer reports.
            for row in self.store.all(
                "SELECT id, started_at FROM sessions WHERE host_id = ? AND status IN ('active', 'ending')", (host_id,)
            ):
                if row["id"] not in active:
                    self._end(row["id"], now, now - (row["started_at"] or now), "lost")
            self.sweep()
        return {"terminate": terminate}

    def sweep(self):
        """Expire tickets nobody redeemed, sessions on dead hosts, and old tokens."""
        now = time.time()
        with self.store.lock:
            self.store.run(
                "UPDATE sessions SET status = 'ended', ended_at = ?, end_reason = 'never_connected' "
                "WHERE status = 'pending' AND created_at < ?",
                (now, now - TICKET_TTL - 10),
            )
            for row in self.store.all(
                "SELECT s.id, s.started_at, h.last_seen FROM sessions s JOIN hosts h ON h.id = s.host_id "
                "WHERE s.status IN ('pending', 'active', 'ending') AND h.last_seen < ?",
                (now - HOST_TIMEOUT,),
            ):
                played = row["last_seen"] - row["started_at"] if row["started_at"] else 0
                self._end(row["id"], now, played, "host_lost")
            self.store.run("DELETE FROM tokens WHERE expires_at < ?", (now,))

    def _end(self, sid, now, seconds, reason):
        self.store.run(
            "UPDATE sessions SET status = 'ended', ended_at = ?, seconds = ?, end_reason = ? WHERE id = ?",
            (now, max(0.0, seconds), reason, sid),
        )


class Handler(BaseHTTPRequestHandler):
    server_version = "CloudPlay"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        log.debug("%s %s", self.address_string(), fmt % args)

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def _dispatch(self, method):
        url = urlparse(self.path)
        path = url.path
        self.query = parse_qs(url.query)
        if path.startswith("/api/"):
            try:
                status, body = self._api(method, path)
            except ApiError as e:
                status, body = e.status, {"error": e.message}
            except Exception:
                log.exception("unhandled error on %s %s", method, path)
                status, body = 500, {"error": "Something went wrong on our side."}
            self._send(status, json.dumps(body).encode(), "application/json")
        elif method == "GET" and path.startswith("/backgrounds/"):
            name = path.rsplit("/", 1)[1].removesuffix(".jpg")
            self._image(self.server.cp.background_path(name) if name.isdigit() else None)
        elif method == "GET" and path.startswith("/avatars/"):
            name = path.rsplit("/", 1)[1].removesuffix(".jpg")
            self._image(self.server.cp.avatar_path(name) if name.isdigit() else None)
        elif method == "GET" and path.startswith("/thumbnails/"):
            self._thumbnail(path.rsplit("/", 1)[1].removesuffix(".jpg"))
        elif method == "GET":
            self._static(path)
        else:
            self._send(405, b"Method not allowed", "text/plain")

    def _api(self, method, path):
        cp = self.server.cp
        if (method, path) == ("POST", "/api/signup"):
            body = self._body()
            return 201, cp.signup(body.get("username"), body.get("password"), body.get("invite"))
        if (method, path) == ("GET", "/api/signup"):
            return 200, {"needs_invite": cp.needs_invite()}
        if (method, path) == ("POST", "/api/login"):
            body = self._body()
            return 200, cp.login(body.get("username"), body.get("password"), self.client_address[0])
        if (method, path) == ("POST", "/api/hosts/heartbeat"):
            if not hmac.compare_digest(self.headers.get("Authorization", ""), f"Bearer {cp.host_token}"):
                raise ApiError(401, "Bad host credentials.")
            return 200, cp.heartbeat(self._body())

        token = self.headers.get("Authorization", "").removeprefix("Bearer ")
        user = cp.authenticate(token)
        if (method, path) == ("GET", "/api/me"):
            return 200, cp.me(user)
        if (method, path) == ("POST", "/api/invites"):
            return 201, cp.create_invite(user)
        if (method, path) == ("POST", "/api/me/settings"):
            return 200, cp.update_settings(user, self._body())
        if (method, path) == ("POST", "/api/me/background"):
            return 200, cp.set_background(user, self._raw_body(MAX_AVATAR_UPLOAD))
        if (method, path) == ("DELETE", "/api/me/background"):
            return 200, cp.remove_background(user)
        if (method, path) == ("POST", "/api/me/avatar"):
            return 200, cp.set_avatar(user, self._raw_body(MAX_AVATAR_UPLOAD))
        if (method, path) == ("DELETE", "/api/me/avatar"):
            return 200, cp.remove_avatar(user)
        if (method, path) == ("POST", "/api/me/username"):
            return 200, cp.rename(user, self._body().get("username"))
        if (method, path) == ("GET", "/api/games"):
            return 200, cp.games(user)
        if (method, path) == ("POST", "/api/artwork/prefetch"):
            return 200, cp.prefetch_artwork(user, self._body())
        if (method, path) == ("POST", "/api/games"):
            return 201, cp.import_game(user, self._body())
        if method == "DELETE" and path.startswith("/api/games/"):
            return 200, cp.delete_game(user, path.rsplit("/", 1)[1])
        if (method, path) == ("GET", "/api/console"):
            return 200, cp.console_status(user)
        if (method, path) == ("POST", "/api/console"):
            return 201, cp.add_console(user, self._body())
        if (method, path) == ("POST", "/api/console/install"):
            return 200, cp.install_chiaki(user)
        if (method, path) == ("POST", "/api/console/open"):
            return 200, cp.open_chiaki(user)
        if (method, path) == ("GET", "/api/store"):
            return 200, cp.store_search(user, (self.query.get("q") or [""])[0])
        if (method, path) == ("POST", "/api/store/get"):
            return 200, cp.store_get(user, self._body())
        if (method, path) == ("POST", "/api/epic/setup"):
            return 200, cp.epic_setup(user)
        if (method, path) == ("POST", "/api/epic/signin"):
            return 200, cp.epic_sign_in(user, self._body())
        if (method, path) == ("POST", "/api/epic/signout"):
            return 200, cp.epic_sign_out(user)
        if (method, path) == ("GET", "/api/store/history"):
            return 200, cp.purchase_history(user)
        if (method, path) == ("POST", "/api/store/uninstall"):
            return 200, cp.store_uninstall(user, self._body())
        if (method, path) == ("POST", "/api/store/cancel"):
            return 200, cp.store_cancel(user, self._body())
        if (method, path) == ("GET", "/api/store/status"):
            return 200, cp.store_status(user)
        if (method, path) == ("GET", "/api/steam"):
            return 200, cp.steam_library(user)
        if (method, path) == ("GET", "/api/files"):
            return 200, cp.browse(user, self.query.get("dir", [""])[0])
        if (method, path) == ("POST", "/api/logout"):
            cp.logout(token)
            return 200, {"ok": True}
        if (method, path) == ("POST", "/api/sessions"):
            return 201, cp.create_session(user, self._body().get("game"))
        if method == "DELETE" and path.startswith("/api/sessions/"):
            return 200, cp.stop_session(user, path.rsplit("/", 1)[1])
        raise ApiError(404, "Not found.")

    def _raw_body(self, limit):
        length = int(self.headers.get("Content-Length") or 0)
        if length > limit:
            raise ApiError(413, "That file is too big.")
        return self.rfile.read(length)

    def _body(self):
        try:
            body = json.loads(self._raw_body(MAX_BODY) or b"{}")
        except ValueError:
            raise ApiError(400, "Request body must be JSON.") from None
        if not isinstance(body, dict):
            raise ApiError(400, "Request body must be a JSON object.")
        return body

    def _static(self, path):
        target = (WEB_DIR / (path.lstrip("/") or "index.html")).resolve()
        if not target.is_relative_to(WEB_DIR) or not target.is_file():
            target = WEB_DIR / "index.html"  # single-page app fallback
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self._send(200, target.read_bytes(), ctype)

    def _thumbnail(self, slug):
        self._image(self.server.cp.thumbnail_path(slug) if SLUG_RE.match(slug) else None)

    def _image(self, path):
        if path is None or not path.is_file():
            self._send(404, b"Not found", "text/plain")
            return
        self._send(200, path.read_bytes(), "image/jpeg")

    def _send(self, status, data, ctype):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            # (pictures in the store come from Steam's and Epic's own servers)
            "default-src 'self'; connect-src 'self' ws: wss:; img-src 'self' blob: data: "
            "https://shared.akamai.steamstatic.com https://shared.fastly.steamstatic.com "
            "https://cdn1.epicgames.com https://cdn2.unrealengine.com https://epicgames-download1.akamaized.net; "
            "style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com",
        )
        self.end_headers()
        self.wfile.write(data)


def make_server(bind, port, cp):
    server = ThreadingHTTPServer((bind, port), Handler)
    server.daemon_threads = True
    server.cp = cp
    return server


def main():
    parser = argparse.ArgumentParser(description="CloudPlay control plane")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default="cloudplay.db")
    args = parser.parse_args()
    secret = os.environ.get("CLOUDPLAY_SECRET")
    if not secret:
        raise SystemExit("Set CLOUDPLAY_SECRET (shared with stream hosts).")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    shared = args.bind not in ("127.0.0.1", "localhost", "::1")
    server = make_server(args.bind, args.port, ControlPlane(args.db, secret, shared=shared))
    log.info("control plane on http://%s:%d", args.bind, args.port)
    server.serve_forever()


if __name__ == "__main__":
    main()
