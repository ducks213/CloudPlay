"""Run the whole stack on one machine: control plane + one stream host."""
import argparse
import asyncio
import logging
import os
import secrets
import socket
import threading

from control.server import ControlPlane, make_server
from host.host import Host


async def run_host(args, secret):
    display = os.environ.get("DISPLAY") if args.on_screen else None
    host = Host(
        "local-1", secret, f"http://127.0.0.1:{args.port}", args.public_url, args.capacity, "local",
        desktop_display=display,
    )
    await host.start(args.bind, args.stream_port)
    await host.run_forever()


def lan_address():
    """This computer's address on the local network (no traffic is sent)."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        try:
            s.connect(("192.0.2.1", 9))  # picks the outgoing interface; UDP connect sends nothing
            return s.getsockname()[0]
        except OSError:
            return "127.0.0.1"


def main():
    parser = argparse.ArgumentParser(description="Run CloudPlay locally")
    parser.add_argument("--lan", action="store_true",
                        help="let other devices on your network play (by default only this computer can)")
    parser.add_argument("--bind", help="address to listen on (default: this computer only, or all with --lan)")
    parser.add_argument("--port", type=int, default=8080, help="web + API port")
    parser.add_argument("--stream-port", type=int, default=8081)
    parser.add_argument("--public-url", help="stream URL browsers use, e.g. ws://192.168.1.20:8081")
    parser.add_argument("--capacity", type=int, default=4)
    parser.add_argument("--db", default="cloudplay.db")
    parser.add_argument("--on-screen", action="store_true", help="show PC games on this computer's desktop instead of hidden screens")
    args = parser.parse_args()
    host = lan_address() if args.lan else "localhost"
    if args.bind is None:
        args.bind = "0.0.0.0" if args.lan else "127.0.0.1"
    if args.public_url is None:
        args.public_url = f"ws://{host}:{args.stream_port}"

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    os.makedirs(os.path.dirname(os.path.abspath(args.db)), exist_ok=True)
    secret = os.environ.get("CLOUDPLAY_SECRET") or secrets.token_hex(32)

    server = make_server(args.bind, args.port, ControlPlane(args.db, secret, shared=args.lan))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"\n  CloudPlay is running → http://{host}:{args.port}")
    print("  Other devices on your network can play too.\n" if args.lan else "  Only this computer can reach it (start with --lan to share it on your network).\n")
    try:
        asyncio.run(run_host(args, secret))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
