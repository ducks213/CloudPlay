#!/usr/bin/env python3
"""The CloudPlay app: CloudPlay in a window of its own, without a browser.

It shows the CloudPlay pages from this computer's server in WebKitGTK, keeps
you signed in between runs, starts the server if it isn't running, and handles
full screen itself: since no browser sits around it, Esc always reaches the game.

The game's picture is shown natively (NativeVideo): drawing 1080p60 video in
the page costs over a processor core, and with a game running on the same
computer the picture couldn't keep up. The page does everything else, and
tells the app where the picture goes.
"""
import asyncio
import json
import os
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

import gi

# WebKitGTK's DMA-BUF renderer flickers on many systems (Intel graphics among
# them) while scrolling; the older route still uses the GPU and doesn't.
# (CLOUDPLAY_DMABUF=1 brings it back.)
if os.environ.get("CLOUDPLAY_DMABUF") != "1":
    os.environ.setdefault("WEBKIT_DISABLE_DMABUF_RENDERER", "1")

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("WebKit2", "4.1")
gi.require_version("Gst", "1.0")
from gi.repository import Gdk, GLib, Gst, Gtk, WebKit2  # noqa: E402

try:
    import websockets
except ImportError:  # no native video then: the page shows the picture itself
    websockets = None

URL = os.environ.get("CLOUDPLAY_URL", "http://localhost:8080/")
HERE = Path(__file__).resolve().parent
ICON = HERE.parent / "web" / "icon.png"
DATA = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "cloudplay" / "webview"

STARTING = """<html><body style="margin:0;height:100vh;display:grid;place-items:center;background:#17140f;
color:#b3a690;font:16px system-ui">Starting CloudPlay…</body></html>"""


class NativeVideo:
    """The game's H.264 video, received over its own connection to the stream
    server, decoded and scaled on the GPU and shown in a GTK widget laid over
    the page's picture (mouse events on it are handed to the page).

    It's drawn without GL (gtksink, not gtkglsink): a GL widget turns the rest
    of the window white with the WebKit renderer this app uses (see the top).
    The GPU scaler (vapostproc) only gives out widths in multiples of 64 here
    (other widths crash it), so the picture is scaled to the nearest one and
    the widget fits the last few pixels."""

    FRAME_KEY, FRAME_DELTA = 1, 2  # as in host/desktop.py

    @staticmethod
    def available():
        if websockets is None:
            return False
        Gst.init(None)
        need = ("appsrc", "h264parse", "gtksink")
        return all(Gst.ElementFactory.find(n) for n in need) and NativeVideo._decoder() is not None

    @staticmethod
    def _scaler():
        on_gpu = NativeVideo._decoder() == "vah264dec" and Gst.ElementFactory.find("vapostproc")
        return "vapostproc" if on_gpu else "videoconvertscale"

    @staticmethod
    def _decoder():
        return next((d for d in ("vah264dec", "avdec_h264", "openh264dec") if Gst.ElementFactory.find(d)), None)

    def __init__(self, on_size, on_closed):
        self.on_size, self.on_closed = on_size, on_closed
        self.pipeline = self.src = self.widget = None
        self.loop = self.ws = None
        self.frames = 0  # shown since the page last asked
        self.received = 0  # bytes of video, likewise
        self.size = None  # the game's picture size
        self.box = (1280, 720)  # what the picture is scaled to
        self.space = None  # the widget's size on screen

    def start(self, url):
        self.pipeline = Gst.parse_launch(
            "appsrc name=src is-live=true format=time do-timestamp=true "
            "caps=video/x-h264,stream-format=byte-stream,alignment=au ! "
            f"h264parse ! {self._decoder()} name=dec ! {self._scaler()} ! "
            "capsfilter name=box caps=video/x-raw,format=BGRx,width=1280,height=720 ! "
            "gtksink name=sink sync=false force-aspect-ratio=true")
        self.src = self.pipeline.get_by_name("src")
        sink = self.pipeline.get_by_name("sink")
        self.widget = sink.props.widget
        sink.get_static_pad("sink").add_probe(Gst.PadProbeType.BUFFER, self._shown)
        self.pipeline.get_by_name("dec").get_static_pad("src").add_probe(Gst.PadProbeType.BUFFER, self._decoded)
        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message::error", lambda _bus, _msg: self.fail())
        self.url = url
        return self.widget

    def play(self):
        """Once the widget is in the window and realized."""
        self.pipeline.set_state(Gst.State.PLAYING)
        threading.Thread(target=lambda: asyncio.run(self._receive(self.url)), daemon=True).start()

    def _shown(self, pad, info):
        self.frames += 1
        return Gst.PadProbeReturn.OK

    def _decoded(self, pad, info):
        caps = pad.get_current_caps()
        if caps:
            s = caps.get_structure(0)
            size = (s.get_value("width"), s.get_value("height"))
            if size != self.size:  # (the page maps the mouse by the game's own size)
                self.size = size
                GLib.idle_add(self.on_size, *size)
                GLib.idle_add(self.fit, *(self.space or self.box))
        return Gst.PadProbeReturn.OK

    def fit(self, width, height):
        """Scale the picture to fit this space, keeping the game's shape."""
        self.space = (width, height)
        if not self.size or self.pipeline is None:
            return False
        gw, gh = self.size
        w = min(width, round(height * gw / gh))
        w = max(64, w // 64 * 64)  # (the GPU scaler's widths, see the class)
        h = max(2, round(w * gh / gw) // 2 * 2)
        if (w, h) != self.box:
            self.box = (w, h)
            self.pipeline.get_by_name("box").set_property(
                "caps", Gst.Caps.from_string(f"video/x-raw,format=BGRx,width={w},height={h}"))
        return False

    async def _receive(self, url):
        self.loop = asyncio.get_running_loop()
        try:
            async with websockets.connect(url, max_size=None) as ws:
                self.ws = ws
                async for message in ws:
                    if isinstance(message, bytes) and len(message) > 5 and message[4] in (self.FRAME_KEY, self.FRAME_DELTA):
                        self.received += len(message)
                        self.src.emit("push-buffer", Gst.Buffer.new_wrapped(message[5:]))
        except (OSError, websockets.WebSocketException):
            pass
        GLib.idle_add(self.fail)

    def fail(self):
        if self.pipeline is not None:
            self.stop()
            self.on_closed()
        return False

    def stop(self):
        if self.loop and self.ws and not self.loop.is_closed():
            try:
                self.loop.call_soon_threadsafe(lambda: asyncio.ensure_future(self.ws.close()))
            except RuntimeError:  # its thread has just finished
                pass
        if self.pipeline is not None:
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline.get_bus().remove_signal_watch()
        self.pipeline = None


class App:
    def __init__(self):
        GLib.set_prgname("cloudplay")  # the window's class, so the taskbar shows CloudPlay's icon
        GLib.set_application_name("CloudPlay")
        self.window = Gtk.Window(title="")  # no name in the title bar
        self.window.set_default_size(1280, 800)
        if Gtk.IconTheme.get_default().has_icon("cloudplay"):
            self.window.set_icon_name("cloudplay")  # the installed icon, the same one the menu and taskbar show
        elif ICON.exists():
            self.window.set_icon_from_file(str(ICON))
        self.window.connect("destroy", Gtk.main_quit)
        self.window.connect("key-press-event", self.on_key)

        # Its own storage, so signing in survives restarts (and is separate from any browser).
        manager = WebKit2.WebsiteDataManager(
            base_data_directory=str(DATA / "data"), base_cache_directory=str(DATA / "cache"))
        context = WebKit2.WebContext.new_with_website_data_manager(manager)
        settings = WebKit2.Settings(
            enable_webaudio=True, enable_developer_extras=False, media_playback_requires_user_gesture=False,
            hardware_acceleration_policy=WebKit2.HardwareAccelerationPolicy.ALWAYS,
        )
        if settings.find_property("enable-webcodecs"):
            settings.set_property("enable-webcodecs", True)  # the H.264 video and Opus sound
        content = WebKit2.UserContentManager()
        content.register_script_message_handler("cloudplay")  # the page asks for full screen through this
        # Tells every page it's in the app, and whether the app can show games'
        # video natively, whatever its address (a link to "/" loses any ?app).
        content.add_script(WebKit2.UserScript.new(
            f"window.CLOUDPLAY_APP = {{native: {'true' if NativeVideo.available() else 'false'}}};",
            WebKit2.UserContentInjectedFrames.TOP_FRAME, WebKit2.UserScriptInjectionTime.START, None, None))
        content.connect("script-message-received::cloudplay", self.on_message)
        self.view = WebKit2.WebView(web_context=context, settings=settings, user_content_manager=content)
        self.view.connect("decide-policy", self.on_policy)
        self.view.connect("load-failed", self.on_load_failed)
        self.view.connect("load-changed", lambda _v, event: event == WebKit2.LoadEvent.STARTED and self.stop_video())
        # The page under everything; the native video, its fps readout and the
        # exit button on top, where the page says the picture is.
        self.overlay = Gtk.Overlay()
        self.overlay.add(self.view)
        self.window.add(self.overlay)
        self.video = None
        self.native = NativeVideo.available()
        # Each native piece gets exactly its own rectangle (get-child-position):
        # a GL video makes its whole area opaque, so nothing may be larger.
        self.positions = {}
        self.overlay.connect("get-child-position", self.child_position)
        self.hud = Gtk.Label(no_show_all=True)
        self.hud.get_style_context().add_class("cloudplay-hud")
        self.exit_full = Gtk.Button(label="✕ Exit full screen", halign=Gtk.Align.START, valign=Gtk.Align.START, no_show_all=True)
        self.exit_full.get_style_context().add_class("cloudplay-exit")
        self.exit_full.connect("clicked", lambda _b: self.run_js("document.querySelector('#exit-full').click()"))
        style = Gtk.CssProvider()
        style.load_from_data(b"""
            .cloudplay-hud { font: 12px monospace; color: #cceeee; background: rgba(0,0,0,.55); padding: 6px 10px; border-radius: 8px; }
            .cloudplay-exit { font-size: 13px; color: #f2e8d8; background: rgba(0,0,0,.6); border: 0; padding: 6px 12px; }
        """)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), style, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.overlay.add_overlay(self.hud)
        self.overlay.set_overlay_pass_through(self.hud, True)
        self.overlay.add_overlay(self.exit_full)
        self.rect = None
        self.full_window = False
        self.exit_timer = 0
        self.view.connect("motion-notify-event", self.on_motion)
        self.window.show_all()

        self.attempts = 0
        self.view.load_html(STARTING, None)
        self.start_server()
        GLib.timeout_add(300, self.load_when_ready)

    def start_server(self):
        try:
            subprocess.Popen(["systemctl", "--user", "start", "cloudplay"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass

    def load_when_ready(self):
        try:
            urllib.request.urlopen(URL, timeout=1).close()
        except OSError:
            self.attempts += 1
            if self.attempts < 60:
                return True  # try again shortly
            self.view.load_html(STARTING.replace("Starting CloudPlay…",
                                                 "CloudPlay's server isn't running. Try: systemctl --user start cloudplay"), None)
            return False
        self.view.load_uri(URL + ("?app&native" if self.native else "?app"))
        return False

    def on_load_failed(self, view, event, uri, error):
        if uri.startswith(URL):  # the server went away: wait for it to come back
            self.attempts = 0
            self.view.load_html(STARTING, None)
            GLib.timeout_add(1000, self.load_when_ready)
            return True
        return False

    def on_policy(self, view, decision, kind):
        # Links to other sites (store pages, help) open in the normal browser, not in here.
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri()
            if not uri.startswith((URL, "about:", "data:")) and uri != "about:blank":
                Gtk.show_uri_on_window(self.window, uri, Gtk.get_current_event_time())
                decision.ignore()
                return True
        return False

    def on_message(self, manager, message):
        value = message.get_js_value().to_string() if hasattr(message, "get_js_value") else message.to_string()
        if value == "fullscreen":
            self.window.fullscreen()
            self.full_window = True
        elif value == "window":
            self.window.unfullscreen()
            self.full_window = False
            self.exit_full.hide()
        elif value.startswith("{"):
            self.on_video_message(json.loads(value))

    # --- the native video (see NativeVideo) ---

    def run_js(self, code):
        self.view.evaluate_javascript(code, -1, None, None, None, None, None)

    def on_video_message(self, msg):
        if "video" in msg:  # start (a URL) or stop (null)
            self.stop_video()
            if msg["video"] and self.native:
                self.video = NativeVideo(self.on_video_size, self.on_video_closed)
                widget = self.video.start(msg["video"])
                widget.set_no_show_all(True)
                widget.set_can_focus(False)  # the keyboard stays with the page
                self.overlay.add_overlay(widget)
                self.overlay.reorder_overlay(widget, 0)  # under the readout and the button
                # The GL video takes the mouse itself (it can't let it through),
                # so it hands it to the page, which sends it to the game as before.
                widget.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK
                                  | Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.SCROLL_MASK
                                  | Gdk.EventMask.SMOOTH_SCROLL_MASK)
                widget.connect("button-press-event", self.on_video_mouse, "pointerdown")
                widget.connect("button-release-event", self.on_video_mouse, "pointerup")
                widget.connect("motion-notify-event", self.on_video_mouse, "pointermove")
                widget.connect("scroll-event", self.on_video_mouse, "wheel")
                widget.realize()
                self.set_video_cursor()
                self.video.play()
                self.place(self.rect)
        if "rect" in msg:  # where the picture is on the page, or null to hide it
            self.rect = msg["rect"]
            self.place(self.rect)
        if "cursor" in msg:  # the game hides its mouse pointer: hide it over the video too
            self.cursor_hidden = bool(msg["cursor"])
            self.set_video_cursor()
        if "hud" in msg:
            self.hud.set_text(msg["hud"] or "")
            self.place(self.rect)
        if "frames" in msg and self.video:  # the page asks how many were shown, once a second
            frames, self.video.frames = self.video.frames, 0
            received, self.video.received = self.video.received, 0
            self.run_js(f"player && player.nativeFrames && player.nativeFrames({frames}, {received})")

    def place(self, rect):
        widget = self.video and self.video.widget
        if not widget:
            self.hud.hide()
            return
        if not rect:
            widget.hide()
            self.hud.hide()
            self.exit_full.hide()
            return
        x, y, w, h = (max(0, round(v)) for v in rect)
        self.positions[widget] = (x, y, max(1, w), max(1, h))
        self.video.fit(max(64, w), max(2, h))
        widget.show()
        self.hud.set_visible(bool(self.hud.get_text()))
        hud_w, hud_h = self.hud.get_preferred_width()[1], self.hud.get_preferred_height()[1]
        self.positions[self.hud] = (max(0, x + w - hud_w - 10), y + 10, hud_w, hud_h)  # top right, like the page's
        bw, bh = self.exit_full.get_preferred_width()[1], self.exit_full.get_preferred_height()[1]
        self.positions[self.exit_full] = (x + 10, y + 10, bw, bh)
        self.overlay.queue_resize()

    def on_video_mouse(self, widget, event, kind):
        place = self.positions.get(widget)
        if not place:
            return False
        x, y = place[0] + event.x, place[1] + event.y  # in page coordinates
        if kind == "wheel":
            ok, _dx, dy = event.get_scroll_deltas()
            if not ok:
                dy = {Gdk.ScrollDirection.UP: -1, Gdk.ScrollDirection.DOWN: 1}.get(event.direction, 0)
            extra = f", deltaY: {dy}"
        elif kind == "pointermove":
            extra = ""
        else:
            if event.type != Gdk.EventType.BUTTON_PRESS and kind == "pointerdown":
                return True  # (double-click events: the two presses already went)
            extra = f", button: {event.button - 1}"
        self.run_js(f"player && player.nativePointer && player.nativePointer('{kind}', {{clientX: {x}, clientY: {y}{extra}}})")
        if kind == "pointerdown":
            self.view.grab_focus()  # keys keep going to the page (and so to the game)
        return True

    def set_video_cursor(self):
        widget = self.video and self.video.widget
        window = widget and widget.get_window()
        if window:
            hidden = getattr(self, "cursor_hidden", False)
            window.set_cursor(Gdk.Cursor.new_from_name(window.get_display(), "none") if hidden else None)

    def child_position(self, _overlay, widget, allocation):
        place = self.positions.get(widget)
        if not place:
            return False
        allocation.x, allocation.y, allocation.width, allocation.height = place
        return True
        self.exit_full.set_margin_start(x + 10)
        self.exit_full.set_margin_top(y + 10)

    def on_motion(self, _view, _event):
        # Like the page's own button: shown while the mouse moves over the picture.
        if self.full_window and self.rect and self.video:
            self.exit_full.show()
            if self.exit_timer:
                GLib.source_remove(self.exit_timer)
            self.exit_timer = GLib.timeout_add(2000, self.hide_exit)
        return False

    def hide_exit(self):
        self.exit_timer = 0
        if not self.exit_full.has_focus():
            self.exit_full.hide()
        return False

    def on_video_size(self, w, h):
        self.run_js(f"player && player.nativeSize && player.nativeSize({w}, {h})")
        return False

    def on_video_closed(self):
        self.stop_video()
        self.run_js("player && player.nativeFailed && player.nativeFailed()")  # the page shows it itself again

    def stop_video(self):
        if self.video:
            self.video.stop()
            if self.video.widget is not None and self.video.widget.get_parent() is self.overlay:
                self.positions.pop(self.video.widget, None)
                self.overlay.remove(self.video.widget)
            self.video = None
        self.hud.hide()
        self.exit_full.hide()

    def on_key(self, window, event):
        name = Gtk.accelerator_name(event.keyval, event.state)
        if name == "F11":
            state = window.get_window().get_state() if window.get_window() else 0
            if state & Gdk.WindowState.FULLSCREEN:
                window.unfullscreen()
            else:
                window.fullscreen()
            return True
        return False


if __name__ == "__main__":
    App()
    sys.exit(Gtk.main())
