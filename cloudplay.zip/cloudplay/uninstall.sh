#!/bin/sh
# Removes CloudPlay installed with install.sh.
#
#   ./uninstall.sh           remove the program, but keep accounts, settings and pictures
#   ./uninstall.sh --purge   remove those too (and CloudPlay's Wine setup)
#
# System packages stay installed: other programs may use them.
set -eu

DATA="${XDG_DATA_HOME:-$HOME/.local/share}/cloudplay"
CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}"

# Only the service this install set up: not a CloudPlay set up some other way on this account.
UNIT="$CONFIG/systemd/user/cloudplay.service"
if [ -f "$UNIT" ] && [ "$(systemctl --user show -p FragmentPath --value cloudplay.service 2>/dev/null)" = "$UNIT" ] &&
    grep -q "^WorkingDirectory=$DATA/app\$" "$UNIT"; then
    systemctl --user disable --now cloudplay.service 2>/dev/null || true  # closes any running games
    rm -f "$UNIT"
    systemctl --user daemon-reload 2>/dev/null || true
elif [ -f "$UNIT" ] && grep -q "^WorkingDirectory=$DATA/app\$" "$UNIT"; then
    rm -f "$UNIT"  # installed but not loaded here
fi

DESKTOP=$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")
rm -f "$HOME/.local/bin/cloudplay" "$HOME"/.local/share/icons/hicolor/*/apps/cloudplay.png \
      "$HOME/.local/share/applications/cloudplay.desktop" "$DESKTOP/cloudplay.desktop"
rm -rf "$DATA/app"

if [ "${1:-}" = "--purge" ]; then
    rm -rf "$DATA"
    echo "CloudPlay and all its data are removed."
else
    echo "CloudPlay is removed. Accounts, settings and pictures are kept in $DATA/data"
    echo "(delete that folder, or run ./uninstall.sh --purge, to remove them too)."
fi
