import asyncio
import json
import os
import sqlite3
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

import websockets

from common import tickets
from control import server as control
from control.server import ControlPlane, make_server
from host.host import Host

try:
    from host import desktop  # needs libX11 + GStreamer
except Exception:
    desktop = None

SECRET = "test-secret"


class TicketTests(unittest.TestCase):
    def test_roundtrip(self):
        t = tickets.sign({"sid": "abc"}, "k", ttl=60)
        self.assertEqual(tickets.verify(t, "k")["sid"], "abc")

    def test_rejects_tampering_wrong_key_and_expiry(self):
        t = tickets.sign({"sid": "abc"}, "k", ttl=60)
        payload, mac = t.split(".")
        forged = tickets._b64(json.dumps({"sid": "xyz", "exp": 9999999999}).encode())
        for bad in (f"{forged}.{mac}", "garbage", ""):
            with self.assertRaises(tickets.TicketError):
                tickets.verify(bad, "k")
        with self.assertRaises(tickets.TicketError):
            tickets.verify(t, "other")
        with self.assertRaises(tickets.TicketError):
            tickets.verify(t, "k", now=time.time() + 120)


class PasswordTests(unittest.TestCase):
    def test_hash_and_check(self):
        h = control.hash_password("hunter22")
        self.assertTrue(control.check_password("hunter22", h))
        self.assertFalse(control.check_password("hunter23", h))
        self.assertFalse(control.check_password("x", "not-a-hash"))


@unittest.skipIf(desktop is None or not __import__("shutil").which("pactl"), "needs GStreamer and PulseAudio/PipeWire")
class AudioTests(unittest.TestCase):
    def test_each_game_gets_its_own_sound_device(self):
        import array
        import subprocess

        from host import audio

        game_audio = audio.GameAudio("pcm")
        self.assertTrue(game_audio.env, "a virtual sound device was created")
        tone = subprocess.Popen(
            ["gst-launch-1.0", "-q", "audiotestsrc", "volume=0.25", "!", "audioconvert", "!", "pulsesink"],
            env=dict(os.environ, **game_audio.env), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        try:
            packets, deadline = [], time.monotonic() + 3
            while time.monotonic() < deadline:
                packets += game_audio.pull()
                time.sleep(0.05)
        finally:
            tone.terminate()
            tone.wait()
            game_audio.close()
        samples = array.array("h", b"".join(packets[len(packets) // 2:]))
        self.assertAlmostEqual(max(map(abs, samples)) / 32768, 0.25, delta=0.02, msg="the game's sound is captured")
        sinks = subprocess.run(["pactl", "list", "short", "sinks"], capture_output=True, text=True).stdout
        self.assertNotIn(game_audio.sink, sinks, "the device is removed with the game")


@unittest.skipIf(not os.access("/dev/uinput", os.W_OK), "needs write access to /dev/uinput")
class PadKindTests(unittest.TestCase):
    """Each kind of virtual controller looks like the real one with its Linux
    driver, so games number its buttons the same way (no device is created)."""

    @unittest.skipIf(__import__("importlib").util.find_spec("evdev") is None, "needs python3-evdev")
    def test_each_kind_matches_its_real_driver(self):
        from evdev import ecodes as e

        from host import pad
        keys = lambda kind: pad.capabilities(kind)[e.EV_KEY]  # noqa: E731
        self.assertNotIn(e.BTN_TL2, keys("xbox"), "xpad: the triggers are axes only")
        self.assertIn(e.BTN_TL2, keys("playstation"))
        self.assertIn(e.BTN_Z, keys("nintendo"), "hid-nintendo's Capture button shifts the numbering after it")
        self.assertEqual((pad.KINDS["xbox"]["buttons"][2], pad.KINDS["playstation"]["buttons"][2]),
                         (e.BTN_NORTH, e.BTN_WEST), "the left face button: xpad's X, hid-playstation's square")
        axes = dict(pad.capabilities("playstation")[e.EV_ABS])
        self.assertEqual((axes[e.ABS_X].min, axes[e.ABS_X].max), (0, 255), "DualSense sticks rest mid-range")
        self.assertNotIn(e.ABS_Z, dict(pad.capabilities("nintendo")[e.EV_ABS]), "ZL/ZR are buttons only")


# A virtual controller is a real device on this computer: the desktop and
# programs like chiaki-ng announce it ("controller connected"). Only when asked:
# CLOUDPLAY_TEST_DEVICES=1 python3 -m unittest
@unittest.skipUnless(os.environ.get("CLOUDPLAY_TEST_DEVICES") == "1", "creates a real controller device (set CLOUDPLAY_TEST_DEVICES=1)")
class PadTests(unittest.TestCase):
    def test_virtual_pad_looks_and_acts_like_an_xbox_360_pad(self):
        import evdev
        from evdev import ecodes as e

        from host.pad import VirtualPad

        pad = VirtualPad()
        self.addCleanup(pad.close)
        self.assertTrue(pad.available)
        device = evdev.InputDevice(pad.nodes[0])
        self.addCleanup(device.close)
        self.assertEqual((device.name, device.info.vendor, device.info.product), ("Microsoft X-Box 360 pad", 0x045E, 0x028E))
        self.assertTrue(any(node.startswith("/dev/input/js") for node in pad.nodes), "joystick node for older games")

        pad.update(1 << 0 | 1 << 13, [1.0, -0.5, 0, 0], [0, 0.6])  # A, D-pad down, left stick, right trigger
        time.sleep(0.1)
        last = {}
        while (event := device.read_one()) is not None:
            if event.type != e.EV_SYN:
                last[(event.type, event.code)] = event.value
        self.assertEqual(last[(e.EV_KEY, e.BTN_SOUTH)], 1)
        self.assertEqual(last[(e.EV_ABS, e.ABS_HAT0Y)], 1)
        self.assertEqual(last[(e.EV_ABS, e.ABS_X)], 32767)
        self.assertEqual(last[(e.EV_ABS, e.ABS_Y)], -16384)
        self.assertEqual(last[(e.EV_ABS, e.ABS_RZ)], 153)
        self.assertEqual(last[(e.EV_ABS, e.ABS_Z)], 0, "axes are warmed up once and left at rest")


class SteamTests(unittest.TestCase):
    def setUp(self):
        from pathlib import Path
        from unittest import mock

        from common import steam

        self.steam = steam
        self.dot = Path(tempfile.mkdtemp())
        self.addCleanup(lambda: __import__("shutil").rmtree(self.dot))
        root, extra = self.dot / "steam", self.dot / "SSD"
        for folder in (root, extra):
            (folder / "steamapps").mkdir(parents=True)
        (root / "steamapps" / "libraryfolders.vdf").write_text(
            f'"libraryfolders"\n{{\n "0" {{ "path" "{root}" }}\n "1" {{ "path" "{extra}" }}\n}}\n'
        )

        def manifest(folder, appid, name, flags=4):
            (folder / "steamapps" / f"appmanifest_{appid}.acf").write_text(
                f'"AppState"\n{{\n "appid" "{appid}"\n "name" "{name}"\n "StateFlags" "{flags}"\n}}\n'
            )

        manifest(root, 480, "Spacewar")
        manifest(extra, 2322010, "God of War Ragnarök")
        manifest(root, 1493710, "Proton Experimental")  # a tool, not a game
        manifest(extra, 570, "Dota 2", flags=1026)  # still downloading
        for name, value in (("DOT_STEAM", self.dot), ("ROOT", root)):
            patcher = mock.patch.object(steam, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)

    def test_lists_installed_games_from_every_library_folder(self):
        self.assertEqual(
            self.steam.installed_games(),
            [{"appid": 2322010, "name": "God of War Ragnarök"}, {"appid": 480, "name": "Spacewar"}],
        )

    def test_store_artwork_only_takes_the_game_itself(self):
        import io
        from unittest import mock

        results = {"items": [
            {"id": 2974310, "name": "God of War Ragnarök Soundtrack",
             "tiny_image": "https://cdn.example/apps/2974310/capsule_231x87.jpg?t=1"},
            {"id": 2322010, "name": "God of War Ragnarök",
             "tiny_image": "https://cdn.example/apps/2322010/capsule_231x87.jpg?t=2"},
        ]}
        fetched = []

        def fake_urlopen(url, timeout):
            fetched.append(url)
            if "storesearch" in url:
                return io.BytesIO(json.dumps(results).encode())
            if "appdetails" in url:  # newer games' banners have coded addresses, given here
                appid = url.split("appids=")[1].split("&")[0]
                header = f"https://cdn.example/apps/{appid}/0a1b2c/header.jpg?t=3"
                return io.BytesIO(json.dumps({appid: {"data": {"header_image": header}}}).encode())
            return io.BytesIO(b"\xff\xd8 banner")

        with mock.patch.object(self.steam.urllib.request, "urlopen", fake_urlopen):
            self.assertEqual(self.steam.store_artwork(["GoWR", "God of War Ragnarok"]), b"\xff\xd8 banner")
            self.assertEqual(fetched[-1], "https://cdn.example/apps/2322010/0a1b2c/header.jpg?t=3", "the game, not its soundtrack")
            results["items"] = results["items"][:1]
            self.assertIsNone(self.steam.store_artwork(["God of War Ragnarok"]), "no exact match, no picture")

    def test_knows_which_game_steam_is_running(self):
        self.assertEqual(self.steam.running_app(), 0)
        (self.dot / "registry.vdf").write_text('"Registry"\n{\n "HKCU" { "Steam" { "RunningAppID" "480" } }\n}\n')
        self.assertEqual(self.steam.running_app(), 480)
        (self.dot / "steam.pid").write_text("999999999")
        self.assertIsNone(self.steam.running_pid(), "a stale pid file doesn't count as Steam running")


CHIAKI_CONF = """[General]
version=2

[registered_hosts]
1\\regist_key=@ByteArray(secret)
1\\server_nickname=PS5-123
1\\target=1000100
size=1

[manual_hosts]
1\\host=192.168.1.20
size=1
"""


class ConsoleTests(unittest.TestCase):
    def setUp(self):
        from pathlib import Path
        from unittest import mock

        from common import console

        self.console = console
        conf = Path(tempfile.mkdtemp()) / "Chiaki.conf"
        self.addCleanup(lambda: __import__("shutil").rmtree(conf.parent))
        conf.write_text(CHIAKI_CONF)
        patcher = mock.patch.object(console, "CONFIG", conf)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_reads_consoles_linked_in_chiaki(self):
        self.assertEqual(self.console.linked_consoles(), [{"nickname": "PS5-123", "address": "192.168.1.20"}])

    def test_streams_through_chiaki_fullscreen(self):
        cmd = self.console.launch_command("PS5-123", "192.168.1.20")
        self.assertEqual(cmd[:3], ["flatpak", "run", "io.github.streetpea.Chiaki4deck"])
        self.assertEqual(cmd[-3:], ["stream", "PS5-123", "192.168.1.20"])
        self.assertIn("--exit-app-on-stream-exit", cmd, "the session ends with the stream")

    def test_owner_adds_their_console_to_the_library(self):
        from unittest import mock

        cp = ControlPlane(":memory:", SECRET, fetch_artwork=False)
        owner = cp.store.one("SELECT * FROM users WHERE id = ?", (cp.signup("owner", "password1") and 1,))
        with mock.patch.object(self.console, "installed", return_value=True):
            status = cp.console_status(owner)
        self.assertEqual(status["consoles"], [{"nickname": "PS5-123", "address": "192.168.1.20", "added": False}])
        self.assertEqual((status["installed"], status["installing"]), (True, False))
        with self.assertRaises(control.ApiError):
            cp.add_console(owner, {"nickname": "PS5-123", "address": "not an address!"})
        with self.assertRaises(control.ApiError):
            cp.add_console(owner, {"nickname": "someone else's PS5", "address": "192.168.1.30"})
        game = cp.add_console(owner, {"nickname": "PS5-123", "address": "192.168.1.20"})
        self.assertEqual((game["title"], game["description"]), ("PlayStation", "PlayStation (Remote Play)"))
        self.assertTrue(cp.console_status(owner)["consoles"][0]["added"])


class WineTests(unittest.TestCase):
    def test_every_pinned_layer_says_which_dlls_it_replaces(self):
        from host import wine

        self.assertEqual(set(wine.RELEASES), set(wine.LAYER_DLLS))
        for name, (url, sha256) in wine.RELEASES.items():
            self.assertIn(name, url)
            self.assertRegex(sha256, "^[0-9a-f]{64}$")


class SecurityTests(unittest.TestCase):
    def test_database_is_private_to_its_owner(self):
        path = os.path.join(tempfile.mkdtemp(), "cp.db")
        ControlPlane(path, SECRET, fetch_artwork=False).store.run("SELECT 1")
        ControlPlane(path, SECRET, fetch_artwork=False)  # permissions are fixed on every start
        ControlPlane(path, SECRET)  # and it starts as the real server does (with its background checks)
        self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)

    @unittest.skipIf(desktop is None, "X11/GStreamer not available")
    def test_games_cant_see_private_folders(self):
        args = desktop.sandboxed(["game"], [])
        hidden = {args[i + 1] for i, a in enumerate(args) if a == "--tmpfs"}
        project = os.path.dirname(os.path.dirname(os.path.abspath(desktop.__file__)))
        self.assertIn(project, hidden, "CloudPlay's own database")
        for path in ("~/.ssh", "~/.mozilla", "~/.config/BraveSoftware", "~/.local/share/keyrings"):
            if os.path.isdir(os.path.expanduser(path)):
                self.assertIn(os.path.expanduser(path), hidden)
        self.assertNotIn(os.path.expanduser("~"), hidden, "the rest of home (saves, settings) stays")


class MigrationTests(unittest.TestCase):
    def test_upgrades_old_database_and_makes_first_user_owner(self):
        path = os.path.join(tempfile.mkdtemp(), "old.db")
        db = sqlite3.connect(path)
        db.executescript(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pw_hash TEXT NOT NULL, "
            "plan TEXT NOT NULL DEFAULT 'free', created_at REAL NOT NULL);"
            "CREATE TABLE hosts (id TEXT PRIMARY KEY, ws_url TEXT NOT NULL, region TEXT NOT NULL, "
            "capacity INTEGER NOT NULL, last_seen REAL NOT NULL);"
            "INSERT INTO users(email, pw_hash, created_at) VALUES ('first@x.io', 'h', 1), ('second@x.io', 'h', 2);"
        )
        db.commit()
        db.close()
        cp = ControlPlane(path, SECRET, fetch_artwork=False)
        admins = [r["username"] for r in cp.store.all("SELECT username FROM users WHERE is_admin = 1")]
        self.assertEqual(admins, ["first@x.io"], "old email addresses become usernames")
        columns = [r["name"] for r in cp.store.all("PRAGMA table_info(users)")]
        self.assertNotIn("plan", columns, "the old free/pro plan column is removed")


WINDOW_GAME = """#!/usr/bin/env python3
import sys, gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk
log = open(sys.argv[1], "a", buffering=1)
log.write("display " + Gdk.Display.get_default().get_name() + "\\n")
w = Gtk.Window(title="test game")
w.set_default_size(640, 360)
w.connect("key-press-event", lambda _, e: log.write("key " + Gdk.keyval_name(e.keyval) + "\\n"))
w.connect("destroy", Gtk.main_quit)
w.show_all()
Gtk.main()
"""


def read(path):
    with open(path) as f:
        return f.read()


@unittest.skipIf(desktop is None or not __import__("shutil").which("Xvfb"), "needs X11, GStreamer and Xvfb")
class HiddenScreenTests(unittest.TestCase):
    def test_game_runs_on_its_own_hidden_screen(self):
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder))
        path, events = os.path.join(folder, "game"), os.path.join(folder, "events.log")
        with open(path, "w") as f:
            f.write(WINDOW_GAME)
        os.chmod(path, 0o755)

        game = desktop.DesktopGame({"runner": "native", "path": path, "args": [events]}, None, "test", gamepad=False)
        screen_procs = list(game.screen.procs)
        try:
            screen = game.screen.name
            self.assertNotEqual(screen, os.environ.get("DISPLAY"))
            deadline = time.monotonic() + 15
            while game.geom is None and time.monotonic() < deadline:
                game.next_frame(1 / 30, 70)
            self.assertEqual(game.geom[2:], (640, 360), "captures just the game's window")
            frame = game.next_frame(1 / 30, 70)
            self.assertTrue(frame.startswith(b"\xff\xd8"), "JPEG frames")
            game.on_input("ArrowRight", True)
            game.on_input("ArrowRight", False)
            deadline = time.monotonic() + 5
            while "key Right" not in read(events) and time.monotonic() < deadline:
                game.next_frame(1 / 30, 70)
        finally:
            game.close()
        log = read(events)
        self.assertIn(f"display {screen}", log)
        self.assertIn("key Right", log, "input reaches the game without a window manager")
        self.assertTrue(all(p.poll() is not None for p in screen_procs), "the hidden screen is shut down with the game")

    @unittest.skipIf(desktop is None or not desktop.h264_encoder(), "needs an H.264 encoder (gstreamer1.0-plugins-bad/ugly)")
    def test_h264_stream_starts_with_a_keyframe_and_runs_at_60fps(self):
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder))
        path = os.path.join(folder, "game")
        with open(path, "w") as f:
            f.write(WINDOW_GAME)
        os.chmod(path, 0o755)

        game = desktop.DesktopGame({"runner": "native", "path": path, "args": [os.devnull]}, None, "test", "h264", gamepad=False)
        try:
            self.assertEqual((game.codec, game.fps), ("h264", 60))
            chunks, deadline = [], time.monotonic() + 15
            while not chunks and time.monotonic() < deadline:  # "Launching…" placeholder first
                chunks = [c for c in game.next_frame(1 / 60, 70) if c[0] != desktop.FRAME_JPEG]
            start = time.monotonic()
            while time.monotonic() - start < 2:
                chunks += game.next_frame(1 / 60, 70)
            game.request_keyframe()
            later = []
            while time.monotonic() - start < 3:
                later += game.next_frame(1 / 60, 70)
        finally:
            game.close()
        self.assertEqual(chunks[0][0], desktop.FRAME_KEY, "a new stream opens with a keyframe")
        nal_types = [part[0] & 0x1F for part in chunks[0][1].split(b"\x00\x00\x01")[1:] if part]
        self.assertIn(7, nal_types, "keyframes carry the SPS (Annex B), so a browser can join at any keyframe")
        self.assertGreater(len(chunks), 100, f"about 60 fps, got {len(chunks) / 2:.0f}")
        self.assertIn(desktop.FRAME_KEY, [kind for kind, _ in later], "keyframes can be requested")


@unittest.skipIf(
    desktop is None or not desktop.h264_encoder() or not desktop.Gst.ElementFactory.find("vah264dec"),
    "needs an H.264 encoder and decoder",
)
class EncoderTests(unittest.TestCase):
    def test_gpu_converts_only_at_safe_widths(self):
        # Cheap GPU conversion at the usual full-screen sizes; the CPU where the GPU shears.
        for width in (1920, 1280, 640):
            self.assertTrue(desktop.gpu_convert_safe(width, width), width)
        for width in (330, 1008, 1164, 1366):
            self.assertFalse(desktop.gpu_convert_safe(width, width), width)
        self.assertFalse(desktop.gpu_convert_safe(1920, 1366), "scaled to an unsafe width")

    def test_odd_widths_are_not_sheared(self):
        # The GPU colour converter used to shear the picture at widths like these.
        for width in (330, 1008, 1164):
            encode = desktop.h264_encoder().format(w=width, h=120, kbps=4000, gop=60)
            pipeline = desktop.Gst.parse_launch(
                f"videotestsrc pattern=smpte num-buffers=5 ! video/x-raw,format=BGRx,width={width},height=120,framerate=60/1 ! "
                f"{encode} ! h264parse ! vah264dec ! videoconvert ! video/x-raw,format=RGB ! appsink name=sink sync=false"
            )
            pipeline.set_state(desktop.Gst.State.PLAYING)
            sample = pipeline.get_by_name("sink").try_pull_sample(5 * desktop.Gst.SECOND)
            pipeline.set_state(desktop.Gst.State.NULL)
            self.assertIsNotNone(sample, width)
            buf = sample.get_buffer()
            stride = buf.get_size() // 120
            data = buf.extract_dup(0, buf.get_size())
            pixel = lambda x, y: data[y * stride + 3 * x: y * stride + 3 * x + 3]  # noqa: E731
            # SMPTE bars are vertical: a column's colour is the same near the top and further down.
            differ = sum(1 for x in range(0, width, 3) if sum(abs(a - b) for a, b in zip(pixel(x, 5), pixel(x, 70))) > 60)
            self.assertLess(differ, 3, f"picture {width} px wide is sheared")


def http(base, method, path, body=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(base + path, data=json.dumps(body).encode() if body else None, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


class EndToEndTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.cp = ControlPlane(":memory:", SECRET, fetch_artwork=False)
        control.anticheat._cache.update(at=time.time() + 10**9, steam={}, epic={}, names={})  # (offline: no list)
        self.http_server = make_server("127.0.0.1", 0, self.cp)
        threading.Thread(target=self.http_server.serve_forever, daemon=True).start()
        self.base = f"http://127.0.0.1:{self.http_server.server_address[1]}"
        self.host = Host("h1", SECRET, self.base, capacity=2, pc_games=False)
        self.ws_server = await self.host.start("127.0.0.1", 0)

    async def asyncTearDown(self):
        self.ws_server.close()
        await self.ws_server.wait_closed()
        await asyncio.to_thread(self.http_server.shutdown)
        self.http_server.server_close()

    async def call(self, *args, **kwargs):
        return await asyncio.to_thread(http, self.base, *args, **kwargs)

    async def signup(self, username="player1"):
        """The first account is the owner; later ones sign up with an invite from the owner."""
        invite = None
        if getattr(self, "owner_token", None):
            _, created = await self.call("POST", "/api/invites", token=self.owner_token)
            invite = created["code"]
        status, body = await self.call("POST", "/api/signup", {"username": username, "password": "password1", "invite": invite})
        self.assertEqual(status, 201, body)
        if invite is None:
            self.owner_token = body["token"]
        return body["token"]

    async def test_after_the_owner_only_invited_people_can_sign_up(self):
        _, info = await self.call("GET", "/api/signup")
        self.assertFalse(info["needs_invite"], "the first account (the owner) needs no invite")
        owner = await self.signup("owner")
        _, info = await self.call("GET", "/api/signup")
        self.assertTrue(info["needs_invite"])
        status, _ = await self.call("POST", "/api/signup", {"username": "stranger", "password": "password1"})
        self.assertEqual(status, 403)

        guest = await self.signup("guest")
        status, _ = await self.call("POST", "/api/invites", token=guest)
        self.assertEqual(status, 403, "only the owner invites people")

        _, invite = await self.call("POST", "/api/invites", token=owner)
        self.assertRegex(invite["code"], r"^[A-Z2-9]{4}-[A-Z2-9]{4}$")
        typed = invite["code"].lower().replace("-", " ")  # typed loosely: still accepted
        status, _ = await self.call("POST", "/api/signup", {"username": "friend", "password": "password1", "invite": typed})
        self.assertEqual(status, 201)
        status, _ = await self.call("POST", "/api/signup", {"username": "friend2", "password": "password1", "invite": typed})
        self.assertEqual(status, 403, "each invite works once")

        self.cp.store.run("UPDATE invites SET expires_at = 0")
        _, invite = await self.call("POST", "/api/invites", token=owner)
        self.cp.store.run("UPDATE invites SET expires_at = 0")
        status, _ = await self.call("POST", "/api/signup", {"username": "late", "password": "password1", "invite": invite["code"]})
        self.assertEqual(status, 403, "invites expire")

    async def start_game(self, token):
        """Import a (windowless) game and start a session on the test host."""
        path = await self.make_script()
        _, game = await self.call("POST", "/api/games", {"title": "G", "path": path}, token=token)
        self.host.desktop = desktop
        await self.host.heartbeat()
        status, session = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=token)
        self.assertEqual(status, 201, session)
        return session

    @unittest.skipIf(desktop is None, "X11/GStreamer not available")
    async def test_full_session_lifecycle(self):
        token = await self.signup()
        path = await self.make_script()
        _, game = await self.call("POST", "/api/games", {"title": "G", "path": path}, token=token)
        status, body = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=token)
        self.assertEqual(status, 503, "no hosts have registered yet")

        self.host.desktop = desktop
        await self.host.heartbeat()
        status, session = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=token)
        self.assertEqual(status, 201, session)

        url = f"{session['ws_url']}/play?ticket={session['ticket']}"
        async with websockets.connect(url) as ws:
            hello = json.loads(await ws.recv())
            self.assertEqual((hello["t"], hello["w"], hello["h"]), ("hello", desktop.JPEG_W, desktop.JPEG_H))
            frame = await ws.recv()
            self.assertEqual(frame[4], desktop.FRAME_JPEG)
            self.assertEqual(frame[5:7], b"\xff\xd8", "frames are JPEG (browsers without WebCodecs)")

            await ws.send(json.dumps({"t": "in", "k": "KeyZ", "d": 1}))
            await ws.send(json.dumps({"t": "ping", "c": 1}))
            while True:
                msg = await ws.recv()
                if isinstance(msg, str):
                    self.assertEqual(json.loads(msg)["t"], "pong")
                    break

            await self.host.heartbeat()
            _, me = await self.call("GET", "/api/me", token=token)
            self.assertEqual(me["session"]["status"], "active")

            # A ticket can only be redeemed once.
            async with websockets.connect(url) as replay:
                with self.assertRaises(websockets.ConnectionClosed) as cm:
                    await replay.recv()
                self.assertEqual(cm.exception.code, 4409)

            # Quit from the website: the next heartbeat tells the host to stop.
            await self.call("DELETE", f"/api/sessions/{session['session_id']}", token=token)
            await self.host.heartbeat()
            end = None
            async for msg in ws:
                if isinstance(msg, str) and json.loads(msg)["t"] == "end":
                    end = json.loads(msg)["reason"]
            self.assertEqual(end, "stopped_by_server")

        await self.host.heartbeat()
        row = self.cp.store.one("SELECT status, end_reason FROM sessions WHERE id = ?", (session["session_id"],))
        self.assertEqual((row["status"], row["end_reason"]), ("ended", "stopped_by_server"))

    async def test_rejects_bad_tickets(self):
        await self.host.heartbeat()
        forged = tickets.sign({"sid": "x", "game": "pc-x", "host": "h1"}, "wrong-key", 60)
        async with websockets.connect(f"{self.host.public_url}/play?ticket={forged}") as ws:
            with self.assertRaises(websockets.ConnectionClosed) as cm:
                await ws.recv()
            self.assertEqual(cm.exception.code, 4401)

    async def test_native_video_needs_the_sessions_key(self):
        from types import SimpleNamespace

        session = SimpleNamespace(id="s1", video_key="the-right-key", video_ws=None)
        self.host.sessions["s1"] = session
        for query in ("session=s1&key=wrong", "session=s1&key=", "session=nope&key=the-right-key"):
            async with websockets.connect(f"{self.host.public_url}/video?{query}") as ws:
                with self.assertRaises(websockets.ConnectionClosed) as cm:
                    await ws.recv()
                self.assertEqual(cm.exception.code, 4403, query)
        async with websockets.connect(f"{self.host.public_url}/video?session=s1&key=the-right-key") as ws:
            for _ in range(50):
                if session.video_ws is not None:
                    break
                await asyncio.sleep(0.02)
            self.assertIsNotNone(session.video_ws, "the right key attaches the app's video")
        for _ in range(50):
            if session.video_ws is None:
                break
            await asyncio.sleep(0.02)
        self.assertIsNone(session.video_ws, "and closing it gives the video back to the page")
        del self.host.sessions["s1"]

    async def test_auth_errors(self):
        await self.signup()
        _, invite = await self.call("POST", "/api/invites", token=self.owner_token)
        status, _ = await self.call("POST", "/api/signup", {"username": "Player1", "password": "password1", "invite": invite["code"]})
        self.assertEqual(status, 409, "usernames aren't case-sensitive")
        status, _ = await self.call("POST", "/api/signup", {"username": "a b@c", "password": "password1"})
        self.assertEqual(status, 400)
        status, _ = await self.call("POST", "/api/login", {"username": "player1", "password": "nope"})
        self.assertEqual(status, 401)
        status, _ = await self.call("POST", "/api/login", {"username": "PLAYER1", "password": "password1"})
        self.assertEqual(status, 200)
        status, _ = await self.call("GET", "/api/me", token="made-up")
        self.assertEqual(status, 401)
        status, _ = await self.call("POST", "/api/hosts/heartbeat", {"host_id": "evil"})
        self.assertEqual(status, 401)

    async def test_invite_button_only_when_shared_on_the_network(self):
        owner = await self.signup("owner")
        _, me = await self.call("GET", "/api/me", token=owner)
        self.assertFalse(me["can_invite"], "only this computer can reach it: nobody to invite")
        self.cp.shared = True  # started with --lan
        _, me = await self.call("GET", "/api/me", token=owner)
        self.assertTrue(me["can_invite"])
        guest = await self.signup("guest")
        _, me = await self.call("GET", "/api/me", token=guest)
        self.assertFalse(me["can_invite"], "only the owner invites")

    async def test_profile_picture_is_redrawn_as_a_safe_square(self):
        import io as _io

        from PIL import Image

        token = await self.signup("ilkay")
        picture = _io.BytesIO()
        Image.new("RGB", (800, 400), "orange").save(picture, "PNG")

        def upload(data):
            req = urllib.request.Request(f"{self.base}/api/me/avatar", data=data, method="POST",
                                         headers={"Authorization": f"Bearer {token}"})
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    return resp.status, json.loads(resp.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read())

        status, _ = await asyncio.to_thread(upload, b"<script>not a picture</script>")
        self.assertEqual(status, 400)
        status, body = await asyncio.to_thread(upload, picture.getvalue())
        self.assertEqual(status, 200, body)
        _, me = await self.call("GET", "/api/me", token=token)
        self.assertEqual(me["avatar"], body["avatar"])
        with urllib.request.urlopen(self.base + me["avatar"], timeout=5) as resp:
            saved = Image.open(_io.BytesIO(resp.read()))
        self.assertEqual((saved.format, saved.size), ("JPEG", (256, 256)))
        await self.call("DELETE", "/api/me/avatar", token=token)
        _, me = await self.call("GET", "/api/me", token=token)
        self.assertIsNone(me["avatar"])

    async def test_any_colour_can_be_picked(self):
        owner = await self.signup()
        for colour in ("purple", "#3fa7ff"):
            status, body = await self.call("POST", "/api/me/settings", {"accent": colour}, token=owner)
            self.assertEqual((status, body["settings"]["accent"]), (200, colour))
        for bad in ("#3FA7FF", "#fff", "rgb(1,2,3)", "url(x)", 5):
            status, _ = await self.call("POST", "/api/me/settings", {"accent": bad}, token=owner)
            self.assertEqual(status, 400, bad)

    async def test_settings_are_saved_per_account(self):
        token = await self.signup("ilkay")
        _, me = await self.call("GET", "/api/me", token=token)
        self.assertEqual(me["settings"], {"accent": "orange", "theme": "dark", "quality": "best", "volume": 100,
                                          "stats": True, "full_window": False, "background": "plain"})
        status, body = await self.call("POST", "/api/me/settings", {"theme": "light", "volume": 40, "stats": False}, token=token)
        self.assertEqual(status, 200, body)
        _, me = await self.call("GET", "/api/me", token=token)
        self.assertEqual((me["settings"]["theme"], me["settings"]["volume"], me["settings"]["stats"]), ("light", 40, False))
        for bad in ({"theme": "neon"}, {"volume": 150}, {"stats": 1}, {"volume": True}, {"admin": True}):
            status, _ = await self.call("POST", "/api/me/settings", bad, token=token)
            self.assertEqual(status, 400, bad)
        other = await self.signup("other")
        _, me = await self.call("GET", "/api/me", token=other)
        self.assertEqual(me["settings"]["theme"], "dark", "each person has their own")

        # Two changes at the same moment both stick (neither undoes the other).
        await asyncio.gather(*(self.call("POST", "/api/me/settings", change, token=other)
                               for change in ({"background": "grid"}, {"accent": "pink"}, {"stats": False})))
        _, me = await self.call("GET", "/api/me", token=other)
        self.assertEqual((me["settings"]["background"], me["settings"]["accent"], me["settings"]["stats"]), ("grid", "pink", False))

    async def test_custom_background_image(self):
        import io as _io

        from PIL import Image

        token = await self.signup("ilkay")
        status, _ = await self.call("POST", "/api/me/settings", {"background": "custom"}, token=token)
        self.assertEqual(status, 400, "no image uploaded yet")
        status, _ = await self.call("POST", "/api/me/settings", {"background": "stars"}, token=token)
        self.assertEqual(status, 200)

        picture = _io.BytesIO()
        Image.new("RGB", (4000, 1000), "teal").save(picture, "PNG")
        req = urllib.request.Request(f"{self.base}/api/me/background", data=picture.getvalue(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
        body = await asyncio.to_thread(lambda: json.loads(urllib.request.urlopen(req, timeout=5).read()))
        self.assertEqual(body["settings"]["background"], "custom", "uploading switches to it")
        with urllib.request.urlopen(self.base + body["background_image"], timeout=5) as resp:
            saved = Image.open(_io.BytesIO(resp.read()))
        self.assertEqual((saved.format, saved.size), ("JPEG", (1920, 480)), "shrunk to fit 1920x1080, same shape")

        _, body = await self.call("DELETE", "/api/me/background", token=token)
        self.assertEqual((body["settings"]["background"], body["background_image"]), ("plain", None))

    async def test_rename_account(self):
        token = await self.signup("ilkay")
        await self.signup("taken")
        status, _ = await self.call("POST", "/api/me/username", {"username": "Taken"}, token=token)
        self.assertEqual(status, 409)
        status, body = await self.call("POST", "/api/me/username", {"username": "Ilkay_2"}, token=token)
        self.assertEqual((status, body), (200, {"username": "Ilkay_2"}))
        _, me = await self.call("GET", "/api/me", token=token)
        self.assertEqual(me["username"], "Ilkay_2")
        status, _ = await self.call("POST", "/api/login", {"username": "ilkay_2", "password": "password1"})
        self.assertEqual(status, 200)

    async def make_script(self, name="game.sh", executable=True):
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder))
        path = os.path.join(folder, name)
        with open(path, "w") as f:
            f.write("#!/bin/sh\nsleep 30\n")
        os.chmod(path, 0o755 if executable else 0o644)
        return path

    async def test_only_the_owner_can_import_games(self):
        owner = await self.signup("owner")
        guest = await self.signup("guest")
        _, me = await self.call("GET", "/api/me", token=owner)
        self.assertTrue(me["is_admin"])
        _, me = await self.call("GET", "/api/me", token=guest)
        self.assertFalse(me["is_admin"])

        path = await self.make_script()
        status, _ = await self.call("POST", "/api/games", {"title": "Mine", "path": path}, token=guest)
        self.assertEqual(status, 403)
        status, _ = await self.call("GET", "/api/files", token=guest)
        self.assertEqual(status, 403)

        status, game = await self.call("POST", "/api/games", {"title": "My Game", "path": path, "args": "--windowed 'a b'"}, token=owner)
        self.assertEqual(status, 201, game)
        self.assertEqual(game["description"], "Linux game")
        row = self.cp.store.one("SELECT args FROM games")
        self.assertEqual(json.loads(row["args"]), ["--windowed", "a b"])

        _, listing = await self.call("GET", "/api/games", token=guest)
        imported = listing["games"]
        self.assertEqual([g["title"] for g in imported], ["My Game"])
        self.assertNotIn("path", imported[0], "only the owner sees file paths")

        status, _ = await self.call("DELETE", f"/api/games/{game['slug']}", token=guest)
        self.assertEqual(status, 403)
        status, _ = await self.call("DELETE", f"/api/games/{game['slug']}", token=owner)
        self.assertEqual(status, 200)

    async def test_import_validation_and_browsing(self):
        owner = await self.signup()
        status, body = await self.call("POST", "/api/games", {"title": "X", "path": "/nope/game"}, token=owner)
        self.assertEqual(status, 400)
        not_runnable = await self.make_script("notes.txt", executable=False)
        status, body = await self.call("POST", "/api/games", {"title": "X", "path": not_runnable}, token=owner)
        self.assertEqual(status, 400)
        self.assertIn("chmod", body["error"])
        status, _ = await self.call("POST", "/api/games", {"title": "", "path": not_runnable}, token=owner)
        self.assertEqual(status, 400)

        path = await self.make_script()
        folder = os.path.dirname(path)
        open(os.path.join(folder, "Game.EXE"), "w").close()
        os.mkdir(os.path.join(folder, "data"))
        status, listing = await self.call("GET", f"/api/files?dir={folder}", token=owner)
        self.assertEqual(status, 200)
        self.assertEqual(
            [(e["name"], e["type"], e.get("runner")) for e in listing["entries"]],
            [("data", "dir", None), ("Game.EXE", "file", "wine"), ("game.sh", "file", "native")],
            "notes.txt isn't runnable so it's hidden",
        )
        self.assertEqual(listing["parent"], os.path.dirname(folder))

    async def test_pc_games_go_to_a_desktop_host_with_launch_details(self):
        owner = await self.signup()
        path = await self.make_script()
        _, game = await self.call("POST", "/api/games", {"title": "G", "path": path}, token=owner)
        await self.host.heartbeat()  # this host can't run games
        status, body = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=owner)
        self.assertEqual(status, 503)
        self.assertIn("busy", body["error"])

        self.host.desktop = object()  # pretend PC games are enabled
        await self.host.heartbeat()
        status, session = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=owner)
        self.assertEqual(status, 201, session)
        claims = tickets.verify(session["ticket"], self.cp.ticket_key)
        self.assertEqual(claims["launch"], {"runner": "native", "path": path, "args": []})
        self.assertEqual(claims["title"], "G")

    async def test_library_cards_show_the_games_official_art(self):
        from unittest import mock

        owner = await self.signup()
        banner = b"\xff\xd8 official banner"
        self.cp.fetch_artwork = True
        with mock.patch.object(control.steam, "store_artwork", return_value=banner) as look_up:
            _, game = await self.call("POST", "/api/games", {"title": "GoWR", "path": await self.make_script()}, token=owner)
            for _ in range(50):  # looked up in the background
                if self.cp.thumbnail_path(game["slug"]).exists():
                    break
                await asyncio.sleep(0.05)
        self.assertEqual(look_up.call_args[0][0][0], "GoWR", "searched by the game's name, then its folder's")
        _, listing = await self.call("GET", "/api/games", token=owner)
        with urllib.request.urlopen(self.base + listing["games"][0]["thumbnail"], timeout=5) as resp:
            self.assertEqual((resp.headers["Content-Type"], resp.read()), ("image/jpeg", banner))

        # Steam games use the banner Steam has already downloaded.
        art = os.path.join(tempfile.mkdtemp(), "header.jpg")
        with open(art, "wb") as f:
            f.write(b"\xff\xd8 steam banner")
        with mock.patch.object(control.steam, "installed_games", return_value=[{"appid": 480, "name": "Spacewar"}]), \
                mock.patch.object(control.steam, "artwork", return_value=art):
            status, steam_game = await self.call("POST", "/api/games", {"title": "Spacewar", "steam_appid": 480}, token=owner)
        self.assertEqual(status, 201, steam_game)
        with urllib.request.urlopen(self.base + steam_game["thumbnail"], timeout=5) as resp:
            self.assertEqual(resp.read(), b"\xff\xd8 steam banner")

        await self.call("DELETE", f"/api/games/{game['slug']}", token=owner)
        self.assertFalse(self.cp.thumbnail_path(game["slug"]).exists(), "removed with the game")

    async def test_cover_art_looked_up_ahead_is_there_at_import(self):
        from unittest import mock

        owner = await self.signup()
        self.cp.fetch_artwork = True
        path = await self.make_script()
        with mock.patch.object(control.steam, "store_artwork", return_value=b"\xff\xd8 banner") as look_up:
            status, _ = await self.call("POST", "/api/artwork/prefetch", {"title": "Celeste", "path": path}, token=owner)
            self.assertEqual(status, 200)
            for _ in range(50):
                if self.cp.artwork and all(e["done"].is_set() for e in self.cp.artwork.values()):
                    break
                await asyncio.sleep(0.05)
            _, game = await self.call("POST", "/api/games", {"title": "Celeste", "path": path}, token=owner)
        self.assertIn("thumbnail", game, "on the card straight away, not after a background lookup")
        self.assertEqual(look_up.call_count, 1, "looked up once, ahead of the import")

    async def test_store_search_marks_whats_already_there(self):
        from unittest import mock

        owner = await self.signup()
        guest = await self.signup("guest")
        found = {"country": "BG", "steam": [
                     {"source": "steam", "id": "480", "name": "Spacewar", "price": 0},
                     {"source": "steam", "id": "367520", "name": "Hollow Knight", "price": 1479, "currency": "EUR"}]}
        with mock.patch.object(control.store, "search", return_value=found), \
                mock.patch.object(control.steam, "available", return_value=True), \
                mock.patch.object(control.steam, "installed_games", return_value=[{"appid": 480, "name": "Spacewar"}]), \
                mock.patch.object(control.epic, "account", return_value=None), \
                mock.patch.object(control.epic, "free_games", return_value=[]), \
                mock.patch.object(control.store, "country", return_value="BG"):
            status, _ = await self.call("GET", "/api/store?q=kart", token=guest)
            self.assertEqual(status, 403, "only the owner installs games")
            status, body = await self.call("GET", "/api/store?q=kart", token=owner)
        self.assertEqual(status, 200, body)
        self.assertEqual([(g["installed"], g["in_library"]) for g in body["steam"]], [(True, False), (False, False)])
        self.assertNotIn("flathub", body, "Flathub isn't in the store any more")

    async def test_store_adds_games_once_installed(self):
        from unittest import mock

        owner = await self.signup()
        with mock.patch.object(control.steam, "available", return_value=True), \
                mock.patch.object(control.steam, "installed_games", return_value=[{"appid": 480, "name": "Spacewar"}]), \
                mock.patch.object(control.store, "open_in_steam") as open_in_steam, \
                mock.patch.object(control.ControlPlane, "_watch_steam"):
            # Already installed in Steam: straight into the library.
            status, body = await self.call("POST", "/api/store/get", {"source": "steam", "id": "480", "name": "Spacewar"}, token=owner)
            self.assertEqual(status, 200, body)
            self.assertEqual(body["added"]["title"], "Spacewar")
            # Not installed: handed to Steam (its store page to buy it), then waited for.
            status, body = await self.call("POST", "/api/store/get", {"source": "steam", "id": "367520", "name": "Hollow Knight", "buy": True}, token=owner)
            self.assertEqual(body, {"waiting": "steam"})
            open_in_steam.assert_called_once_with("367520", buy=True)
            status, _ = await self.call("POST", "/api/store/get", {"source": "steam", "id": "1; rm -rf /"}, token=owner)
            self.assertEqual(status, 400)

        status, _ = await self.call("POST", "/api/store/get", {"source": "flathub", "id": "net.supertuxkart.SuperTuxKart"}, token=owner)
        self.assertEqual(status, 400, "Flathub isn't in the store any more")
        # (Flathub games installed before still run from the library.)
        self.assertEqual(desktop.command_for({"runner": "flatpak", "path": "net.supertuxkart.SuperTuxKart", "args": []}) if desktop else
                         ["flatpak", "run", "net.supertuxkart.SuperTuxKart"], ["flatpak", "run", "net.supertuxkart.SuperTuxKart"])

    async def test_epic_games_install_and_start_through_wine(self):
        from unittest import mock

        owner = await self.signup()
        # The sign-in code from Epic's page: only a real-looking code is passed on.
        self.assertIn("isn't an authorization code", control.epic.sign_in("rm -rf / ; echo"))
        with mock.patch.object(control.epic, "_run") as run, mock.patch.object(control.epic, "account", return_value="ilkay"):
            self.assertIsNone(control.epic.sign_in('{"authorizationCode":"0123456789abcdef0123456789abcdef"}'))
            self.assertEqual(run.call_args[0][:3], ("auth", "--code", "0123456789abcdef0123456789abcdef"))

        installed = []
        with mock.patch.object(control.epic, "account", return_value="ilkay"), \
                mock.patch.object(control.epic, "installed", return_value={}), \
                mock.patch.object(control.epic, "install", side_effect=lambda app, done: (installed.append(app), done(app))):
            status, body = await self.call("POST", "/api/store/get", {"source": "epic", "id": "Sugar", "name": "Celeste"}, token=owner)
            self.assertEqual((status, body), (200, {"waiting": "epic"}))
            status, _ = await self.call("POST", "/api/store/get", {"source": "epic", "id": "a b; c"}, token=owner)
            self.assertEqual(status, 400)
        self.assertEqual(installed, ["Sugar"])
        _, listing = await self.call("GET", "/api/games", token=owner)
        self.assertEqual(next(g for g in listing["games"] if g["title"] == "Celeste")["description"], "Epic game")

        if desktop:
            info = {"game_executable": "Celeste.exe", "game_directory": "/games/Celeste", "working_directory": "/games/Celeste",
                    "game_parameters": [], "egl_parameters": ["-AUTH_PASSWORD=token"], "environment": {"X": 1}}
            launch = {"runner": "epic", "path": "Sugar", "args": []}
            with mock.patch.object(desktop.epic, "available", return_value=True), \
                    mock.patch.object(desktop.epic, "launch_info", return_value=info), \
                    mock.patch.object(desktop.shutil, "which", return_value="/usr/bin/wine"):
                self.assertEqual(desktop.command_for(launch), ["/usr/bin/wine", "/games/Celeste/Celeste.exe", "-AUTH_PASSWORD=token"])
            self.assertEqual((launch["cwd"], launch["env"]), ("/games/Celeste", {"X": "1"}))
            self.assertIn(str(desktop.epic.CONFIG), desktop.PRIVATE_PATHS, "games can't read the Epic sign-in")

    async def test_store_uninstalls_and_cancels(self):
        from unittest import mock

        owner = await self.signup()
        _, game = await self.call("POST", "/api/games", {"title": "Pinball", "path": await self.make_script()}, token=owner)
        self.cp.store.run("UPDATE games SET runner = 'epic', path = 'Pinball' WHERE slug = ?", (game["slug"],))
        # Not while someone plays it.
        self.host.desktop = object()
        await self.host.heartbeat()
        status, session = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=owner)
        self.assertEqual(status, 201, session)
        status, body = await self.call("POST", "/api/store/uninstall", {"source": "epic", "id": "Pinball"}, token=owner)
        self.assertEqual(status, 409, body)
        self.cp.store.run("UPDATE sessions SET status = 'ended'")
        with mock.patch.object(control.epic, "uninstall", return_value=None) as uninstall:
            status, body = await self.call("POST", "/api/store/uninstall", {"source": "epic", "id": "Pinball"}, token=owner)
        self.assertEqual((status, body), (200, {"ok": True}))
        uninstall.assert_called_once_with("Pinball")
        _, listing = await self.call("GET", "/api/games", token=owner)
        self.assertEqual(listing["games"], [], "gone from the library too")
        status, _ = await self.call("POST", "/api/store/uninstall", {"source": "epic", "id": "--all; x"}, token=owner)
        self.assertEqual(status, 400)
        status, _ = await self.call("POST", "/api/store/uninstall", {"source": "flathub", "id": "com.example.Pinball"}, token=owner)
        self.assertEqual(status, 400, "Flathub isn't in the store any more")

        with mock.patch.object(control.epic, "cancel_install") as cancel:
            status, _ = await self.call("POST", "/api/store/cancel", {"source": "epic", "id": "Sugar"}, token=owner)
        self.assertEqual(status, 200)
        cancel.assert_called_once_with("Sugar")
        self.cp.steam_waiting["480"] = (time.time(), "Spacewar", 1, [], None)
        await self.call("POST", "/api/store/cancel", {"source": "steam", "id": "480"}, token=owner)
        self.assertNotIn("480", self.cp.steam_waiting, "no longer waiting for Steam")

    async def test_purchase_history_records_games_got_through_the_store(self):
        from unittest import mock

        owner = await self.signup()
        with mock.patch.object(control.epic, "account", return_value="me"), \
                mock.patch.object(control.epic, "installed", return_value={}), \
                mock.patch.object(control.epic, "download_size", return_value=10**9), \
                mock.patch.object(control.epic, "install", side_effect=lambda app, done: done(app)):
            await self.call("POST", "/api/store/get", {"source": "epic", "id": "Sugar", "name": "Celeste", "price": 999}, token=owner)
        with mock.patch.object(control.steam, "available", return_value=True), \
                mock.patch.object(control.steam, "installed_games", return_value=[]), \
                mock.patch.object(control.store, "open_in_steam"), mock.patch.object(control.ControlPlane, "_watch_steam"):
            await self.call("POST", "/api/store/get", {"source": "steam", "id": "1091500", "name": "Cyberpunk 2077",
                                                       "buy": True, "price": 1799, "currency": "EUR"}, token=owner)
        # Steam has installed it (what the watcher does):
        _since, title, uid, images, record = self.cp.steam_waiting["1091500"]
        user = self.cp.store.one("SELECT * FROM users WHERE id = ?", (uid,))
        self.cp._add_store_game(user, "steam", "1091500", title, images, record)
        _, history = await self.call("GET", "/api/store/history", token=owner)
        self.assertEqual([(i["name"], i["price"]) for i in history["items"]], [("Cyberpunk 2077", 1799), ("Celeste", None)],
                         "newest first; installing an Epic game the account owns isn't buying it")
        self.assertEqual(history["totals"], {"EUR": 1799})
        guest = await self.signup("guest")
        status, _ = await self.call("GET", "/api/store/history", token=guest)
        self.assertEqual(status, 403)

    async def test_hidden_screens_let_several_people_play_at_once(self):
        owner = await self.signup("owner")
        guest = await self.signup("guest")
        _, game = await self.call("POST", "/api/games", {"title": "G", "path": await self.make_script()}, token=owner)
        self.host.desktop = object()  # a hidden screen per game
        await self.host.heartbeat()
        for token in (owner, guest):
            status, body = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=token)
            self.assertEqual(status, 201, body)

        # On the host's real desktop (--on-screen) it's one game at a time.
        self.cp.store.run("UPDATE sessions SET status = 'ended'")
        self.host.desktop_display = ":0"
        await self.host.heartbeat()
        status, _ = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=owner)
        self.assertEqual(status, 201)
        status, _ = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=guest)
        self.assertEqual(status, 503)

    @unittest.skipIf(desktop is None, "X11/GStreamer not available")
    async def test_missing_game_file_ends_the_session_cleanly(self):
        owner = await self.signup()
        path = await self.make_script()
        _, game = await self.call("POST", "/api/games", {"title": "G", "path": path}, token=owner)
        self.host.desktop, self.host.desktop_display = desktop, ":0"
        await self.host.heartbeat()
        _, session = await self.call("POST", "/api/sessions", {"game": game["slug"]}, token=owner)
        os.remove(path)
        async with websockets.connect(f"{session['ws_url']}/play?ticket={session['ticket']}") as ws:
            self.assertEqual(json.loads(await ws.recv()), {"t": "end", "reason": "game_missing"})
        self.assertFalse(self.host.desktop_busy)
        await self.host.heartbeat()
        row = self.cp.store.one("SELECT status, end_reason FROM sessions")
        self.assertEqual((row["status"], row["end_reason"]), ("ended", "game_missing"))

    @unittest.skipIf(desktop is None, "X11/GStreamer not available")
    async def test_stopping_the_server_ends_every_session(self):
        session = await self.start_game(await self.signup())
        async with websockets.connect(f"{session['ws_url']}/play?ticket={session['ticket']}") as ws:
            await ws.recv()  # hello
            await self.host.shutdown()
            self.assertEqual(self.host.sessions, {}, "every game was closed")
            while True:
                msg = await ws.recv()
                if isinstance(msg, str):
                    break
            self.assertEqual(json.loads(msg), {"t": "end", "reason": "server_stopped"})

    async def test_serves_web_app_without_path_traversal(self):
        def get(path):
            with urllib.request.urlopen(self.base + path, timeout=5) as resp:
                return resp.read()

        index = await asyncio.to_thread(get, "/")
        self.assertIn(b"CloudPlay", index)
        leaked = await asyncio.to_thread(get, "/../control/server.py")
        self.assertEqual(leaked, index)


if __name__ == "__main__":
    unittest.main()
