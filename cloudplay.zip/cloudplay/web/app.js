"use strict";

const $ = (sel) => document.querySelector(sel);

const store = {
  get(key) { try { return localStorage.getItem(key); } catch { return null; } },
  set(key, value) { try { value == null ? localStorage.removeItem(key) : localStorage.setItem(key, value); } catch {} },
};

let token = store.get("cp_token");

// --- settings (each person's, saved with their account) ----------------

let me = null; // the signed-in account, from /api/me
let gainNode = null; // game sound goes through this, for the volume setting
const DEFAULT_SETTINGS = {
  accent: "orange", theme: "dark", quality: "best", volume: 100, stats: true, full_window: false, background: "plain",
};
let backgroundImage = store.get("cp_background"); // the person's uploaded background, if any
let settings = { ...DEFAULT_SETTINGS };
try { Object.assign(settings, JSON.parse(store.get("cp_settings") || "{}")); } catch {} // last known, so the page doesn't flash

// Dark text or white, whichever stands out more on this colour ("#rrggbb"),
// by the contrast ratio used for accessible web pages (WCAG).
function readableOn(hex) {
  const light = lightness(hex);
  if (light == null) return "#1a0f06";
  return contrast(light, lightness("#1a0f06")) >= contrast(light, 1) ? "#1a0f06" : "#ffffff";
}

// How light a colour looks (0 black – 1 white), and how much two stand apart (1–21).
function lightness(hex) {
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if (!m) return null;
  const [r, g, b] = m.slice(1).map((h) => {
    const c = parseInt(h, 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function contrast(a, b) {
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}

// The colour for text drawn in it (the logo's "play", links): itself, or a
// lighter (dark theme) or darker (light theme) shade until it's easy to read.
function readableText(hex, background) {
  const bg = lightness(background);
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if (!m || bg == null) return hex;
  const toward = bg < 0.2 ? 255 : 0;
  const rgb = m.slice(1).map((h) => parseInt(h, 16));
  for (let mix = 0; mix <= 1; mix += 0.05) {
    const shade = "#" + rgb.map((c) => Math.round(c + (toward - c) * mix).toString(16).padStart(2, "0")).join("");
    if (contrast(lightness(shade), bg) >= 4.5) return shade;
  }
  return toward ? "#ffffff" : "#000000";
}

function applySettings() {
  const root = document.documentElement;
  const ownColour = settings.accent.startsWith("#"); // picked with "Any colour"
  root.dataset.accent = ownColour ? "custom" : settings.accent;
  if (ownColour) root.style.setProperty("--accent", settings.accent);
  else root.style.removeProperty("--accent");
  root.dataset.theme = settings.theme;
  root.dataset.background = settings.background;
  // (after the theme, whose background matters here) Text on the colour (buttons, the profile letter): dark, or white if that reads better.
  const accent = getComputedStyle(root).getPropertyValue("--accent").trim();
  root.style.setProperty("--on-accent", readableOn(accent));
  root.style.setProperty("--accent-text", readableText(accent, getComputedStyle(root).getPropertyValue("--bg").trim()));
  if (backgroundImage) root.style.setProperty("--custom-image", `url("${backgroundImage}")`);
  else root.style.removeProperty("--custom-image");
  store.set("cp_background", backgroundImage);
  if (me) {
    me.settings = { ...settings };
    me.background_image = backgroundImage;
  }
  if (gainNode) gainNode.gain.value = settings.volume / 100;
  const hud = document.querySelector("#hud");
  if (hud) hud.hidden = !settings.stats;
  store.set("cp_settings", JSON.stringify(settings));
}
applySettings();

// Opened as the CloudPlay app (its launcher adds ?app): no name in the window's
// title bar. A zero-width space, because an empty title makes the browser show the address.
if (window.CLOUDPLAY_APP || new URLSearchParams(location.search).has("app")) document.title = "\u200b"; // (no title in the app)
let games = [];

async function api(method, path, body) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token && !path.startsWith("/api/login")) {
    setToken(null);
    route();
  }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function setToken(value) {
  token = value;
  store.set("cp_token", value);
}

function show(view) {
  for (const el of document.querySelectorAll(".view")) el.hidden = el.id !== `view-${view}`;
  $("#account").hidden = view === "auth";
  if (view !== "player") setFullWindow(false);
}

// --- auth -------------------------------------------------------------

let signingUp = true;

function renderAuthMode() {
  $("#auth-title").textContent = signingUp ? "Make an account" : "Welcome back";
  $("#auth-submit").textContent = signingUp ? "Sign up" : "Sign in";
  $("#auth-switch-text").textContent = signingUp ? "Already have an account?" : "New here?";
  $("#auth-switch").textContent = signingUp ? "Sign in" : "Create an account";
  $("#auth-form").password.autocomplete = signingUp ? "new-password" : "current-password";
  $("#auth-error").textContent = "";
  $("#invite-field").hidden = true;
  if (signingUp) {
    // Only the owner's (first) account signs up without an invite.
    api("GET", "/api/signup").then(({ needs_invite }) => {
      $("#invite-field").hidden = !(signingUp && needs_invite);
      $("#auth-form").invite.required = signingUp && needs_invite;
    }).catch(() => {});
  } else {
    $("#auth-form").invite.required = false;
  }
}

$("#auth-switch").addEventListener("click", () => { signingUp = !signingUp; renderAuthMode(); });

$("#auth-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const button = $("#auth-submit");
  button.disabled = true;
  $("#auth-error").textContent = "";
  try {
    const { token: t } = await api("POST", signingUp ? "/api/signup" : "/api/login", {
      username: form.username.value.trim(), password: form.password.value, invite: form.invite.value || null,
    });
    setToken(t);
    form.reset();
    await route();
  } catch (err) {
    $("#auth-error").textContent = err.message;
  } finally {
    button.disabled = false;
  }
});

$("#signout").addEventListener("click", async () => {
  if (player) player.stop();
  await Promise.all([...removing.keys()].map((slug) => commitRemoval(slug))); // while still signed in
  try { await api("POST", "/api/logout"); } catch {}
  setToken(null);
  settings = { ...DEFAULT_SETTINGS }; // the next person here gets the normal look
  backgroundImage = null;
  applySettings();
  route();
});

// --- library ----------------------------------------------------------

function renderAccount() {
  $("#username").textContent = me.username;
  $("#invite").hidden = !me.can_invite; // only when CloudPlay is shared on the network (--lan)
  for (const spot of [$("#avatar-small"), $("#avatar-big")]) renderAvatar(spot);
  $("#avatar-remove").hidden = !me.avatar;
}

// The profile picture, or the username's first letter when there isn't one.
function renderAvatar(spot) {
  spot.replaceChildren();
  if (me.avatar) {
    const picture = el("img");
    picture.src = me.avatar;
    picture.alt = "";
    spot.append(picture);
  } else {
    spot.textContent = me.username.slice(0, 1).toUpperCase();
  }
}

// --- profile ------------------------------------------------------------

// Opens a window without putting the keyboard on its first control (which
// would draw a focus ring around it); Tab still moves into it from there.
function openDialog(dialog) {
  dialog.showModal();
  dialog.tabIndex = -1;
  dialog.focus();
}

const profileDialog = $("#profile-dialog");
async function openProfile() {
  $("#profile-error").textContent = "";
  $("#rename-form").username.value = me.username;
  renderAccount();
  openDialog(profileDialog);
}

$("#profile-button").addEventListener("click", openProfile);

const settingsDialog = $("#settings-dialog");
const settingsForm = $("#settings-form");

function showVolume() {
  settingsForm.elements.volume.style.setProperty("--fill", `${settings.volume}%`);
  $("#volume-value").textContent = `${settings.volume}%`;
}

function fillSettingsForm() {
  showOwnColour();
  for (const [name, value] of Object.entries(settings)) {
    const field = settingsForm.elements[name];
    if (!field) continue;
    if (field instanceof RadioNodeList) field.value = value;
    else if (field.type === "checkbox") field.checked = value;
    else field.value = value;
  }
  showVolume();
  $("#custom-backdrop").hidden = !backgroundImage; // only once there's a picture to pick
  $("#background-remove").hidden = !backgroundImage;
}

function readSetting(field) {
  if (field.type === "checkbox") return field.checked;
  if (field.type === "range") return Number(field.value);
  return field.value;
}

$("#settings-button").addEventListener("click", () => {
  $("#settings-error").textContent = "";
  fillSettingsForm();
  openDialog(settingsDialog);
  if (me.is_admin) showConsoleSettings();
});

// The owner can add their PlayStation (streamed through chiaki-ng) to the library.
let consolePoll = null;

function consoleButton(label, action, ghost = false) {
  const button = el("button", ghost ? "ghost small" : "small", label);
  button.type = "button";
  button.addEventListener("click", async () => {
    button.disabled = true;
    $("#settings-error").textContent = "";
    try {
      await action();
    } catch (err) {
      $("#settings-error").textContent = err.message;
    }
    button.disabled = false;
  });
  return button;
}

async function showConsoleSettings() {
  const section = $("#console-settings");
  const status = $("#console-status");
  const list = $("#console-list");
  clearTimeout(consolePoll);
  section.hidden = false;
  let data;
  try {
    data = await api("GET", "/api/console");
  } catch (err) {
    status.textContent = err.message;
    return;
  }
  list.replaceChildren();
  const recheck = consoleButton("Check again", showConsoleSettings, true);

  if (data.installing) {
    status.textContent = "Installing chiaki-ng… this takes a few minutes. You can close Settings meanwhile.";
    consolePoll = setTimeout(() => settingsDialog.open && showConsoleSettings(), 4000);
    return;
  }
  if (!data.installed) {
    status.textContent = data.install_error
      ? `Installing chiaki-ng didn't work: ${data.install_error}`
      : "To stream your PlayStation through CloudPlay, you need chiaki-ng (free PlayStation Remote Play).";
    list.append(el("div", "row-buttons"));
    list.lastChild.append(consoleButton("Install chiaki-ng", async () => {
      await api("POST", "/api/console/install");
      showConsoleSettings();
    }));
    return;
  }
  if (!data.consoles.length) {
    status.textContent = "Link your PlayStation once:";
    const steps = el("ol", "steps");
    const first = el("li");
    first.append(consoleButton("Open chiaki-ng", () => api("POST", "/api/console/open")), " on this computer.");
    steps.append(
      first,
      el("li", null, "Turn your PlayStation on, on the same Wi-Fi or network as this computer."),
      el("li", null, "In chiaki-ng, pick your console and choose Register."),
      el("li", null, "On the PlayStation, open Settings → System → Remote Play → Link Device, and type its code into chiaki-ng."),
    );
    const last = el("li");
    last.append(recheck, " once it's linked.");
    steps.append(last);
    list.append(steps);
    return;
  }
  status.textContent = "Add your console to the library, and anyone who plays it gets the console's picture, sound and controller.";
  for (const c of data.consoles) {
    const row = el("div", "console"); // (not a form: it sits inside the settings form)
    const address = el("input"); // no name, so the settings code leaves it alone
    address.placeholder = "Address, e.g. 192.168.1.20";
    address.value = c.address;
    const label = el("label", null, "Network address");
    label.append(address);
    const add = el("button", "small", c.added ? "Added" : "Add to library");
    add.type = "button";
    add.disabled = c.added;
    row.append(el("strong", null, c.nickname), label, add);
    add.addEventListener("click", async () => {
      add.disabled = true;
      try {
        await api("POST", "/api/console", { nickname: c.nickname, address: address.value.trim() });
        add.textContent = "Added";
        const { games: updated } = await api("GET", "/api/games");
        games = updated;
        renderLibrary();
      } catch (err) {
        $("#settings-error").textContent = err.message;
        add.disabled = false;
      }
    });
    list.append(row);
  }
  list.append(el("div", "row-buttons"));
  list.lastChild.append(consoleButton("Open chiaki-ng", () => api("POST", "/api/console/open"), true), recheck);
}
settingsForm.addEventListener("submit", (e) => e.preventDefault()); // Enter in a text box: nothing to submit

// "Any colour": the rainbow circle opens a colour picker, and then shows the colour picked.
const ownColourOption = $("#accent-custom");
const colourPicker = $("#accent-picker");
function showOwnColour() {
  const own = settings.accent.startsWith("#") ? settings.accent : "";
  ownColourOption.value = own;
  ownColourOption.nextElementSibling.style.setProperty("--picked", own || null);
  if (own) colourPicker.value = own;
}
ownColourOption.addEventListener("click", (e) => {
  e.preventDefault(); // chosen once a colour is picked
  if (!colourPicker.value || colourPicker.value === "#000000") colourPicker.value = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#ff7a3d";
  colourPicker.click();
});
colourPicker.addEventListener("input", (e) => {
  e.stopPropagation(); // not a setting of its own: it sets the accent
  settings.accent = colourPicker.value.toLowerCase();
  showOwnColour();
  ownColourOption.checked = true;
  applySettings();
});
colourPicker.addEventListener("change", async (e) => {
  e.stopPropagation();
  try {
    await api("POST", "/api/me/settings", { accent: colourPicker.value.toLowerCase() });
  } catch (err) {
    $("#settings-error").textContent = err.message;
  }
});

$("#settings-close").addEventListener("click", () => {
  clearTimeout(consolePoll);
  settingsDialog.close();
});

$("#background-upload").addEventListener("click", () => $("#background-file").click());
$("#background-file").addEventListener("change", async (e) => {
  const file = e.currentTarget.files[0];
  e.currentTarget.value = "";
  if (!file) return;
  $("#settings-error").textContent = "";
  try {
    // Sent as-is; the server shrinks it to fit 1920x1080 and redraws it.
    const res = await fetch("/api/me/background", { method: "POST", body: file, headers: { Authorization: `Bearer ${token}` } });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Couldn't use that picture.");
    backgroundImage = body.background_image;
    settings = { ...settings, ...body.settings };
    applySettings();
    fillSettingsForm();
  } catch (err) {
    $("#settings-error").textContent = err.message;
  }
});
$("#background-remove").addEventListener("click", async () => {
  try {
    const body = await api("DELETE", "/api/me/background");
    backgroundImage = null;
    settings = { ...settings, ...body.settings };
    applySettings();
    fillSettingsForm();
  } catch (err) {
    $("#settings-error").textContent = err.message;
  }
});

// Changes show straight away; they're saved to the account when let go of.
settingsForm.addEventListener("input", (e) => {
  if (!e.target.name) return;
  settings[e.target.name] = readSetting(e.target);
  showVolume();
  applySettings();
});
settingsForm.addEventListener("change", async (e) => {
  if (!e.target.name) return;
  try {
    // Saved one at a time; what's on screen already shows every change.
    await api("POST", "/api/me/settings", { [e.target.name]: readSetting(e.target) });
  } catch (err) {
    $("#settings-error").textContent = err.message;
  }
});
$("#profile-close").addEventListener("click", () => profileDialog.close());

$("#rename-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("#profile-error").textContent = "";
  try {
    me.username = (await api("POST", "/api/me/username", { username: e.currentTarget.username.value.trim() })).username;
    renderAccount();
  } catch (err) {
    $("#profile-error").textContent = err.message;
  }
});

$("#avatar-change").addEventListener("click", () => $("#avatar-file").click());
$("#avatar-file").addEventListener("change", async (e) => {
  const file = e.currentTarget.files[0];
  e.currentTarget.value = "";
  if (!file) return;
  $("#profile-error").textContent = "";
  try {
    // Sent as-is; the server crops it to a square and redraws it.
    const res = await fetch("/api/me/avatar", { method: "POST", body: file, headers: { Authorization: `Bearer ${token}` } });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Couldn't change the picture.");
    me.avatar = body.avatar;
    renderAccount();
  } catch (err) {
    $("#profile-error").textContent = err.message;
  }
});

$("#avatar-remove").addEventListener("click", async () => {
  try {
    me.avatar = (await api("DELETE", "/api/me/avatar")).avatar;
    renderAccount();
  } catch (err) {
    $("#profile-error").textContent = err.message;
  }
});

$("#invite").addEventListener("click", async () => {
  try {
    const { code } = await api("POST", "/api/invites");
    prompt("Send this invite code to the person you want to let play. It works once, for 7 days.", code);
  } catch (err) {
    alert(err.message);
  }
});

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

// The library is split into pages: as many games as fit on the screen without
// scrolling, the rest on the next page.
let libraryPage = 0;
const CARD_MIN_WIDTH = 280; // as in .games (style.css)
const CARD_GAP = 24;
const ACTIONS_HEIGHT = 54; // the Play and Remove row under each picture

function cardsPerPage() {
  const grid = $("#games");
  const main = $("main");
  const style = getComputedStyle(main);
  const width = grid.clientWidth || main.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
  const columns = Math.max(1, Math.floor((width + CARD_GAP) / (Math.min(CARD_MIN_WIDTH, width) + CARD_GAP)));
  const cardHeight = ((width - CARD_GAP * (columns - 1)) / columns) * 215 / 460 + ACTIONS_HEIGHT;
  const top = grid.getBoundingClientRect().top + scrollY || 200;
  const room = innerHeight - top - 60; // room for the page buttons (the footer line may scroll out of view)
  const rows = Math.max(1, Math.floor((room + CARD_GAP) / (cardHeight + CARD_GAP)));
  return columns * rows;
}

function renderLibrary(turning = false) {
  const grid = $("#games");
  const cards = [];
  for (const g of games) {
    if (removing.has(g.slug)) continue;
    const card = el("article", "card game");
    card.style.setProperty("--game-accent", g.accent);
    const art = el("div", "art", g.thumbnail ? null : g.title);
    if (g.thumbnail) {
      const picture = el("img");
      picture.src = g.thumbnail;
      picture.alt = "";
      art.append(picture);
    }
    card.setAttribute("aria-label", g.title); // just the picture; screen readers still get the name
    const actions = el("div", "actions");
    const play = el("button", null, "Play");
    play.addEventListener("click", () => startGame(g));
    actions.append(play);
    if (me.is_admin) {
      const remove = el("button", "ghost", "Remove");
      remove.addEventListener("click", () => removeGame(g));
      actions.append(remove);
    }
    card.append(art, actions);
    cards.push(card);
  }
  // The owner's "Import a game" card ends every page, so it takes one place on each.
  const perPage = Math.max(1, cardsPerPage() - (me.is_admin ? 1 : 0));
  const pages = Math.max(1, Math.ceil(cards.length / perPage));
  libraryPage = Math.min(Math.max(0, libraryPage), pages - 1);
  grid.replaceChildren(...cards.slice(libraryPage * perPage, (libraryPage + 1) * perPage));
  if (me.is_admin) {
    const add = el("button", "card game import");
    add.append(el("span", "plus", "+"), el("strong", null, "Import a game"),
      el("span", "muted small", "Add a Windows or Linux game from this computer"));
    add.addEventListener("click", openImport);
    grid.append(add);
  } else if (!cards.length) {
    grid.append(el("p", "muted", "Nothing here yet. Ask whoever runs this CloudPlay to add some games."));
  }
  grid.classList.remove("turning");
  if (turning) {
    void grid.offsetWidth; // restart the fade-in
    grid.classList.add("turning");
  }

  $("#pager").hidden = pages < 2;
  $("#page-prev").disabled = libraryPage === 0;
  $("#page-next").disabled = libraryPage === pages - 1;
  $("#pages").replaceChildren(...Array.from({ length: pages }, (_, i) => {
    const dot = el("button");
    dot.type = "button";
    dot.setAttribute("aria-label", `Page ${i + 1}`);
    if (i === libraryPage) dot.setAttribute("aria-current", "page");
    dot.addEventListener("click", () => turnPage(i));
    return dot;
  }));
  $("#resume").hidden = !me.session;
  $("#open-store").hidden = !me.is_admin;
}

function turnPage(page) {
  if (page === libraryPage) return;
  libraryPage = page;
  renderLibrary(true);
}

$("#page-prev").addEventListener("click", () => turnPage(libraryPage - 1));
$("#page-next").addEventListener("click", () => turnPage(libraryPage + 1));
addEventListener("keydown", (e) => { // ← and → turn the page too
  if ($("#view-library").hidden || $("#pager").hidden || document.querySelector("dialog[open]")) return;
  if (e.target.closest?.("input, textarea, select")) return;
  if (e.key === "ArrowLeft" && libraryPage > 0) turnPage(libraryPage - 1);
  if (e.key === "ArrowRight" && !$("#page-next").disabled) turnPage(libraryPage + 1);
});
let resizeTimer = null;
addEventListener("resize", () => { // a different size fits a different number of games
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (me && !$("#view-library").hidden) renderLibrary(); }, 150);
});

// Removing is instant: the card goes at once, and for a few seconds Undo
// brings it back. Only then is it removed on the server (the game's files
// always stay on the computer).
const UNDO_SECONDS = 5;
const removing = new Map(); // slug → { game, timer }

function removeGame(game) {
  $("#library-error").textContent = "";
  for (const slug of [...removing.keys()]) commitRemoval(slug); // one Undo at a time
  removing.set(game.slug, { game, timer: setTimeout(() => commitRemoval(game.slug), UNDO_SECONDS * 1000) });
  $("#undo-text").textContent = `Removed ${game.title}`;
  showUndo(true);
  renderLibrary();
}

let undoHideTimer = null;
function showUndo(on) {
  const bar = $("#undo");
  clearTimeout(undoHideTimer);
  if (on) {
    bar.hidden = false;
    void bar.offsetWidth; // lay it out invisible first, so adding "shown" fades it in right away
    bar.classList.add("shown");
  } else {
    bar.classList.remove("shown");
    undoHideTimer = setTimeout(() => { bar.hidden = true; }, 250); // once it has faded out
  }
}

async function commitRemoval(slug, leaving = false) {
  const pending = removing.get(slug);
  if (!pending) return;
  clearTimeout(pending.timer);
  removing.delete(slug);
  if (!removing.size) showUndo(false);
  const request = { method: "DELETE", headers: { Authorization: `Bearer ${token}` }, keepalive: true };
  if (leaving) return void fetch(`/api/games/${slug}`, request); // the page is closing: just send it
  try {
    const res = await fetch(`/api/games/${slug}`, request);
    if (!res.ok && res.status !== 404) throw new Error((await res.json().catch(() => ({}))).error || "Couldn't remove it.");
    games = games.filter((g) => g.slug !== slug);
  } catch (err) {
    $("#library-error").textContent = `${pending.game.title}: ${err.message}`;
    renderLibrary(); // it's still there
  }
}

$("#undo-button").addEventListener("click", () => {
  for (const { timer } of removing.values()) clearTimeout(timer);
  removing.clear();
  showUndo(false);
  renderLibrary();
});

// Closing the app (or signing out) during the Undo time still removes it.
addEventListener("pagehide", () => { for (const slug of [...removing.keys()]) commitRemoval(slug, true); });

// The official cover art is looked up online after an import; show it on the
// new game's card as soon as it arrives instead of on the next visit.
async function showArtworkWhenFound(slug) {
  for (let i = 0; i < 40; i++) { // for up to 20 seconds
    await new Promise((resolve) => setTimeout(resolve, 500));
    if ($("#view-library").hidden || !games.some((g) => g.slug === slug)) return; // left the library, or removed it
    let found;
    try {
      found = (await api("GET", "/api/games")).games.find((g) => g.slug === slug);
    } catch {
      continue;
    }
    if (!found) return;
    if (found.thumbnail) {
      games = games.map((g) => (g.slug === slug ? found : g));
      renderLibrary();
      return;
    }
  }
}

// --- the store --------------------------------------------------------
// Steam's games at Steam's prices (bought and installed in Steam on this
// computer) and Epic games (installed with Legendary); each joins the library once installed.

let storeQuery = "";
let storeSearchId = 0;
let storeTimer = null;
let storePoll = null;

async function openStore() {
  show("store");
  $("#store-error").textContent = "";
  $("#store-search").focus();
  try { storeStatus = await api("GET", "/api/store/status"); } catch {}
  searchStore($("#store-search").value);
  pollStore();
}

$("#open-store").addEventListener("click", openStore);
$("#close-store").addEventListener("click", () => {
  clearTimeout(storePoll);
  route();
});
$("#store-search").addEventListener("input", (e) => {
  clearTimeout(storeTimer);
  storeTimer = setTimeout(() => searchStore(e.target.value), 300); // once typing pauses
});

async function searchStore(query) {
  storeQuery = query.trim();
  const id = ++storeSearchId;
  for (const grid of [$("#store-steam")]) {
    if (!grid.children.length || grid.querySelector(".empty")) grid.replaceChildren(el("p", "muted empty", "Looking…"));
  }
  let data;
  try {
    data = await api("GET", `/api/store?q=${encodeURIComponent(storeQuery)}`);
  } catch (err) {
    if (id === storeSearchId) $("#store-error").textContent = err.message;
    return;
  }
  if (id !== storeSearchId) return; // a newer search is on its way
  lastStore = data;
  renderStore(data);
}

let lastStore = null;
function renderStore(data) {
  $("#store-error").textContent = "";
  $("#steam-heading").textContent = storeQuery ? "Steam" : "Steam: top sellers";
  renderStoreGrid($("#store-steam"), data.steam, data.steam_available ? null : "Steam isn't installed on this computer. Install it to get Steam games here.");
  renderEpic(data.epic);
}

// Epic Games, through Legendary: set it up once, sign in with an Epic account,
// then the account's games install from here; Epic's free games are claimed on its site.
function renderEpic(e) {
  const box = $("#epic-setup");
  box.hidden = Boolean(e.account);
  $("#epic-account").replaceChildren();
  $("#epic-owned-heading").hidden = !e.account;
  if (e.account) {
    const out = el("button", "link", "Sign out");
    out.type = "button";
    out.addEventListener("click", async () => { await api("POST", "/api/epic/signout"); searchStore($("#store-search").value); });
    $("#epic-account").append(`Signed in as ${e.account} · `, out);
    renderStoreGrid($("#store-epic"), e.owned, null);
  } else {
    $("#store-epic").replaceChildren();
    if (!e.ready) {
      const busy = e.setup.running;
      const go = el("button", null, busy ? "Setting up…" : "Set up Epic Games");
      go.type = "button";
      go.disabled = busy;
      go.addEventListener("click", async () => {
        go.disabled = true;
        go.textContent = "Setting up…";
        try { await api("POST", "/api/epic/setup"); } catch (err) { $("#store-error").textContent = err.message; }
        pollStore();
      });
      box.replaceChildren(
        el("p", null, "To get and play your Epic games, CloudPlay uses Legendary, the free and open-source Epic Games program (3 MB)."),
        ...(e.setup.error ? [el("p", "error", e.setup.error)] : []), go);
    } else {
      const open = el("a", "button-link", "1. Open Epic's sign-in page");
      open.href = e.login_url;
      open.target = "_blank";
      open.rel = "noopener";
      const code = el("input");
      code.placeholder = "2. Paste the authorization code here";
      code.autocomplete = "off";
      code.spellcheck = false;
      const signIn = el("button", null, "Sign in");
      signIn.type = "button";
      const error = el("p", "error");
      signIn.addEventListener("click", async () => {
        signIn.disabled = true;
        error.textContent = "";
        try {
          await api("POST", "/api/epic/signin", { code: code.value });
          searchStore($("#store-search").value);
        } catch (err) {
          error.textContent = err.message;
          signIn.disabled = false;
        }
      });
      const row = el("div", "row");
      row.append(code, signIn);
      box.replaceChildren(
        el("p", null, "Sign in with your Epic Games account. Epic's page shows an authorization code once you're signed in: copy it (the letters and numbers after \"authorizationCode\") and paste it below. CloudPlay never sees your password."),
        open, row, error);
    }
  }
  renderStoreGrid($("#store-epic-free"), e.free, null);
}

function renderStoreGrid(grid, items, unavailable, where = grid.id) {
  if (unavailable) return grid.replaceChildren(el("p", "muted empty", unavailable));
  if (items == null) return grid.replaceChildren(el("p", "muted empty", "Couldn't reach this store. Check the internet connection."));
  if (!items.length) return grid.replaceChildren(el("p", "muted empty", storeQuery ? `Nothing found for “${storeQuery}”.` : "Nothing here right now."));
  grid.replaceChildren(...items.map((item) => storeItem(item, where)));
}

function formatPrice(cents, currency) {
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2)} ${currency || ""}`.trim();
  }
}

// Cards are redrawn often (search, install progress); their pictures are kept
// and moved into the new card, so they don't load again and flicker.
const storePictures = new Map(); // "source:id" → <img>

function storePicture(item, where) {
  const key = `${where}:${item.source}:${item.id}`; // (a picture can only be in one place on the page)
  let img = storePictures.get(key);
  if (img) return img.dataset.failed ? null : img;
  img = el("img");
  img.alt = "";
  img.decoding = "async"; // decoded on the side, not while scrolling
  // Shown once it's loaded and decoded, fading in, instead of popping into an empty box.
  img.onload = () => (img.decode ? img.decode() : Promise.resolve()).catch(() => {}).then(() => img.classList.add("ready"));
  img.onerror = () => { // newer Steam games: the medium picture instead, if there's one
    if (item.image_fallback && img.src !== item.image_fallback) img.src = item.image_fallback;
    else { img.dataset.failed = "1"; img.remove(); }
  };
  img.src = item.image;
  if (storePictures.size > 400) storePictures.delete(storePictures.keys().next().value);
  storePictures.set(key, img);
  return img;
}

function storeItem(item, where) {
  const card = el("article", "store-item");
  const pic = el("div", "pic");
  const img = item.image && storePicture(item, where);
  if (img) pic.append(img);
  const info = el("div", "info");
  const meta = item.wont_run ? "⚠ Won't run on Linux (its anti-cheat blocks it)" : item.source === "steam"
    ? (item.linux == null ? "Steam" : item.linux ? "Steam · Linux" : "Steam · Windows (runs with Proton)")
    : item.source === "epic" ? "Epic · Windows (runs with Wine)"
    : item.source === "epic-free" ? (item.free_now ? "Free on Epic this week" : "Free on Epic soon")
    : item.summary || "";
  info.append(el("div", "name", item.name), el("div", `meta${item.wont_run ? " warning" : ""}`, meta));

  const price = el("span", "price");
  const free = item.price === 0;
  if (free && item.initial) price.append(el("s", null, formatPrice(item.initial, item.currency)), "Free"); // (Epic's free games)
  else if (free) price.textContent = "Free";
  else if (item.price === "soon") price.textContent = "Coming soon";
  else if (item.source === "epic-free" && item.initial) price.append(el("s", null, formatPrice(item.initial, item.currency)));
  else if (item.price != null) {
    if (item.initial) price.append(el("s", null, formatPrice(item.initial, item.currency)));
    price.append(formatPrice(item.price, item.currency));
    if (item.initial) price.append(el("span", "off", `−${Math.round(100 - (item.price / item.initial) * 100)}%`));
  }
  const button = el("button");
  button.type = "button";
  const epicInstall = item.source === "epic" ? storeStatus.epic?.[item.id] : null;
  const installing = epicInstall?.running;
  const waiting = item.source === "steam" && storeStatus.steam_waiting?.includes(item.id);
  const uninstalling = item.source === "steam" && storeStatus.steam_uninstalling?.includes(item.id);
  if (uninstalling) {
    button.textContent = "Uninstall in Steam…";
    button.disabled = true;
    button.className = "ghost";
  } else if (item.in_library) {
    button.textContent = "In library";
    button.disabled = true;
    button.className = "ghost";
  } else if (installing || waiting) {
    button.textContent = waiting ? "Waiting for Steam…" : epicInstall ? `Installing ${Math.floor(epicInstall.progress)}%${timeLeft(epicInstall.eta)}` : "Installing…";
    if (waiting) button.title = "Buy or install it in the Steam window on this computer. Changed your mind? Press Cancel.";
    button.disabled = true;
    button.className = "ghost";
  } else if (item.source === "epic-free") {
    button.textContent = item.free_now ? "Get on Epic" : "Free soon"; // claimed on Epic's site, with the account
    button.disabled = !item.free_now;
  } else if (item.installed) {
    button.textContent = "Add to library";
  } else if (item.price === "soon") {
    button.textContent = "View in Steam"; // to wishlist it there
  } else if (item.source === "steam" && !free && item.price != null) {
    button.textContent = "Buy";
  } else {
    button.textContent = "Install";
  }
  button.addEventListener("click", () => item.source === "epic-free" ? open(item.url, "_blank", "noopener") : getFromStore(item, button));
  const buttons = el("div", "buttons");
  buttons.append(button);
  if (installing || waiting) {
    // Stop getting it: the download (or, for Steam, CloudPlay waiting for it).
    const cancel = el("button", "ghost", "Cancel");
    cancel.type = "button";
    cancel.title = waiting ? "Stops waiting for Steam (a download Steam started carries on in Steam)" : "Stops the download";
    cancel.addEventListener("click", async () => {
      cancel.disabled = true;
      try { await api("POST", "/api/store/cancel", { source: item.source, id: item.id }); } catch (err) { $("#store-error").textContent = err.message; }
      pollStore();
    });
    buttons.append(cancel);
  } else if (item.installed && !uninstalling && item.source !== "epic-free") {
    buttons.append(uninstallButton(item));
  }
  const buy = el("div", "buy");
  buy.append(price, buttons);
  info.append(buy);
  card.append(pic, info);
  return card;
}

// --- purchase history: games got through the store ---

const historyDialog = $("#history-dialog");
const SOURCE_NAMES = { steam: "Steam", flathub: "Flathub", epic: "Epic" };

$("#open-history").addEventListener("click", async () => {
  const list = $("#history-list");
  list.replaceChildren(el("li", "empty", "Loading…"));
  $("#history-total").textContent = "";
  openDialog(historyDialog);
  let data;
  try {
    data = await api("GET", "/api/store/history");
  } catch (err) {
    list.replaceChildren(el("li", "empty", err.message));
    return;
  }
  $("#steam-receipts").href = data.receipts.steam;
  $("#epic-receipts").href = data.receipts.epic;
  if (!data.items.length) {
    list.replaceChildren(el("li", "empty", "Nothing yet. Games you get through the store show up here."));
    return;
  }
  list.replaceChildren(...data.items.map((item) => {
    const row = el("li");
    const when = new Date(item.got_at * 1000).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    const price = item.price == null ? "Already yours" : item.price === 0 ? "Free" : formatPrice(item.price, item.currency);
    row.append(el("span", "when", when), el("span", "name", item.name), el("span", "from", SOURCE_NAMES[item.source] || item.source),
      el("span", "price", price));
    return row;
  }));
  const totals = Object.entries(data.totals).map(([currency, cents]) => formatPrice(cents, currency || "EUR"));
  $("#history-total").textContent = `Spent through CloudPlay: ${totals.length ? totals.join(" + ") : formatPrice(0, "EUR")}`;
});
$("#history-close").addEventListener("click", () => historyDialog.close());

// Uninstalling deletes the game's files, so it asks once more, on the button itself.
function uninstallButton(item) {
  const button = el("button", "ghost", "Uninstall");
  button.type = "button";
  let armed = null;
  button.addEventListener("click", async () => {
    if (!armed) {
      button.textContent = "Sure? Uninstall";
      button.classList.add("danger");
      armed = setTimeout(() => { armed = null; button.textContent = "Uninstall"; button.classList.remove("danger"); }, 4000);
      return;
    }
    clearTimeout(armed);
    button.disabled = true;
    button.textContent = "Uninstalling…";
    $("#store-error").textContent = "";
    try {
      const result = await api("POST", "/api/store/uninstall", { source: item.source, id: item.id });
      if (result.waiting === "steam") $("#store-note").textContent = `Steam asks on this computer whether to uninstall ${item.name}. It leaves your library once Steam has removed it.`;
      await searchStore($("#store-search").value);
      pollStore();
    } catch (err) {
      $("#store-error").textContent = err.message;
      button.disabled = false;
      button.textContent = "Uninstall";
      button.classList.remove("danger");
      armed = null;
    }
  });
  return button;
}

let storeStatus = {};

function timeLeft(seconds) {
  if (!seconds) return "";
  const h = Math.floor(seconds / 3600), m = Math.round((seconds % 3600) / 60);
  return ` · ${h ? `${h} h ${m} min` : `${Math.max(1, m)} min`} left`;
}

async function getFromStore(item, button) {
  const confirmed = button.dataset.confirmed === "1"; // (the download size was shown and clicked)
  // A game that can't run here (anti-cheat) asks once more, on the button itself.
  if (item.wont_run && !button.dataset.sure) {
    button.dataset.sure = "1";
    button.textContent = "Won't run here. Get anyway?";
    button.classList.add("danger");
    return;
  }
  button.disabled = true;
  $("#store-error").textContent = "";
  const buy = item.source === "steam" && !item.installed && (item.price > 0 || item.price === "soon"); // (opens its store page)
  try {
    const result = await api("POST", "/api/store/get", {
      source: item.source, id: item.id, name: item.name, buy,
      image: item.image, image_fallback: item.image_fallback, // (becomes the game's cover in the library)
      price: Number.isInteger(item.price) ? item.price : null, currency: item.currency, // (for the purchase history)
      confirmed,
    });
    if (result.confirm) { // a big download: its size first, then a second click
      button.disabled = false;
      button.textContent = `${result.confirm} download · Install?`;
      button.classList.add("danger");
      button.dataset.confirmed = "1";
      return;
    }
    if (result.added) {
      item.in_library = true;
      button.textContent = "In library";
      button.className = "ghost";
      return;
    }
    if (result.waiting === "steam") {
      $("#store-note").textContent = buy
        ? `Steam is opening ${item.name}'s page on this computer (it can take a moment to start). Buy it there, then install it: it's added to your library once it's installed. Changed your mind? Press Cancel.`
        : `Steam is opening ${item.name}'s install window on this computer (it can take a moment to start). Confirm it there: it's added to your library once it's installed. Changed your mind? Press Cancel.`;
    }
    pollStore();
  } catch (err) {
    $("#store-error").textContent = err.message;
    button.disabled = false;
  }
}

// While something is installing, check on it and refresh the store when it's done.
async function pollStore() {
  clearTimeout(storePoll);
  if ($("#view-store").hidden) return;
  try {
    const before = storeStatus;
    storeStatus = await api("GET", "/api/store/status");
    // Something finished (installed, or Epic got set up): look again. Otherwise
    // only redraw, e.g. a download's percentage.
    const running = (s) => JSON.stringify([s.steam_waiting, s.steam_uninstalling, s.epic_setup?.running,
      Object.entries(s.epic || {}).map(([k, v]) => [k, v.running, v.error])]);
    if (running(before) === running(storeStatus)) {
      if (lastStore) renderStore(lastStore);
    } else searchStore($("#store-search").value);
    const failed = Object.entries(storeStatus.epic || {}).find(([, s]) => s.error);
    if (failed) $("#store-error").textContent = `Couldn't install ${failed[0]}: ${failed[1].error}`;
    if (storeStatus.steam_running && storeStatus.steam_waiting.length === 0) {
      $("#store-note").textContent = "Done installing in Steam? Quit Steam on this computer (Steam ▸ Exit) so CloudPlay can start Steam games itself.";
    }
  } catch {}
  const busy = storeStatus.steam_waiting?.length || storeStatus.steam_uninstalling?.length || storeStatus.epic_setup?.running
    || Object.values(storeStatus.epic || {}).some((s) => s.running);
  if (busy) storePoll = setTimeout(pollStore, 3000);
}

// --- importing --------------------------------------------------------

const importDialog = $("#import-dialog");
const importForm = $("#import-form");
let browseParent = null;
const GENERIC_NAMES = /^(game|start|launch(er)?|run|play|setup|main|app)$/i;

function suggestTitle(path) {
  const parts = path.split("/").filter(Boolean);
  let name = (parts.pop() || "").replace(/\.(exe|bat|sh|x86_64|x86|bin|appimage)$/i, "");
  if (GENERIC_NAMES.test(name) && parts.length) name = parts.pop();
  return name.replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}

async function browse(dir) {
  const list = $("#browse-list");
  try {
    const data = await api("GET", `/api/files?dir=${encodeURIComponent(dir || "")}`);
    browseParent = data.parent;
    $("#browse-up").disabled = !data.parent;
    $("#browse-path").textContent = data.dir;
    list.replaceChildren();
    for (const entry of data.entries) {
      const full = `${data.dir.replace(/\/$/, "")}/${entry.name}`;
      const item = el("li");
      const button = el("button");
      button.type = "button";
      button.append(entry.type === "dir" ? "📁" : "🎮", el("span", null, entry.name));
      if (entry.type === "file") button.append(el("span", "tag", entry.runner === "wine" ? "Windows" : "Linux"));
      button.addEventListener("click", () => {
        if (entry.type === "dir") return browse(full);
        for (const b of list.querySelectorAll(".selected")) b.classList.remove("selected");
        button.classList.add("selected");
        importForm.path.value = full;
        importForm.title.value = suggestTitle(full);
        importForm.runner.value = "";
        prefetchArtwork();
      });
      item.append(button);
      list.append(item);
    }
    if (!data.entries.length) list.append(el("li", "empty", "No folders or games here."));
  } catch (err) {
    $("#import-error").textContent = err.message;
  }
}

function openImport() {
  importForm.reset();
  $("#import-error").textContent = "";
  openDialog(importDialog);
  browse("");
  listSteamGames();
}

async function listSteamGames() {
  const list = $("#steam-list");
  list.replaceChildren(el("li", "empty", "Looking for Steam games…"));
  let data;
  try {
    data = await api("GET", "/api/steam");
  } catch (err) {
    list.replaceChildren(el("li", "empty", err.message));
    return;
  }
  list.replaceChildren();
  if (!data.available) {
    list.append(el("li", "empty", "Steam isn't installed on this computer."));
  } else if (!data.games.length) {
    list.append(el("li", "empty", "No games are installed in Steam yet. Install one in Steam, then open this again."));
  }
  for (const game of data.games) {
    const add = el("button", "ghost small", game.imported ? "Added" : "Add");
    add.type = "button";
    add.disabled = game.imported;
    add.addEventListener("click", async () => {
      add.disabled = true;
      try {
        await api("POST", "/api/games", { title: game.name.slice(0, 60), steam_appid: game.appid });
        importDialog.close();
        libraryPage = Infinity; // new games go last: show that page
        await route();
      } catch (err) {
        $("#import-error").textContent = err.message;
        add.disabled = false;
      }
    });
    const item = el("li");
    item.append(el("span", "name", game.name), add);
    list.append(item);
  }
}

$("#browse-up").addEventListener("click", () => browseParent && browse(browseParent));
$("#import-cancel").addEventListener("click", () => importDialog.close());
importForm.path.addEventListener("change", () => {
  if (!importForm.title.value) importForm.title.value = suggestTitle(importForm.path.value);
  prefetchArtwork();
});

// Look up the cover art while the game is still being picked, so it's on the
// card the moment Import is pressed.
let prefetchTimer = null;
function prefetchArtwork() {
  clearTimeout(prefetchTimer);
  prefetchTimer = setTimeout(() => {
    const title = importForm.title.value.trim();
    if (title) api("POST", "/api/artwork/prefetch", { title, path: importForm.path.value.trim() }).catch(() => {});
  }, 300);
}
importForm.title.addEventListener("input", prefetchArtwork);

importForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const button = $("#import-submit");
  button.disabled = true;
  $("#import-error").textContent = "";
  try {
    const added = await api("POST", "/api/games", {
      title: importForm.title.value, path: importForm.path.value.trim(),
      runner: importForm.runner.value || null, args: importForm.args.value,
    });
    importDialog.close();
    libraryPage = Infinity; // new games go last: show that page
    await route();
    showArtworkWhenFound(added.slug);
  } catch (err) {
    $("#import-error").textContent = err.message;
  } finally {
    button.disabled = false;
  }
});

$("#resume-stop").addEventListener("click", async () => {
  if (!me.session) return;
  try { await api("DELETE", `/api/sessions/${me.session.id}`); } catch {}
  await route();
});

async function route() {
  if (!token) {
    renderAuthMode();
    show("auth");
    return;
  }
  try {
    [me, { games }] = await Promise.all([api("GET", "/api/me"), api("GET", "/api/games")]);
  } catch (err) {
    if (!token) return; // the 401 handler already routed to sign-in
    show("library");
    $("#library-error").textContent = err.message;
    return;
  }
  $("#library-error").textContent = "";
  settings = { ...DEFAULT_SETTINGS, ...me.settings }; // this person's saved settings
  backgroundImage = me.background_image;
  applySettings();
  renderAccount();
  show("library"); // first, so the library can measure how much fits on screen
  renderLibrary();
}


// --- player -----------------------------------------------------------

const END_MESSAGES = {
  stopped_by_server: "This session was ended — did you start a game somewhere else?",
  error: "The game crashed on the server. Sorry about that.",
  disconnected: "Connection lost.",
  game_exited: "The game was closed.",
  server_stopped: "The server was stopped or restarted. Start the game again to keep playing.",
  idle: "Your session ended because there was no input for 15 minutes.",
  launch_failed: "The game couldn't be started on the server.",
  game_missing: "The game's file is gone. It may have been moved or uninstalled; remove it and import it again.",
  no_wine: "The server needs Wine installed to run Windows games.",
  no_xvfb: "The server needs Xvfb installed to run PC games (sudo apt install xvfb).",
  no_steam: "Steam isn't installed on the server.",
  no_legendary: "Epic Games isn't set up on the server: set it up in the Store.",
  epic_failed: "Epic couldn't start the game. Check you're still signed in to Epic in the Store, then try again.",
  no_chiaki: "chiaki-ng isn't installed on the server, so the console can't be streamed.",
  steam_running: "Steam is already open on the server's desktop. Close Steam there first: CloudPlay needs to run it for this game, and Steam only runs once per account.",
  no_display: "The server's desktop isn't available, so PC games can't run right now.",
};

function endMessage(reason) {
  if (END_MESSAGES[reason]) return END_MESSAGES[reason];
  return reason ? `${reason[0].toUpperCase()}${reason.slice(1)}.` : "Session ended.";
}

// Games get real key codes (KeyboardEvent.code); gamepad and touch buttons map onto them.
const BROWSER_KEYS = new Set(["F11"]);

let player = null;

// Browsers only notice gamepads once a page shows interest, and only reveal one
// after a button is pressed on it. Listening from the start means a press in
// the library counts, so the game gets a real controller when Play is pressed.
let gamepadSeen = false;

// Which kind of controller the player holds (from its name), so the game gets
// a virtual one of the same kind and shows the right button hints.
function padKind() {
  const pad = [...(navigator.getGamepads?.() || [])].find(Boolean);
  const name = pad?.id || "";
  if (/xbox|x-box|microsoft|xinput/i.test(name)) return "xbox";
  if (/sony|playstation|dualsense|dualshock|^wireless controller|054c/i.test(name)) return "playstation";
  if (/nintendo|pro controller|joy-con|switch|057e/i.test(name)) return "nintendo";
  return "xbox";
}
addEventListener("gamepadconnected", () => { gamepadSeen = true; });
addEventListener("gamepaddisconnected", () => { gamepadSeen = [...(navigator.getGamepads?.() || [])].some(Boolean); });
navigator.getGamepads?.();

// PC games stream as H.264 when the browser can decode it (WebCodecs needs
// https or localhost); otherwise the server sends JPEG frames.
const FRAME_JPEG = 0, FRAME_KEY = 1, AUDIO = 3;
const H264_SUPPORTED = "VideoDecoder" in window
  ? VideoDecoder.isConfigSupported({ codec: "avc1.640028", optimizeForLatency: true })
      .then((r) => r.supported).catch(() => false)
  : Promise.resolve(false);

// Sound: Opus decoded by WebCodecs where available, raw 16-bit PCM otherwise.
const AUDIO_RATE = 48000, AUDIO_CHANNELS = 2;
const OPUS_SUPPORTED = "AudioDecoder" in window
  ? AudioDecoder.isConfigSupported({ codec: "opus", sampleRate: AUDIO_RATE, numberOfChannels: AUDIO_CHANNELS })
      .then((r) => r.supported).catch(() => false)
  : Promise.resolve(false);
let audioCtx = null;

// Browsers only allow sound to start from a click, so the Play button calls this first.
function unlockAudio() {
  try {
    if (!audioCtx) {
      audioCtx = new AudioContext({ sampleRate: AUDIO_RATE, latencyHint: "interactive" });
      gainNode = audioCtx.createGain();
      gainNode.connect(audioCtx.destination);
      applySettings();
    }
    audioCtx.resume();
  } catch {
    audioCtx = null;
  }
}

// H.264 arrives as "Annex B" (NAL units after 00 00 01 start codes). It's
// decoded as "AVC" instead: each NAL unit prefixed with its length, plus an
// avcC description of the stream from its SPS and PPS. Chrome takes either,
// but WebKit (the CloudPlay app) only decodes this form.
function nalUnits(bytes) {
  const units = [];
  let start = -1;
  for (let i = 0; i + 2 < bytes.length; i++) {
    if (bytes[i] === 0 && bytes[i + 1] === 0 && bytes[i + 2] === 1) {
      if (start >= 0) units.push(bytes.subarray(start, bytes[i - 1] === 0 ? i - 1 : i)); // (4-byte start codes)
      start = i + 3;
      i += 2;
    }
  }
  if (start >= 0) units.push(bytes.subarray(start));
  return units;
}

const NAL_SPS = 7, NAL_PPS = 8, NAL_AUD = 9;

function avcDescription(sps, pps) {
  return new Uint8Array([
    1, sps[1], sps[2], sps[3], 0xff, // version, profile, compatibility, level, 4-byte lengths
    0xe1, sps.length >> 8, sps.length & 0xff, ...sps, // one SPS
    1, pps.length >> 8, pps.length & 0xff, ...pps, // one PPS
  ]);
}

function lengthPrefixed(units) {
  const out = new Uint8Array(units.reduce((n, u) => n + 4 + u.length, 0));
  let at = 0;
  for (const u of units) {
    new DataView(out.buffer).setUint32(at, u.length);
    out.set(u, at + 4);
    at += 4 + u.length;
  }
  return out;
}

class Player {
  constructor(game, session, h264 = false, opus = false) {
    this.game = game;
    this.session = session;
    this.canvas = $("#screen");
    this.ctx = this.canvas.getContext("2d");
    this.held = new Set();
    this.sources = new Map(); // key -> set of input sources holding it (keyboard, pad, touch)
    this.lastDrawn = 0;
    this.frames = 0; // pictures actually drawn on the canvas this second
    this.gameFps = null; // what the game itself draws, measured on the server
    this.bytes = 0;
    this.rtt = null;
    this.quality = null;
    this.ended = false;

    this.codec = "jpeg";
    this.decoder = null;
    this.sps = "";
    this.audioCodec = audioCtx ? (opus ? "opus" : "pcm") : null;
    this.audioDecoder = null;
    this.audioTime = 0;
    this.playAt = 0;
    const video = h264 ? "&video=h264" : "";
    const sound = this.audioCodec ? `&audio=${this.audioCodec}` : "";
    // Only ask for a virtual controller if there's a gamepad: games show controller
    // hints as soon as they see one. (Browsers list a gamepad once a button was pressed.)
    const pad = gamepadSeen || [...(navigator.getGamepads?.() || [])].some(Boolean) ? `&pad=1&padkind=${padKind()}` : "";
    const quality = `&quality=${settings.quality}`;
    const native = h264 && NATIVE_VIDEO ? "&native=1" : "";
    this.native = false; // true while the app shows the picture
    this.nativeRect = null;
    this.ws = new WebSocket(`${session.ws_url}/play?ticket=${encodeURIComponent(session.ticket)}${video}${sound}${pad}${quality}${native}`);
    this.ws.binaryType = "arraybuffer";
    this.ws.onmessage = (e) => this.onMessage(e.data);
    this.ws.onclose = (e) => this.finish(e.reason || "disconnected");
    this.ws.onerror = () => {};

    this.onKey = this.onKey.bind(this);
    this.onBlur = () => {
      this.releaseAll();
      if (this.realPad) this.sendPad(null); // (browsers stop reporting the gamepad while unfocused)
    };
    addEventListener("keydown", this.onKey);
    addEventListener("keyup", this.onKey);
    addEventListener("blur", this.onBlur);
    this.bindTouch();
    this.bindMouse();

    this.pingTimer = setInterval(() => this.send({ t: "ping", c: performance.now() }), 1000);
    this.statsTimer = setInterval(() => this.renderStats(), 1000);
    this.pollPad = this.pollPad.bind(this);
    this.padFrame = requestAnimationFrame(this.pollPad);
  }

  send(msg) {
    if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(msg));
  }

  onMessage(data) {
    if (typeof data === "string") {
      const msg = JSON.parse(data);
      if (msg.t === "hello") {
        this.resize(msg.w, msg.h);
        this.codec = msg.codec || "jpeg";
        this.realPad = Boolean(msg.pad); // the game has a virtual Xbox controller of its own
        if (settings.full_window) setFullWindow(true);
        $("#overlay").hidden = true;
        if (msg.video_key && NATIVE_VIDEO) {
          this.native = true; // from now on the video goes to the app, not here
          const url = `${this.session.ws_url}/video?session=${encodeURIComponent(this.session.session_id)}&key=${encodeURIComponent(msg.video_key)}`;
          APP.postMessage(JSON.stringify({ video: url }));
        }
      } else if (msg.t === "cursor") {
        // The game hides its mouse cursor (keyboard/gamepad games): hide ours over it too.
        this.canvas.style.cursor = msg.hidden ? "none" : "";
        if (this.native) APP.postMessage(JSON.stringify({ cursor: msg.hidden }));
      } else if (msg.t === "pong") {
        this.rtt = performance.now() - msg.c;
        this.quality = msg.q;
        this.gameFps = msg.gf ?? null;
        this.sentFps = msg.sf ?? null;
      } else if (msg.t === "end") {
        this.finish(msg.reason);
      }
      return;
    }
    this.bytes += data.byteLength;
    const view = new DataView(data);
    const seq = view.getUint32(0);
    const kind = view.getUint8(4);
    const payload = new Uint8Array(data, 5);
    if (kind === AUDIO) this.playAudio(payload);
    else if (kind === FRAME_JPEG) this.drawJpeg(seq, payload); // JPEG streams, and "launching…"/"paused" screens
    else this.decode(seq, kind === FRAME_KEY, payload);
  }

  playAudio(payload) {
    if (!audioCtx) return;
    if (this.audioCodec === "pcm") {
      const samples = new Int16Array(payload.slice().buffer); // copied: Int16Array needs 2-byte alignment
      const frames = samples.length / AUDIO_CHANNELS;
      const buffer = audioCtx.createBuffer(AUDIO_CHANNELS, frames, AUDIO_RATE);
      for (let c = 0; c < AUDIO_CHANNELS; c++) {
        const channel = buffer.getChannelData(c);
        for (let i = 0; i < frames; i++) channel[i] = samples[i * AUDIO_CHANNELS + c] / 32768;
      }
      this.schedule(buffer);
      return;
    }
    if (!this.audioDecoder || this.audioDecoder.state === "closed") {
      this.audioDecoder = new AudioDecoder({
        output: (data) => {
          const buffer = audioCtx.createBuffer(data.numberOfChannels, data.numberOfFrames, data.sampleRate);
          for (let c = 0; c < data.numberOfChannels; c++) {
            data.copyTo(buffer.getChannelData(c), { planeIndex: c, format: "f32-planar" });
          }
          data.close();
          this.schedule(buffer);
        },
        error: () => { this.audioDecoder = null; },
      });
      this.audioDecoder.configure({ codec: "opus", sampleRate: AUDIO_RATE, numberOfChannels: AUDIO_CHANNELS });
    }
    this.audioDecoder.decode(new EncodedAudioChunk({ type: "key", timestamp: this.audioTime, data: payload }));
    this.audioTime += 20000; // 20 ms Opus packets
  }

  schedule(buffer) {
    // Play packets back to back slightly ahead of now; if they fall behind or pile up, start over.
    const now = audioCtx.currentTime;
    if (this.playAt < now + 0.01 || this.playAt > now + 0.3) this.playAt = now + 0.06;
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(gainNode || audioCtx.destination);
    source.start(this.playAt);
    this.playAt += buffer.duration;
  }

  decode(seq, key, payload) {
    const units = nalUnits(payload);
    const type = (u) => u[0] & 0x1f;
    if (key) {
      const sps = units.find((u) => type(u) === NAL_SPS);
      const pps = units.find((u) => type(u) === NAL_PPS);
      const id = sps ? Array.from(sps, (b) => b.toString(16).padStart(2, "0")).join("") : "";
      if (sps && pps && (id !== this.sps || !this.decoder || this.decoder.state === "closed")) {
        // New stream or new size: (re)start the decoder with this stream's profile and level.
        if (this.decoder && this.decoder.state !== "closed") this.decoder.close();
        this.sps = id;
        this.decoder = new VideoDecoder({
          output: (frame) => {
            this.resize(frame.displayWidth, frame.displayHeight);
            this.ctx.drawImage(frame, 0, 0, this.canvas.width, this.canvas.height);
            frame.close();
            this.frames++;
          },
          error: () => {
            this.decoder = null; // wait for a fresh keyframe
            this.send({ t: "key" });
          },
        });
        this.decoder.configure({ codec: `avc1.${id.slice(2, 8)}`, description: avcDescription(sps, pps), optimizeForLatency: true });
      }
    }
    if (!this.decoder || this.decoder.state !== "configured") return;
    if (key) {
      this.catchingUp = false;
    } else if (this.catchingUp) {
      return; // frames after a dropped one can't be decoded: wait for the keyframe
    } else if (this.decoder.decodeQueueSize > 8) {
      this.catchingUp = true; // over ~8 frames behind: drop the rest until a fresh keyframe
      this.send({ t: "key" });
      return;
    }
    try {
      const picture = units.filter((u) => ![NAL_SPS, NAL_PPS, NAL_AUD].includes(type(u))); // those are in the description
      this.decoder.decode(new EncodedVideoChunk({ type: key ? "key" : "delta", timestamp: seq * 16667, data: lengthPrefixed(picture) }));
    } catch {
      this.decoder = null;
      this.send({ t: "key" });
    }
  }

  drawJpeg(seq, bytes) {
    createImageBitmap(new Blob([bytes], { type: "image/jpeg" })).then((bitmap) => {
      if (seq > this.lastDrawn) {
        this.lastDrawn = seq;
        this.resize(bitmap.width, bitmap.height); // PC game windows change size
        this.ctx.drawImage(bitmap, 0, 0, this.canvas.width, this.canvas.height);
        this.frames++;
      }
      bitmap.close();
    }).catch(() => {});
  }

  resize(w, h) {
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  setKey(key, source, down) {
    let holders = this.sources.get(key);
    if (!holders) this.sources.set(key, (holders = new Set()));
    down ? holders.add(source) : holders.delete(source);
    const isDown = holders.size > 0;
    if (isDown !== this.held.has(key)) {
      isDown ? this.held.add(key) : this.held.delete(key);
      this.send({ t: "in", k: key, d: isDown ? 1 : 0 });
    }
  }

  releaseAll() {
    for (const key of [...this.held]) {
      this.sources.set(key, new Set());
      this.held.delete(key);
      this.send({ t: "in", k: key, d: 0 });
    }
  }

  onKey(e) {
    if (document.querySelector("dialog[open]")) return; // typing into settings, profile or import
    if (BROWSER_KEYS.has(e.code)) return;
    const key = e.code;
    e.preventDefault();
    if (e.repeat) return;
    this.setKey(key, "kb", e.type === "keydown");
  }

  bindTouch() {
    for (const btn of document.querySelectorAll("#touchpad [data-key]")) {
      const key = btn.dataset.key;
      btn.onpointerdown = (e) => { e.preventDefault(); btn.setPointerCapture(e.pointerId); this.setKey(key, "touch", true); };
      btn.onpointerup = btn.onpointercancel = () => this.setKey(key, "touch", false);
    }
  }

  bindMouse() {
    const c = this.canvas;
    this.mouseHandlers = {
      pointermove: (e) => { this.pendingMove = this.pointerPos(e); },
      pointerdown: (e) => {
        e.preventDefault();
        try { c.setPointerCapture(e.pointerId); } catch {} // so the release arrives even if it happens outside the picture (the app's video does this itself)
        this.send({ t: "mm", ...this.pointerPos(e) });
        this.send({ t: "mb", b: [1, 2, 3][e.button] ?? 1, d: 1 });
      },
      pointerup: (e) => this.send({ t: "mb", b: [1, 2, 3][e.button] ?? 1, d: 0 }),
      wheel: (e) => { e.preventDefault(); this.send({ t: "mw", dy: Math.sign(e.deltaY) }); },
      contextmenu: (e) => e.preventDefault(),
    };
    for (const [type, fn] of Object.entries(this.mouseHandlers)) c.addEventListener(type, fn, { passive: false });
  }

  pointerPos(e) {
    // The canvas is letterboxed (object-fit: contain); map into the picture itself.
    const r = this.canvas.getBoundingClientRect();
    const scale = Math.min(r.width / this.canvas.width, r.height / this.canvas.height);
    const w = this.canvas.width * scale;
    const h = this.canvas.height * scale;
    const clamp = (v) => Math.min(1, Math.max(0, v));
    return { x: clamp((e.clientX - r.left - (r.width - w) / 2) / w), y: clamp((e.clientY - r.top - (r.height - h) / 2) / h) };
  }

  pollPad() {
    this.syncNative();
    if (this.pendingMove) {
      this.send({ t: "mm", ...this.pendingMove });
      this.pendingMove = null;
    }
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const pad = [...pads].find(Boolean);
    if (this.realPad) {
      this.sendPad(pad);
    } else if (pad) {
      // No virtual controller on this server: gamepad buttons become keys.
      const b = (i) => Boolean(pad.buttons[i] && pad.buttons[i].pressed);
      const [ax = 0, ay = 0] = pad.axes;
      this.setKey("ArrowUp", "pad", b(12) || ay < -0.5);
      this.setKey("ArrowDown", "pad", b(13) || ay > 0.5);
      this.setKey("ArrowLeft", "pad", b(14) || ax < -0.5);
      this.setKey("ArrowRight", "pad", b(15) || ax > 0.5);
      // A/B/X/Y → Z/X/C/V (the usual confirm/cancel keys), Start → Enter, Back → Escape.
      this.setKey("KeyZ", "pad", b(0));
      this.setKey("KeyX", "pad", b(1));
      this.setKey("KeyC", "pad", b(2));
      this.setKey("KeyV", "pad", b(3));
      this.setKey("Enter", "pad", b(9));
      this.setKey("Escape", "pad", b(8));
    }
    this.padFrame = requestAnimationFrame(this.pollPad);
  }

  sendPad(pad) {
    // The whole controller in the Gamepad API's standard layout, sent only when it
    // changes (so nothing is sent until the player touches it).
    let msg = { t: "pad", b: 0, s: [0, 0, 0, 0], g: [0, 0] };
    this.lastPad ??= JSON.stringify(msg);
    if (pad) {
      const value = (i) => (pad.buttons[i] ? pad.buttons[i].value : 0);
      pad.buttons.forEach((button, i) => { if (button.pressed && i < 31) msg.b |= 1 << i; });
      const axis = (i) => Math.round((pad.axes[i] || 0) * 1000) / 1000;
      msg = { ...msg, s: [axis(0), axis(1), axis(2), axis(3)], g: [value(6), value(7)].map((v) => Math.round(v * 1000) / 1000) };
    }
    const state = JSON.stringify(msg);
    if (state !== this.lastPad) {
      this.lastPad = state;
      this.send(msg);
    }
  }

  // Called by the app (client/app.py) about its native video.
  nativeSize(w, h) {
    this.resize(w, h); // the mouse maps onto the picture by its size
  }
  nativeFrames(frames, bytes) {
    this.nativeShown = frames;
    this.nativeBytes = bytes;
  }
  nativePointer(type, e) {
    // A mouse event on the app's native video, as if it happened on the canvas.
    this.mouseHandlers?.[type]?.({ ...e, pointerId: 1, preventDefault() {} });
  }
  nativeFailed() {
    // The app couldn't show it: draw it here again, starting from a fresh keyframe.
    this.native = false;
    this.nativeRect = null;
    this.decoder = null;
    this.send({ t: "key" });
  }

  // Tells the app where the picture is, or that it's covered (a window is open,
  // or the start/end message shows), so its video sits exactly over it.
  syncNative() {
    if (!this.native) return;
    const covered = $("#view-player").hidden || !$("#overlay").hidden || document.querySelector("dialog[open]");
    const r = this.canvas.getBoundingClientRect();
    const rect = covered ? null : [r.left, r.top, r.width, r.height].map(Math.round);
    if (JSON.stringify(rect) !== JSON.stringify(this.nativeRect)) {
      this.nativeRect = rect;
      APP.postMessage(JSON.stringify({ rect }));
    }
  }

  renderStats() {
    if (this.native) {
      this.frames = this.nativeShown ?? 0; // as reported by the app a second ago
      this.bytes += this.nativeBytes ?? 0;
      APP.postMessage(JSON.stringify({ frames: true }));
    }
    const mbps = (this.bytes * 8) / 1e6;
    $("#hud").textContent =
      `game ${this.gameFps ?? "–"} fps\n` +
      `stream ${this.frames} fps${this.sentFps == null ? "" : ` (sent ${this.sentFps})`}  ${this.rtt == null ? "–" : Math.round(this.rtt)} ms\n` +
      `${mbps.toFixed(1)} Mbps  ${this.codec === "h264" ? "H.264" : `q${this.quality ?? "–"}`}`;
    if (this.native) APP.postMessage(JSON.stringify({ hud: settings.stats ? $("#hud").textContent : "" }));
    this.frames = 0;
    this.bytes = 0;
  }

  stop() {
    this.send({ t: "bye" });
    api("DELETE", `/api/sessions/${this.session.session_id}`).catch(() => {});
    this.teardown();
    this.ws.close();
  }

  finish(reason) {
    if (this.ended) return;
    this.teardown();
    const overlay = $("#overlay");
    overlay.hidden = false;
    overlay.querySelector(".spinner").hidden = true;
    $("#overlay-text").textContent = endMessage(reason);
  }

  teardown() {
    this.ended = true;
    if (this.native) APP.postMessage(JSON.stringify({ video: null }));
    this.native = false;
    this.canvas.style.cursor = "";
    if (this.decoder && this.decoder.state !== "closed") this.decoder.close();
    if (this.audioDecoder && this.audioDecoder.state !== "closed") this.audioDecoder.close();
    clearInterval(this.pingTimer);
    clearInterval(this.statsTimer);
    cancelAnimationFrame(this.padFrame);
    removeEventListener("keydown", this.onKey);
    removeEventListener("keyup", this.onKey);
    removeEventListener("blur", this.onBlur);
    for (const [type, fn] of Object.entries(this.mouseHandlers || {})) this.canvas.removeEventListener(type, fn);
  }
}

async function startGame(game) {
  unlockAudio(); // must happen before the first await, while the click still counts
  $("#library-error").textContent = "";
  $("#player-title").textContent = game.title;
  $("#player-controls").textContent = game.controls;
  $("#hud").textContent = "";
  $("#overlay").hidden = false;
  $("#overlay .spinner").hidden = false;
  $("#overlay-text").textContent = "Finding a server…";
  const screen = $("#screen");
  screen.getContext("2d").clearRect(0, 0, screen.width, screen.height);
  show("player");
  try {
    const session = await api("POST", "/api/sessions", { game: game.slug });
    $("#overlay-text").textContent = "Starting game…";
    player = new Player(game, session, await H264_SUPPORTED, await OPUS_SUPPORTED);
  } catch (err) {
    show("library");
    $("#library-error").textContent = err.message;
  }
}

$("#stop").addEventListener("click", () => {
  if (player) player.stop();
  player = null;
  route();
});

// In real fullscreen the browser takes Esc to leave it, unless the page holds a
// Keyboard Lock (Chrome, Edge). Browsers without one (Brave, Firefox, Safari)
// get the game filling the window instead: F11 makes that full screen, and
// there Esc reaches the game.
const KEYBOARD_LOCK = Boolean(navigator.keyboard?.lock);
let hintTimer = null;
let fullWindow = false;

// Inside the CloudPlay app (client/app.py) there's no browser around the page:
// the app makes its window truly full screen, and Esc always reaches the game.
const APP = window.webkit?.messageHandlers?.cloudplay;
// …which can also show the game's picture natively, much faster than the page
// can draw it (see NativeVideo in client/app.py).
const NATIVE_VIDEO = Boolean(APP) && (window.CLOUDPLAY_APP?.native ?? new URLSearchParams(location.search).has("native"));

function setFullWindow(on) {
  $("#stage").classList.toggle("full-window", on);
  if (on !== fullWindow) APP?.postMessage(on ? "fullscreen" : "window"); // (leaves the app's own F11 alone)
  fullWindow = on;
  $("#exit-full").hidden = !on;
  $("#full-hint").hidden = !on || Boolean(APP); // (the F11 hint is for browsers)
  clearTimeout(hintTimer);
  if (on) hintTimer = setTimeout(() => { $("#full-hint").hidden = true; }, 5000);
}

$("#fullscreen").addEventListener("click", () => {
  const stage = $("#stage");
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else if (KEYBOARD_LOCK) {
    navigator.keyboard.lock().catch(() => {}); // before entering fullscreen, as browsers expect
    stage.requestFullscreen?.().catch(() => {});
  } else {
    setFullWindow(!stage.classList.contains("full-window"));
  }
});

$("#exit-full").addEventListener("click", (e) => {
  e.currentTarget.blur(); // so Space/Enter go to the game, not this button
  setFullWindow(false);
});

route();
